import { r as levelBadge, s as vipBadge } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useAdminAsset } from "./media-BXNEENvw.mjs";
import { t as AdminAssetMedia } from "./AdminAssetMedia-CBSs12zp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/IdentityBadges-CjJBvqnl.js
var import_jsx_runtime = require_jsx_runtime();
function BadgeChip({ badge }) {
	const badgeAsset = useAdminAsset(badge.badge_asset_key ?? void 0);
	return badgeAsset ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
		src: badgeAsset,
		alt: badge.badge_name,
		title: badge.badge_name,
		className: "h-10 w-10 shrink-0 object-contain drop-shadow-md"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex h-10 w-10 shrink-0 items-center justify-center text-2xl font-black",
		style: { color: badge.badge_color || "#D4AF37" },
		title: badge.badge_name,
		children: "✦"
	});
}
function IdentityBadges({ level, vip = 0, badge, badges = [] }) {
	const equipped = badges.length ? badges : badge ? [badge] : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-full flex-col items-center justify-center gap-2",
		children: [(level !== void 0 || vip > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-center gap-2",
			children: [level !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 text-xs font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: levelBadge(level),
					alt: "",
					width: 30,
					height: 30,
					className: "h-[30px] w-[30px] object-contain",
					loading: "lazy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Lv.", level] })]
			}), vip > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 text-xs font-bold text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: vipBadge(vip),
					alt: "",
					width: 30,
					height: 30,
					className: "h-[30px] w-[30px] object-contain",
					loading: "lazy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["VIP ", vip] })]
			})]
		}), equipped.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap items-center justify-center gap-2",
			children: equipped.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeChip, { badge: item }, item.badge_key || item.badge_name + index))
		})]
	});
}
//#endregion
export { IdentityBadges as t };
