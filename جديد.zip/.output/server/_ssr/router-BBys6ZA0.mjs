import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as Capacitor, t as App } from "../_libs/capacitor__app+capacitor__core.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { _ as createFileRoute, b as useNavigate, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$15 } from "./admin-BY3pKqIL.mjs";
import { C as ShieldCheck, Et as ArrowUp, ct as Download, et as Gem, g as Sparkles, mt as CircleCheck } from "../_libs/lucide-react.mjs";
import { t as Browser } from "../_libs/capacitor__browser.mjs";
import { t as Route$16 } from "./chat._id-Bdxvg7zy.mjs";
import { t as Route$17 } from "./friends-Bdt3DtCk.mjs";
import { s as Route$18 } from "./routes-BUCliJ9d.mjs";
import { t as Route$19 } from "./room._id-GuSW03Ny.mjs";
import { t as Route$20 } from "./u._id-bt2kJDLV.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BBys6ZA0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: {
			duration: 2e3,
			classNames: {
				toast: "group toast group-[.toaster]:!border group-[.toaster]:!border-white/20 group-[.toaster]:!bg-gradient-to-r group-[.toaster]:!from-slate-950/95 group-[.toaster]:!via-indigo-950/95 group-[.toaster]:!to-violet-950/95 group-[.toaster]:!text-white group-[.toaster]:!shadow-[0_12px_38px_rgba(0,0,0,.5)] group-[.toaster]:!backdrop-blur-2xl group-[.toaster]:!rounded-2xl group-[.toaster]:!px-4 group-[.toaster]:!py-3",
				title: "group-[.toast]:!text-white group-[.toast]:!font-bold",
				description: "group-[.toast]:!text-white/80",
				success: "group-[.toast]:!border-emerald-300/50",
				error: "group-[.toast]:!border-rose-300/60",
				warning: "group-[.toast]:!border-amber-300/60",
				info: "group-[.toast]:!border-sky-300/60",
				actionButton: "group-[.toast]:!bg-white/15 group-[.toast]:!text-white",
				cancelButton: "group-[.toast]:!bg-white/10 group-[.toast]:!text-white/80"
			}
		},
		...props
	});
};
var styles_default = "/assets/styles-BOpEUwmo.css";
var APP_VERSION = "2.0.1";
function compareVersions(a, b) {
	const aa = a.split(/[.-]/).map((x) => Number.parseInt(x, 10) || 0);
	const bb = b.split(/[.-]/).map((x) => Number.parseInt(x, 10) || 0);
	for (let i = 0; i < Math.max(aa.length, bb.length); i += 1) {
		const av = aa[i] ?? 0;
		const bv = bb[i] ?? 0;
		if (av !== bv) return av > bv ? 1 : -1;
	}
	return 0;
}
function AppUpdateGate() {
	const [policy, setPolicy] = (0, import_react.useState)(null);
	const [isAdmin, setIsAdmin] = (0, import_react.useState)(false);
	const [hasSession, setHasSession] = (0, import_react.useState)(false);
	const [accessReady, setAccessReady] = (0, import_react.useState)(false);
	const [policyReady, setPolicyReady] = (0, import_react.useState)(false);
	const loadPolicy = (0, import_react.useCallback)(async () => {
		const { data, error } = await supabase.from("admin_settings").select("value").eq("key", "app_update_policy").maybeSingle();
		if (!error) setPolicy(data?.value ?? null);
		setPolicyReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		let alive = true;
		const refreshAdminAccess = async (userId) => {
			if (!userId) {
				if (alive) {
					setHasSession(false);
					setIsAdmin(false);
					setAccessReady(true);
				}
				return;
			}
			if (alive) setHasSession(true);
			const { data, error } = await supabase.rpc("is_admin", { _uid: userId });
			if (alive) {
				setIsAdmin(!error && !!data);
				setAccessReady(true);
			}
		};
		Promise.all([supabase.auth.getUser().then(({ data }) => refreshAdminAccess(data.user?.id)), loadPolicy()]);
		const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
			if (session?.user?.id) refreshAdminAccess(session.user.id);
			else if (event === "SIGNED_OUT") refreshAdminAccess(void 0);
		});
		const channel = supabase.channel("public-app-update-policy").on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "admin_settings",
			filter: "key=eq.app_update_policy"
		}, (payload) => {
			if (!alive) return;
			if (payload.eventType === "DELETE") setPolicy(null);
			else if (payload.new && "value" in payload.new) {
				setPolicy(payload.new.value);
				setPolicyReady(true);
			}
		}).subscribe();
		return () => {
			alive = false;
			authListener.subscription.unsubscribe();
			supabase.removeChannel(channel);
		};
	}, [loadPolicy]);
	if (!accessReady || !policyReady || !hasSession || !policy?.enabled || isAdmin) return null;
	const blocked = (policy.blocked_versions ?? []).map(String).includes(APP_VERSION);
	const belowMinimum = !!policy.min_version && compareVersions(APP_VERSION, policy.min_version) < 0;
	if (!blocked && !belowMinimum) return null;
	let downloadUrl = "";
	try {
		const parsed = policy.download_url ? new URL(policy.download_url) : null;
		if (parsed && parsed.protocol === "https:") downloadUrl = parsed.toString();
	} catch {
		downloadUrl = "";
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "fixed inset-0 z-[99999] flex min-h-[100dvh] items-center justify-center overflow-y-auto bg-[#090511]/95 p-4 backdrop-blur-xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `
        @keyframes updateFloat { 0%,100% { transform: translateY(0) rotate(-3deg); } 50% { transform: translateY(-9px) rotate(3deg); } }
        @keyframes updateOrbit { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes updateGlow { 0%,100% { opacity:.45; transform:scale(.92); } 50% { opacity:.9; transform:scale(1.08); } }
        .update-float { animation:updateFloat 4s ease-in-out infinite; }
        .update-orbit { animation:updateOrbit 12s linear infinite; }
        .update-glow { animation:updateGlow 3s ease-in-out infinite; }
      ` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative w-full max-w-[410px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "update-glow pointer-events-none absolute -inset-5 rounded-[3rem] bg-fuchsia-500/20 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden rounded-[2rem] border border-amber-200/25 bg-gradient-to-b from-[#342044] via-[#1c122b] to-[#100b1a] p-6 text-center shadow-[0_30px_100px_rgba(0,0,0,.7),inset_0_1px_0_rgba(255,255,255,.12)] sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-fuchsia-500/15 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-24 -left-16 h-56 w-56 rounded-full bg-amber-400/10 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto mb-6 grid h-36 w-36 place-items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-1 rounded-full border border-amber-200/20 shadow-[0_0_35px_rgba(251,191,36,.12)]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "update-orbit absolute inset-0 rounded-full border border-dashed border-amber-200/35",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 left-1/2 h-2.5 w-2.5 -translate-x-1/2 rounded-full bg-amber-200 shadow-[0_0_14px_5px_rgba(251,191,36,.55)]" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "update-float relative grid h-24 w-24 place-items-center rounded-[2rem] border border-amber-100/40 bg-gradient-to-br from-[#ffe7a1] via-[#d69b36] to-[#78451b] shadow-[0_14px_0_#593316,0_24px_38px_rgba(0,0,0,.55),inset_0_3px_8px_rgba(255,255,255,.65)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-2 rounded-[1.45rem] border border-white/30" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "relative h-12 w-12 stroke-[3.2] text-[#3b210d] drop-shadow-[0_2px_1px_rgba(255,255,255,.35)]" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "absolute right-1 top-5 h-6 w-6 text-amber-200 drop-shadow-[0_0_10px_rgba(251,191,36,.8)]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "absolute bottom-4 left-1 h-5 w-5 text-fuchsia-200 drop-shadow-[0_0_10px_rgba(232,121,249,.8)]" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 inline-flex items-center gap-2 rounded-full border border-amber-200/25 bg-amber-100/10 px-4 py-1.5 text-xs font-bold tracking-wide text-amber-100 shadow-inner",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), "تحديث إلزامي لصدى شات"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-l from-[#fff1bd] via-[#e8bd65] to-[#fff8df] drop-shadow-[0_3px_12px_rgba(245,190,85,.25)]",
								children: "حان وقت التحديث!"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-4 max-w-sm text-sm leading-8 text-white/80",
								children: policy.message || "يتوفر إصدار جديد من صدى شات. حدّث التطبيق الآن لمتابعة استخدام حسابك والاستمتاع بأحدث التحسينات."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto mt-5 grid max-w-sm grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-white/10 bg-white/[0.06] px-3 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[10px] text-white/45",
										children: "إصدارك الحالي"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "mt-1 block text-sm text-white/90",
										children: APP_VERSION
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-amber-200/20 bg-amber-200/[0.08] px-3 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[10px] text-amber-100/60",
										children: "الإصدار الجديد"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "mt-1 block text-sm text-amber-100",
										children: policy.latest_version || policy.min_version || "الأحدث"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex items-center justify-center gap-2 text-[11px] text-emerald-200/90",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4" }), "تحديث رسمي وآمن من إدارة صدى شات"]
							}),
							downloadUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "mt-6 h-14 w-full rounded-2xl border border-amber-100/50 bg-gradient-to-b from-[#ffe6a0] via-[#e6b64f] to-[#b97925] text-base font-extrabold text-[#281707] shadow-[0_7px_0_#704316,0_14px_25px_rgba(0,0,0,.35),inset_0_2px_5px_rgba(255,255,255,.65)] transition hover:brightness-110 active:translate-y-1 active:shadow-[0_3px_0_#704316] ",
								onClick: () => {
									window.location.assign(downloadUrl);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "ml-2 h-5 w-5" }), "تحميل النسخة الجديدة"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 rounded-2xl border border-amber-200/20 bg-amber-100/10 p-4 text-sm leading-7 text-amber-100",
								children: "رابط التحديث قيد التجهيز. يرجى المحاولة بعد قليل."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex items-center justify-center gap-2 text-[10px] text-white/40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5" }), "يلزم تثبيت التحديث للمتابعة"]
							})
						]
					})
				]
			})]
		})]
	});
}
var MiniRoomVoice = (0, import_react.lazy)(() => import("./RoomVoice-3nPer991.mjs").then((m) => ({ default: m.RoomVoice })));
function NotFoundComponent() {
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		navigate({
			to: "/",
			replace: true
		});
	}, [navigate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		dir: "rtl",
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-12 w-12 animate-pulse rounded-2xl bg-primary/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-bold text-foreground",
					children: "صدي شات"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "جارٍ إعادتك إلى الصفحة الرئيسية…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-5 inline-flex items-center justify-center rounded-full bg-primary px-5 py-2 text-sm font-bold text-primary-foreground",
					children: "الصفحة الرئيسية"
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$14 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover"
			},
			{ title: "صدي شات — غرف صوتية فاخرة" },
			{
				name: "description",
				content: "صدي شات: غرف دردشة صوتية مباشرة ومقاعد وأصدقاء."
			},
			{
				property: "og:title",
				content: "صدي شات"
			},
			{
				property: "og:description",
				content: "غرف دردشة صوتية مباشرة ومقاعد وأصدقاء."
			},
			{
				name: "theme-color",
				content: "#1a0f24"
			},
			{
				name: "mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-status-bar-style",
				content: "black-translucent"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "manifest",
				href: "/manifest.webmanifest"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&family=Reem+Kufi:wght@600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$14.useRouteContext();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!Capacitor.isNativePlatform()) return;
		let active = true;
		let appUrlListener;
		const inFlightOAuthCodes = /* @__PURE__ */ new Set();
		const completedOAuthCodes = /* @__PURE__ */ new Set();
		const completeGoogleOAuth = async (url) => {
			let callbackUrl;
			try {
				callbackUrl = new URL(url);
			} catch {
				return;
			}
			if (callbackUrl.protocol !== "com.voxroyale.app:" || callbackUrl.hostname !== "auth" || callbackUrl.pathname !== "/callback") return;
			const authCode = callbackUrl.searchParams.get("code");
			if (!authCode) {
				const oauthError = callbackUrl.searchParams.get("error_description") || callbackUrl.searchParams.get("error");
				console.error("[Google OAuth] Callback did not include an authorization code:", oauthError);
				await Browser.close().catch(() => void 0);
				if (active) navigate({
					to: "/auth",
					replace: true
				});
				return;
			}
			if (completedOAuthCodes.has(authCode) || inFlightOAuthCodes.has(authCode)) return;
			inFlightOAuthCodes.add(authCode);
			try {
				const { error } = await supabase.auth.exchangeCodeForSession(authCode);
				if (!active) return;
				if (error) {
					console.error("[Google OAuth] Callback exchange failed:", error.message);
					await Browser.close().catch(() => void 0);
					navigate({
						to: "/auth",
						replace: true
					});
					return;
				}
				completedOAuthCodes.add(authCode);
				await Browser.close().catch(() => void 0);
				if (active) navigate({
					to: "/",
					replace: true
				});
			} finally {
				inFlightOAuthCodes.delete(authCode);
			}
		};
		App.addListener("appUrlOpen", ({ url }) => {
			completeGoogleOAuth(url);
		}).then((listener) => {
			appUrlListener = listener;
			if (!active) listener.remove();
		});
		App.getLaunchUrl().then((launch) => {
			if (active && launch?.url) completeGoogleOAuth(launch.url);
		}).catch((error) => console.warn("[Google OAuth] Could not read launch URL:", error));
		return () => {
			active = false;
			if (appUrlListener) appUrlListener.remove();
		};
	}, [navigate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniRoomController, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
				position: "bottom-center",
				visibleToasts: 3,
				offset: 24
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppUpdateGate, {})
		]
	});
}
function MiniRoomController() {
	const { user } = useAuth();
	const navigate = useNavigate();
	const [active, setActive] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const read = () => {
			try {
				const raw = localStorage.getItem("vox_active_room");
				if (!raw) {
					setActive(null);
					return;
				}
				const parsed = JSON.parse(raw);
				if (!parsed.id) {
					setActive(null);
					return;
				}
				const minimized = localStorage.getItem("vox_minimized_room_id") === parsed.id || !window.location.pathname.startsWith(`/room/${parsed.id}`);
				setActive((current) => ({
					...parsed,
					minimized,
					members: current?.id === parsed.id ? current.members : [],
					musicFile: current?.id === parsed.id ? current.musicFile : null,
					musicCommand: current?.id === parsed.id ? current.musicCommand : null
				}));
			} catch {
				setActive(null);
			}
		};
		const onSession = (event) => {
			const detail = event.detail;
			if (!detail?.id || !detail.name) return;
			const persisted = {
				id: detail.id,
				name: detail.name,
				cover: detail.cover ?? null,
				micEnabled: !!detail.micEnabled
			};
			localStorage.setItem("vox_active_room", JSON.stringify(persisted));
			setActive((current) => ({
				...persisted,
				minimized: localStorage.getItem("vox_minimized_room_id") === detail.id,
				members: detail.members ?? current?.members ?? [],
				musicFile: detail.musicFile === void 0 ? current?.musicFile ?? null : detail.musicFile,
				musicCommand: detail.musicCommand === void 0 ? current?.musicCommand ?? null : detail.musicCommand
			}));
		};
		const onMin = () => read();
		const onMusicFile = (event) => {
			const file = event.detail?.file ?? null;
			setActive((current) => current ? {
				...current,
				musicFile: file
			} : current);
		};
		const onRestore = () => {
			setActive((current) => current ? {
				...current,
				minimized: false
			} : current);
		};
		const onClose = () => {
			localStorage.removeItem("vox_active_room");
			localStorage.removeItem("vox_minimized_room_id");
			localStorage.removeItem("vox_minimized_room");
			setActive(null);
		};
		read();
		window.addEventListener("vox-room-session", onSession);
		window.addEventListener("vox-room-music-file", onMusicFile);
		window.addEventListener("vox-room-minimized", onMin);
		window.addEventListener("vox-room-restored", onRestore);
		window.addEventListener("vox-room-closed", onClose);
		return () => {
			window.removeEventListener("vox-room-session", onSession);
			window.removeEventListener("vox-room-music-file", onMusicFile);
			window.removeEventListener("vox-room-minimized", onMin);
			window.removeEventListener("vox-room-restored", onRestore);
			window.removeEventListener("vox-room-closed", onClose);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!active?.id || !user?.id) return;
		let alive = true;
		const refreshRoomState = async () => {
			const { data: membership, error: memberError } = await supabase.from("room_members").select("user_id").eq("room_id", active.id).eq("user_id", user.id).maybeSingle();
			if (!alive || memberError) return;
			if (!membership) {
				localStorage.removeItem("vox_active_room");
				localStorage.removeItem("vox_minimized_room_id");
				localStorage.removeItem("vox_minimized_room");
				setActive(null);
				return;
			}
			const { data: seat } = await supabase.from("room_seats").select("user_id,is_muted").eq("room_id", active.id).eq("user_id", user.id).maybeSingle();
			if (!alive) return;
			setActive((current) => current?.id === active.id ? {
				...current,
				micEnabled: !!seat && !seat.is_muted && localStorage.getItem("vox_mic_permission_granted") === "1"
			} : current);
		};
		refreshRoomState();
		const channel = supabase.channel(`persistent-room-${active.id}-${user.id}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "room_members",
			filter: `room_id=eq.${active.id}`
		}, () => {
			refreshRoomState();
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "room_seats",
			filter: `room_id=eq.${active.id}`
		}, () => {
			refreshRoomState();
		}).subscribe();
		return () => {
			alive = false;
			supabase.removeChannel(channel);
		};
	}, [active?.id, user?.id]);
	if (!active || !user?.id) return null;
	const restore = () => {
		setActive((current) => current ? {
			...current,
			minimized: false
		} : current);
		window.dispatchEvent(new CustomEvent("vox-room-restored"));
		navigate({
			to: "/room/$id",
			params: { id: active.id }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: null,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniRoomVoice, {
			roomId: active.id,
			uid: user.id,
			members: active.members,
			micEnabled: !!active.micEnabled,
			musicFile: active.musicFile ?? null,
			musicCommand: active.musicCommand ?? null,
			onMusicProgress: (progress) => window.dispatchEvent(new CustomEvent("vox-room-music-progress", { detail: progress })),
			onSpeakingUsers: (users) => window.dispatchEvent(new CustomEvent("vox-room-speaking-users", { detail: users }))
		})
	}), active.minimized && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: restore,
		"aria-label": `العودة إلى غرفة ${active.name}`,
		title: `العودة إلى ${active.name}`,
		className: "fixed bottom-24 right-4 z-[120] flex h-16 w-16 items-center justify-center overflow-hidden rounded-full border-2 border-gold bg-black/80 shadow-2xl shadow-gold/30",
		children: [active.cover ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: active.cover,
			alt: active.name,
			className: "h-full w-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-2xl",
			children: "🎙️"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute bottom-0 left-1/2 -translate-x-1/2 rounded-full bg-gold px-1.5 py-0.5 text-[9px] font-black text-black",
			children: "الغرفة"
		})]
	})] });
}
var $$splitComponentImporter$13 = () => import("./auth-BxYHgzEH.mjs");
var Route$13 = createFileRoute("/auth")({
	head: () => ({ meta: [
		{ title: "تسجيل الدخول — صدى شات" },
		{
			name: "description",
			content: "سجّل دخولك إلى صدى شات للانضمام للغرف الصوتية."
		},
		{
			property: "og:title",
			content: "تسجيل الدخول — صدى شات"
		},
		{
			property: "og:description",
			content: "انضم للغرف الصوتية المباشرة."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./bag-sX0o5x04.mjs");
var Route$12 = createFileRoute("/bag")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./diamonds-D3xI7g6l.mjs");
var Route$11 = createFileRoute("/diamonds")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./families-CrpuetqR.mjs");
var Route$10 = createFileRoute("/families")({
	head: () => ({ meta: [
		{ title: "العائلات — صدى شات" },
		{
			name: "description",
			content: "أنشئ عائلتك أو انضم إلى عائلة وتنافس على النقاط."
		},
		{
			property: "og:title",
			content: "العائلات — صدى شات"
		},
		{
			property: "og:description",
			content: "عائلات صدى شات وترتيبها."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./help-B8olPXfl.mjs");
var Route$9 = createFileRoute("/help")({
	head: () => ({ meta: [
		{ title: "مركز الدعم — صدى شات" },
		{
			name: "description",
			content: "أرسل تذكرة دعم وتابع بلاغاتك وردود الإدارة."
		},
		{
			property: "og:title",
			content: "مركز الدعم — صدى شات"
		},
		{
			property: "og:description",
			content: "الدعم والبلاغات في صدى شات."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./level-D2FPi_Vt.mjs");
var Route$8 = createFileRoute("/level")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./messages-Dj6K7QkG.mjs");
var Route$7 = createFileRoute("/messages")({
	head: () => ({ meta: [
		{ title: "الدردشات — صدى شات" },
		{
			name: "description",
			content: "رسائلك الخاصة وإشعاراتك وأصدقاؤك."
		},
		{
			property: "og:title",
			content: "الدردشات — صدى شات"
		},
		{
			property: "og:description",
			content: "رسائلك الخاصة وإشعاراتك."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./moments-Dd4lITCM.mjs");
var Route$6 = createFileRoute("/moments")({
	head: () => ({ meta: [
		{ title: "اللحظات — صدى شات" },
		{
			name: "description",
			content: "شارك لحظاتك وصورك وتفاعل مع منشورات أصدقائك."
		},
		{
			property: "og:title",
			content: "اللحظات — صدى شات"
		},
		{
			property: "og:description",
			content: "شارك لحظاتك وتفاعل مع أصدقائك."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./notifications-DZ7qQWVm.mjs");
var Route$5 = createFileRoute("/notifications")({
	head: () => ({ meta: [
		{ title: "الإشعارات — صدى شات" },
		{
			name: "description",
			content: "إشعارات الإعجابات والمتابعات والهدايا والعائلة."
		},
		{
			property: "og:title",
			content: "الإشعارات — صدى شات"
		},
		{
			property: "og:description",
			content: "كل إشعاراتك في مكان واحد."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./profile-CQYGmq_y.mjs");
var Route$4 = createFileRoute("/profile")({
	head: () => ({ meta: [
		{ title: "ملفي الشخصي — صدى شات" },
		{
			name: "description",
			content: "ملفك الشخصي ومستواك ومحفظتك في صدى شات."
		},
		{
			property: "og:title",
			content: "ملفي الشخصي — صدى شات"
		},
		{
			property: "og:description",
			content: "ملفك الشخصي ومستواك ومحفظتك."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./reset-password-CzfBXxzY.mjs");
var Route$3 = createFileRoute("/reset-password")({
	head: () => ({ meta: [
		{ title: "كلمة مرور جديدة — صدى شات" },
		{
			name: "description",
			content: "عيّن كلمة مرور جديدة لحسابك."
		},
		{
			property: "og:title",
			content: "كلمة مرور جديدة — صدى شات"
		},
		{
			property: "og:description",
			content: "عيّن كلمة مرور جديدة لحسابك."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./store-CvbKElpt.mjs");
var Route$2 = createFileRoute("/store")({
	head: () => ({ meta: [
		{ title: "المتجر — صدى شات" },
		{
			name: "description",
			content: "شراء الإطارات والدخوليات وشحن العملات في صدى شات."
		},
		{
			property: "og:title",
			content: "المتجر — صدى شات"
		},
		{
			property: "og:description",
			content: "الإطارات والدخوليات وباقات الشحن."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./vip-D22B5qhq.mjs");
var Route$1 = createFileRoute("/vip")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./wallet-BH6uS7S0.mjs");
var Route = createFileRoute("/wallet")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$18.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$14
	}),
	AdminRoute: Route$15.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => Route$14
	}),
	AuthRoute: Route$13.update({
		id: "/auth",
		path: "/auth",
		getParentRoute: () => Route$14
	}),
	BagRoute: Route$12.update({
		id: "/bag",
		path: "/bag",
		getParentRoute: () => Route$14
	}),
	DiamondsRoute: Route$11.update({
		id: "/diamonds",
		path: "/diamonds",
		getParentRoute: () => Route$14
	}),
	FamiliesRoute: Route$10.update({
		id: "/families",
		path: "/families",
		getParentRoute: () => Route$14
	}),
	FriendsRoute: Route$17.update({
		id: "/friends",
		path: "/friends",
		getParentRoute: () => Route$14
	}),
	HelpRoute: Route$9.update({
		id: "/help",
		path: "/help",
		getParentRoute: () => Route$14
	}),
	LevelRoute: Route$8.update({
		id: "/level",
		path: "/level",
		getParentRoute: () => Route$14
	}),
	MessagesRoute: Route$7.update({
		id: "/messages",
		path: "/messages",
		getParentRoute: () => Route$14
	}),
	MomentsRoute: Route$6.update({
		id: "/moments",
		path: "/moments",
		getParentRoute: () => Route$14
	}),
	NotificationsRoute: Route$5.update({
		id: "/notifications",
		path: "/notifications",
		getParentRoute: () => Route$14
	}),
	ProfileRoute: Route$4.update({
		id: "/profile",
		path: "/profile",
		getParentRoute: () => Route$14
	}),
	ResetPasswordRoute: Route$3.update({
		id: "/reset-password",
		path: "/reset-password",
		getParentRoute: () => Route$14
	}),
	StoreRoute: Route$2.update({
		id: "/store",
		path: "/store",
		getParentRoute: () => Route$14
	}),
	VipRoute: Route$1.update({
		id: "/vip",
		path: "/vip",
		getParentRoute: () => Route$14
	}),
	WalletRoute: Route.update({
		id: "/wallet",
		path: "/wallet",
		getParentRoute: () => Route$14
	}),
	ChatIdRoute: Route$16.update({
		id: "/chat/$id",
		path: "/chat/$id",
		getParentRoute: () => Route$14
	}),
	RoomIdRoute: Route$19.update({
		id: "/room/$id",
		path: "/room/$id",
		getParentRoute: () => Route$14
	}),
	UIdRoute: Route$20.update({
		id: "/u/$id",
		path: "/u/$id",
		getParentRoute: () => Route$14
	})
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
