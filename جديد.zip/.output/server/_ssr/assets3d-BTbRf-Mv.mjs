import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assets3d-BTbRf-Mv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var DEVICE_STORAGE_KEY = "vox_royale_device_id";
var QUICK_LOGIN_PAUSED_KEY = "vox_guest_logged_out";
function isQuickLoginPaused() {
	try {
		return localStorage.getItem(QUICK_LOGIN_PAUSED_KEY) === "1";
	} catch {
		return false;
	}
}
function getDeviceId() {
	try {
		const existing = localStorage.getItem(DEVICE_STORAGE_KEY);
		if (existing && existing.length >= 16) return existing;
		const legacy = localStorage.getItem("vox_device_id");
		if (legacy && legacy.length >= 16) {
			localStorage.setItem(DEVICE_STORAGE_KEY, legacy);
			return legacy;
		}
		const id = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
		localStorage.setItem(DEVICE_STORAGE_KEY, id);
		return id;
	} catch {
		return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
	}
}
var cachedUser = null;
function useAuth() {
	const [user, setUser] = (0, import_react.useState)(() => isQuickLoginPaused() ? null : cachedUser);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		let authEventVersion = 0;
		const { data: subscription } = supabase.auth.onAuthStateChange((_event, session) => {
			authEventVersion += 1;
			cachedUser = session?.user ?? null;
			if (session?.user?.is_anonymous && session.refresh_token) try {
				localStorage.setItem("vox_guest_refresh", session.refresh_token);
				localStorage.setItem("vox_guest_account_created", "1");
			} catch (error) {
				console.warn("[Auth] Could not persist quick-login recovery token:", error);
			}
			if (mounted) {
				setUser(isQuickLoginPaused() ? null : cachedUser);
				setLoading(false);
			}
		});
		const onQuickLoginVisibilityChange = () => {
			if (isQuickLoginPaused()) {
				if (mounted) setUser(null);
				return;
			}
			supabase.auth.getSession().then(({ data }) => {
				if (!mounted) return;
				cachedUser = data.session?.user ?? null;
				setUser(cachedUser);
				setLoading(false);
			}).catch((error) => console.warn("[Auth] Could not refresh visible session:", error));
		};
		window.addEventListener("vox-auth-visibility-change", onQuickLoginVisibilityChange);
		const initialVersion = authEventVersion;
		supabase.auth.getSession().then(({ data, error }) => {
			if (!mounted || authEventVersion !== initialVersion) return;
			if (error) console.error("[Auth] Unable to restore session:", error.message);
			cachedUser = data.session?.user ?? null;
			if (data.session?.user?.is_anonymous && data.session.refresh_token) try {
				localStorage.setItem("vox_guest_refresh", data.session.refresh_token);
				localStorage.setItem("vox_guest_account_created", "1");
			} catch (persistError) {
				console.warn("[Auth] Could not persist quick-login recovery token:", persistError);
			}
			setUser(isQuickLoginPaused() ? null : cachedUser);
			setLoading(false);
		}).catch((error) => {
			if (!mounted || authEventVersion !== initialVersion) return;
			console.error("[Auth] Session restore failed:", error);
			cachedUser = null;
			setUser(null);
			setLoading(false);
		});
		return () => {
			mounted = false;
			subscription.subscription.unsubscribe();
			window.removeEventListener("vox-auth-visibility-change", onQuickLoginVisibilityChange);
		};
	}, []);
	return {
		user,
		loading
	};
}
var home_default = "/assets/home-CslZS9Il.png";
var explore_default = "/assets/explore-DyAAce_m.png";
var friends_default = "/assets/friends-CZ1OmZPd.png";
var messages_default = "/assets/messages-CE7iYHsK.png";
var profile_default = "/assets/profile-1jU5PF_u.png";
var store_default = "/assets/store-MJpuSzER.png";
var wallet_default = "/assets/wallet-DqNzQK2M.png";
var vip_default = "/assets/vip-DyAR4Uwx.png";
var family_default = "/assets/family-BvM15vCT.png";
var support_default = "/assets/support-7NmJg-J4.png";
var bell_default = "/assets/bell-BCVvmx1Q.png";
var gear_default = "/assets/gear-B9NL3_h-.png";
var search_default = "/assets/search-DZY5lTm5.png";
var giftbox_default = "/assets/giftbox-CQ4IOi8t.png";
var plus_default = "/assets/plus-BMSOuDBO.png";
var back_default = "/assets/back-Dg3-L873.png";
var share_default = "/assets/share-D83L6cd3.png";
var send_default = "/assets/send-DPH6sTIv.png";
var trash_default = "/assets/trash-Dktb-HiP.png";
var logout_default = "/assets/logout-CyJbqldm.png";
var rose_default = "/assets/rose-BJQiL5s3.png";
var heart_default = "/assets/heart-BuYkKnJb.png";
var crown_default = "/assets/crown-Cm86ECVz.png";
var ring_default = "/assets/ring-7Op1snYs.png";
var car_default = "/assets/car-2NzIQmoB.png";
var castle_default = "/assets/castle-DNlGknhQ.png";
var rocket_default = "/assets/rocket-Bv5PzRyD.png";
var chest_default = "/assets/chest-BdUIwVKu.png";
var mic_default = "/assets/mic-Dwrh68Ef.png";
var mic_host_default = "/assets/mic-host-CosVm9T7.png";
var mic_muted_default = "/assets/mic-muted-CY6KH7ws.png";
var mic_locked_default = "/assets/mic-locked-uDSbY1P0.png";
var diamond_default = "/assets/diamond-KBz7aKBB.png";
var coin_default = "/assets/coin-BJaq9zRh.png";
var vip_1_default = "/assets/vip-1-ccH9oVED.png";
var vip_2_default = "/assets/vip-2-C08gV04y.png";
var vip_3_default = "/assets/vip-3-BDdFfDR1.png";
var vip_4_default = "/assets/vip-4-DPHxPG1s.png";
var vip_5_default = "/assets/vip-5-BW8ZjjcD.png";
var vip_6_default = "/assets/vip-6-cVpGwUUN.png";
var level_1_default = "/assets/level-1-B_4BJHlI.png";
var level_2_default = "/assets/level-2-C833Ky6E.png";
var level_3_default = "/assets/level-3-DtGQ1Rkg.png";
var level_4_default = "/assets/level-4-CLEFTeka.png";
var level_5_default = "/assets/level-5-BBLsewFB.png";
var level_6_default = "/assets/level-6-Bq5OTDGz.png";
var room_royal_default = "/assets/room-royal-DMbwXmoq.jpg";
var room_tropical_default = "/assets/room-tropical-D2br8o9D.jpg";
var room_music_default = "/assets/room-music-BJDQmaHr.jpg";
var room_garden_default = "/assets/room-garden-93_kgPLL.jpg";
var icons3d = {
	home: home_default,
	explore: explore_default,
	friends: friends_default,
	messages: messages_default,
	profile: profile_default,
	store: store_default,
	wallet: wallet_default,
	vip: vip_default,
	family: family_default,
	support: support_default,
	bell: bell_default,
	gear: gear_default,
	search: search_default,
	giftbox: giftbox_default,
	plus: plus_default,
	back: back_default,
	share: share_default,
	send: send_default,
	trash: trash_default,
	logout: logout_default,
	rose: rose_default,
	heart: heart_default,
	crown: crown_default,
	ring: ring_default,
	car: car_default,
	castle: castle_default,
	rocket: rocket_default,
	chest: chest_default,
	mic: mic_default,
	diamond: diamond_default,
	coin: coin_default,
	agency: family_default,
	micHost: mic_host_default,
	micMuted: mic_muted_default,
	micLocked: mic_locked_default
};
var vips = [
	vip_1_default,
	vip_2_default,
	vip_3_default,
	vip_4_default,
	vip_5_default,
	vip_6_default
];
var levels = [
	level_1_default,
	level_2_default,
	level_3_default,
	level_4_default,
	level_5_default,
	level_6_default
];
function vipBadge(vip) {
	return vip > 0 ? vips[Math.min(5, Math.max(0, Math.floor(vip) - 1))] : void 0;
}
function levelBadge(level) {
	return levels[Math.min(5, Math.max(0, Math.floor((level - 1) / 10)))];
}
var roomThemes = [
	{
		id: "royal",
		name: "القصر الملكي",
		image: room_royal_default
	},
	{
		id: "tropical",
		name: "الجزيرة",
		image: room_tropical_default
	},
	{
		id: "music",
		name: "استوديو الموسيقى",
		image: room_music_default
	},
	{
		id: "garden",
		name: "الحديقة",
		image: room_garden_default
	}
];
function roomBackground(category) {
	return (roomThemes.find((t) => t.id === {
		music: "music",
		friends: "tropical",
		poetry: "garden"
	}[category]) ?? roomThemes[0])?.image ?? "/assets/room-royal-DMbwXmoq.jpg";
}
//#endregion
export { roomThemes as a, roomBackground as i, icons3d as n, useAuth as o, levelBadge as r, vipBadge as s, getDeviceId as t };
