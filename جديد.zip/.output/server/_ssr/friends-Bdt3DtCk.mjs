import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/friends-Bdt3DtCk.js
var $$splitComponentImporter = () => import("./friends-CP1PBzsJ.mjs");
var Route = createFileRoute("/friends")({
	head: () => ({ meta: [
		{ title: "الأصدقاء — صدى شات" },
		{
			name: "description",
			content: "أصدقاؤك ومتابعوك ومن تتابعهم وزوار ملفك."
		},
		{
			property: "og:title",
			content: "الأصدقاء — صدى شات"
		},
		{
			property: "og:description",
			content: "أصدقاؤك ومتابعوك."
		}
	] }),
	validateSearch: (s) => {
		const t = s["tab"];
		return t === "followers" || t === "following" || t === "visitors" || t === "friends" ? { tab: t } : {};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
