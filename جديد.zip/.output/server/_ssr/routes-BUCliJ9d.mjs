import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as DialogOverlay$1, c as DialogTrigger$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as roomBackground, n as icons3d } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as cn, t as Button } from "./button-DRsC1qZi.mjs";
import { n as getAdminAssetUrl } from "./media-BXNEENvw.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { a as errMsg, n as COUNTRIES, r as SEAT_OPTIONS, t as CATEGORIES } from "./vox-CkkqXMfh.mjs";
import { _ as createFileRoute, b as useNavigate, g as lazyRouteComponent, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as Search, V as Menu, W as Lock, Z as House, a as Users, d as Trophy, p as ThumbsUp, t as X } from "../_libs/lucide-react.mjs";
import { t as AdminAssetMedia } from "./AdminAssetMedia-CBSs12zp.mjs";
import { t as MediaImage } from "./UserAvatar-DvFPapaA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BUCliJ9d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogTrigger = DialogTrigger$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var $$splitComponentImporter = () => import("./routes-CnEF5zU7.mjs");
var Route = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "الغرف الصوتية — صدي شات" },
		{
			name: "description",
			content: "اكتشف الغرف الصوتية الشائعة والجديدة حسب الدولة والتصنيف."
		},
		{
			property: "og:title",
			content: "الغرف الصوتية — صدي شات"
		},
		{
			property: "og:description",
			content: "اكتشف الغرف الصوتية الشائعة والجديدة."
		}
	] }),
	validateSearch: (s) => s["create"] ? { create: 1 } : {},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var REGION_CHIPS = [
	{
		id: "all",
		label: "شائع",
		flag: null,
		hot: true
	},
	{
		id: "Arabia",
		label: "Arabia",
		flag: "🇸🇦"
	},
	{
		id: "YE",
		label: "Yemen",
		flag: "🇾🇪"
	},
	{
		id: "BD",
		label: "desh",
		flag: "🇧🇩"
	}
];
function HomeScreen({ createRequested = false }) {
	const [rooms, setRooms] = (0, import_react.useState)([]);
	const [tab, setTab] = (0, import_react.useState)("hot");
	const [region, setRegion] = (0, import_react.useState)("all");
	const [userIdSearch, setUserIdSearch] = (0, import_react.useState)("");
	const [appBranding, setAppBranding] = (0, import_react.useState)(null);
	const [logoUrl, setLogoUrl] = (0, import_react.useState)(null);
	const [introBanner, setIntroBanner] = (0, import_react.useState)(null);
	const [introBannerUrl, setIntroBannerUrl] = (0, import_react.useState)(null);
	const [showIntroBanner, setShowIntroBanner] = (0, import_react.useState)(false);
	const [roomBanners, setRoomBanners] = (0, import_react.useState)([]);
	const [bannerIndex, setBannerIndex] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let alive = true;
		let timer;
		async function loadBranding() {
			const { data, error } = await supabase.from("admin_settings").select("key,value").in("key", ["app_branding", "home_banner"]);
			if (error || !alive) return;
			const settings = Object.fromEntries((data ?? []).map((row) => [row.key, row.value]));
			const brand = settings.app_branding ?? {};
			const banner = settings.home_banner ?? {};
			setAppBranding(brand);
			setIntroBanner(banner);
			const resolveStorageImage = async (value) => {
				if (!value) return null;
				const resolved = await getAdminAssetUrl(value);
				if (resolved) return resolved;
				if (/^https?:\/\//i.test(value) || value.startsWith("media:")) return null;
				const { data } = await supabase.storage.from("admin-assets").createSignedUrl(value.replace(/^\/+/, ""), 3600);
				return data?.signedUrl ?? null;
			};
			if (brand.logo_path) {
				const resolved = await resolveStorageImage(brand.logo_path);
				if (alive) setLogoUrl(resolved);
			}
			if (banner.enabled !== false && banner.image_path && !sessionStorage.getItem("vox_intro_seen")) {
				const resolved = await resolveStorageImage(banner.image_path);
				if (alive && resolved) {
					sessionStorage.setItem("vox_intro_seen", "1");
					setIntroBannerUrl(resolved);
					setShowIntroBanner(true);
					timer = setTimeout(() => setShowIntroBanner(false), 5e3);
				}
			}
		}
		loadBranding();
		return () => {
			alive = false;
			if (timer) clearTimeout(timer);
		};
	}, []);
	async function loadBanners() {
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const { data, error } = await supabase.from("banners").select("id,title,image_url,target_url,sort_order,is_active,starts_at,ends_at").eq("is_active", true).order("sort_order").order("created_at", { ascending: false }).limit(20);
		if (error) {
			toast.error("تعذر تحميل البانرات: " + error.message);
			return;
		}
		const active = (data ?? []).filter((b) => (!b.starts_at || b.starts_at <= now) && (!b.ends_at || b.ends_at >= now));
		const resolved = await Promise.all(active.map(async (banner) => {
			const imageValue = (banner.image_url || "").trim();
			const resolvedUrl = await getAdminAssetUrl(imageValue);
			const fallbackUrl = imageValue.startsWith("https://") || imageValue.startsWith("http://") ? imageValue : null;
			const storagePath = imageValue.startsWith("media:") ? null : imageValue;
			const storageUrl = !resolvedUrl && !fallbackUrl && storagePath ? (await supabase.storage.from("admin-assets").createSignedUrl(storagePath.split("/").filter(Boolean).join("/"), 3600)).data?.signedUrl ?? null : null;
			return {
				...banner,
				resolved_image_url: resolvedUrl || fallbackUrl || storageUrl
			};
		}));
		setRoomBanners(resolved);
		setBannerIndex(0);
	}
	async function load() {
		const { data, error } = await supabase.from("rooms").select("*").limit(100);
		if (error) toast.error(error.message);
		else setRooms(data);
	}
	(0, import_react.useEffect)(() => {
		load();
		loadBanners();
		const channel = supabase.channel("home-room-list-live").on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "rooms"
		}, () => {
			load();
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "banners"
		}, () => {
			loadBanners();
		}).subscribe();
		return () => {
			supabase.removeChannel(channel);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (roomBanners.length < 2) return;
		const timer = window.setInterval(() => setBannerIndex((i) => (i + 1) % roomBanners.length), 5e3);
		return () => window.clearInterval(timer);
	}, [roomBanners.length]);
	const list = (0, import_react.useMemo)(() => {
		let filtered = rooms;
		if (region !== "all") filtered = rooms.filter((r) => r.country === region || r.name.toLowerCase().includes(region.toLowerCase()));
		return [...filtered].sort((a, b) => {
			const ao = Number(a.sort_order ?? 0), bo = Number(b.sort_order ?? 0);
			if (ao !== bo) return ao - bo;
			return tab === "hot" ? b.member_count - a.member_count : +new Date(b.created_at) - +new Date(a.created_at);
		});
	}, [
		rooms,
		tab,
		region
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-screen home-reference w-full pb-3 pt-2",
		style: { background: "linear-gradient(180deg, #e8f5e9 0%, #f1f8e9 30%, #f5f5f5 100%)" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 pt-3 pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "text-emerald-500",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {
								className: "h-7 w-7",
								fill: "currentColor"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/store",
							className: "text-amber-500",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "h-7 w-7" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {},
							className: "text-gray-700",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-7 w-7" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-5 text-lg font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gray-400",
						children: "ذات صلة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gray-900",
						children: "حفلة"
					})]
				})]
			}),
			showIntroBanner && introBannerUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[100] flex items-center justify-center bg-black/95 p-4",
				role: "dialog",
				"aria-label": "إعلان البداية",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full max-w-xl overflow-hidden rounded-3xl border border-gold/40 shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: introBannerUrl,
							alt: introBanner?.title || "بنر البداية",
							className: "max-h-[78vh] w-full object-contain"
						}),
						introBanner?.title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-5 pt-12 text-center text-xl font-bold text-white",
							children: introBanner.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowIntroBanner(false),
							className: "absolute right-3 top-3 rounded-full bg-black/70 px-4 py-2 text-sm text-white",
							children: "تخطي"
						})
					]
				})
			}),
			roomBanners.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-3 mb-3 overflow-hidden rounded-2xl shadow-lg",
				children: (() => {
					const banner = roomBanners[bannerIndex];
					if (!banner) return null;
					const content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative h-36 w-full",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: banner.resolved_image_url || "",
								alt: banner.title,
								className: "absolute inset-0 h-full w-full object-cover"
							}),
							banner.title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent px-4 pb-3 pt-10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-bold text-white",
									children: banner.title
								})
							}),
							roomBanners.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-1.5",
								children: roomBanners.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 rounded-full ${i === bannerIndex ? "w-5 bg-white" : "w-1.5 bg-white/50"}` }, b.id))
							})
						]
					});
					return banner.target_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: banner.target_url,
						target: "_blank",
						rel: "noreferrer",
						children: content
					}) : content;
				})()
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-3 mb-3 h-36 overflow-hidden rounded-2xl shadow-lg",
				style: { background: "linear-gradient(135deg, #6a1b9a, #1a237e, #4a148c)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full items-center justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-4xl font-black text-yellow-400",
						style: { textShadow: "0 0 20px rgba(255,215,0,0.6)" },
						children: "PK BATTLE"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mb-3 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-2xl p-3",
					style: { background: "linear-gradient(135deg, #e3f2fd, #bbdefb)" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute left-2 top-1 text-2xl opacity-30",
							children: "⟡"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute right-2 top-1 text-2xl opacity-30",
							children: "⟡"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-center text-lg font-bold text-blue-700",
							children: "Agency"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex justify-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-12 rounded-full border-2 border-slate-400 bg-slate-200" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-12 rounded-full border-2 border-amber-500 bg-amber-100" })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-2xl p-3",
					style: { background: "linear-gradient(135deg, #fff8e1, #ffe0b2)" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute left-2 top-1 text-2xl opacity-30",
							children: "⟡"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute right-2 top-1 text-2xl opacity-30",
							children: "⟡"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-center text-lg font-bold text-amber-700",
							children: "Wealth"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex justify-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-12 rounded-full border-2 border-amber-500 bg-amber-100" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-12 rounded-full border-2 border-slate-400 bg-slate-200" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-12 rounded-full border-2 border-amber-500 bg-amber-100" })
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center gap-2 overflow-x-auto px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "rounded-full p-2 text-gray-600",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
				}), REGION_CHIPS.map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setRegion(chip.id),
					className: `flex shrink-0 items-center gap-1.5 rounded-full px-4 py-1.5 text-sm font-bold ${region === chip.id ? "bg-emerald-500 text-white" : "bg-white text-gray-700 shadow-sm"}`,
					children: [
						chip.flag && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: chip.flag }),
						chip.label,
						chip.hot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: "h-3.5 w-3.5" })
					]
				}, chip.id))]
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-3 rounded-2xl bg-white p-10 text-center text-gray-500 shadow-sm",
				children: "لا توجد غرف بعد — أنشئ أول غرفة!"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 px-3",
				children: list.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/room/$id",
					params: { id: r.id },
					className: "group relative aspect-[3/4] overflow-hidden rounded-2xl shadow-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaImage, {
							src: r.cover_url || roomBackground(r.category),
							className: "absolute inset-0 h-full w-full object-cover"
						}),
						r.room_frame_asset_key && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomFrameOverlay, { assetKey: r.room_frame_asset_key }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute right-2 top-2 rounded-full bg-black/40 px-2 py-0.5 text-xs text-white backdrop-blur",
							children: r.category === "music" ? "Music" : "Party"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-x-0 bottom-0 p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-center text-base font-bold text-white",
								children: r.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 flex items-center justify-center gap-1 text-xs text-white/90",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3 w-3" }), r.member_count]
								})
							})]
						}),
						r.is_private && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "absolute left-2 top-2 h-4 w-4 text-white/80" })
					]
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed bottom-24 left-4 z-30",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateRoom, { createRequested })
			})
		]
	});
}
function RoomFrameOverlay({ assetKey }) {
	const [src, setSrc] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getAdminAssetUrl(assetKey).then(setSrc);
	}, [assetKey]);
	return src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
		src,
		className: "pointer-events-none absolute inset-0 z-10 h-full w-full object-fill"
	}) : null;
}
function CreateRoom({ createRequested = false }) {
	const nav = useNavigate();
	const [open, setOpen] = (0, import_react.useState)(createRequested);
	(0, import_react.useEffect)(() => {
		if (createRequested) setOpen(true);
	}, [createRequested]);
	const [name, setName] = (0, import_react.useState)("");
	const [desc, setDesc] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("chat");
	const [country, setCountry] = (0, import_react.useState)("EG");
	const [seats, setSeats] = (0, import_react.useState)(8);
	const [priv, setPriv] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function create(e) {
		e.preventDefault();
		setBusy(true);
		const { data, error } = await supabase.rpc("create_room", {
			_name: name,
			_description: desc,
			_category: category,
			_country: country,
			_seat_count: seats,
			_is_private: priv
		});
		setBusy(false);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		setOpen(false);
		nav({
			to: "/room/$id",
			params: { id: data }
		});
	}
	const sel = "w-full rounded-md border border-input bg-input px-3 py-2 text-sm";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: (next) => {
			setOpen(next);
			if (!next && createRequested) nav({
				to: "/",
				search: {}
			});
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				className: "bg-gold rounded-full font-bold shadow-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: icons3d.plus,
					alt: "",
					className: "h-6 w-6 object-contain"
				}), " غرفة"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			dir: "rtl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-display text-gold",
				children: "إنشاء غرفة"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: create,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "اسم الغرفة",
						required: true,
						minLength: 2,
						maxLength: 40,
						value: name,
						onChange: (e) => setName(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "وصف (اختياري)",
						maxLength: 300,
						value: desc,
						onChange: (e) => setDesc(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: sel,
							value: category,
							onChange: (e) => setCategory(e.target.value),
							children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.id,
								children: c.name
							}, c.id))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: sel,
							value: country,
							onChange: (e) => setCountry(e.target.value),
							children: COUNTRIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: c.code,
								children: [
									c.flag,
									" ",
									c.name
								]
							}, c.code))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-1 text-sm text-muted-foreground",
						children: "عدد المقاعد"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: SEAT_OPTIONS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSeats(n),
							className: `h-10 w-12 rounded-xl font-bold ${seats === n ? "bg-gold" : "glass"}`,
							children: n
						}, n))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: priv,
							onChange: (e) => setPriv(e.target.checked)
						}), " غرفة خاصة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						className: "w-full bg-gold font-bold",
						children: "إنشاء"
					})
				]
			})]
		})]
	});
}
//#endregion
export { DialogTrigger as a, DialogTitle as i, DialogContent as n, HomeScreen as o, DialogHeader as r, Route as s, Dialog as t };
