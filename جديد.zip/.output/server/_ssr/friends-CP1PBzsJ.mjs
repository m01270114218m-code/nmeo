import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as Search, a as Users, c as UserPlus, ot as Eye, s as UserRound } from "../_libs/lucide-react.mjs";
import { n as PageHeader, t as AppShell } from "./AppShell-CNN_t4M1.mjs";
import { n as UserAvatar } from "./UserAvatar-DvFPapaA.mjs";
import { t as Route } from "./friends-Bdt3DtCk.mjs";
import { t as IdentityBadges } from "./IdentityBadges-CjJBvqnl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/friends-CP1PBzsJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		id: "friends",
		label: "أصدقاء"
	},
	{
		id: "followers",
		label: "المتابِعون"
	},
	{
		id: "following",
		label: "أتابعهم"
	},
	{
		id: "visitors",
		label: "الزوار"
	}
];
function Friends() {
	const { user } = useAuth();
	const uid = user.id;
	const search = Route.useSearch();
	const [tab, setTab] = (0, import_react.useState)(search.tab ?? "friends");
	const [list, setList] = (0, import_react.useState)([]);
	const [query, setQuery] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let active = true;
		async function load() {
			setLoading(true);
			try {
				let ids = [];
				if (tab === "visitors") {
					const { data } = await supabase.from("profile_visits").select("visitor_id").eq("profile_id", uid).order("visited_at", { ascending: false }).limit(100);
					ids = (data ?? []).map((d) => d.visitor_id);
				} else {
					const [{ data: ers }, { data: ing }] = await Promise.all([supabase.from("follows").select("follower_id").eq("following_id", uid), supabase.from("follows").select("following_id").eq("follower_id", uid)]);
					const followers = new Set((ers ?? []).map((x) => x.follower_id));
					const following = new Set((ing ?? []).map((x) => x.following_id));
					ids = tab === "followers" ? [...followers] : tab === "following" ? [...following] : [...followers].filter((id) => following.has(id));
				}
				const uniqueIds = [...new Set(ids)].filter((id) => id !== uid);
				if (!uniqueIds.length) {
					if (active) setList([]);
					return;
				}
				const { data } = await supabase.from("profiles").select("id,display_name,avatar_url,level,vip_level").in("id", uniqueIds);
				if (active) {
					const byId = new Map((data ?? []).map((profile) => [profile.id, profile]));
					setList(uniqueIds.map((id) => byId.get(id)).filter((profile) => !!profile));
				}
			} finally {
				if (active) setLoading(false);
			}
		}
		const channel = supabase.channel(`friends-list-live-${uid}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "follows",
			filter: `following_id=eq.${uid}`
		}, () => {
			load();
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "follows",
			filter: `follower_id=eq.${uid}`
		}, () => {
			load();
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "profile_visits",
			filter: `profile_id=eq.${uid}`
		}, () => {
			load();
		}).subscribe();
		load();
		return () => {
			active = false;
			supabase.removeChannel(channel);
		};
	}, [tab, uid]);
	const filteredList = list.filter((profile) => profile.display_name.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
	const activeTab = TABS.find((item) => item.id === tab) ?? TABS[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "social-list-reference friends-list-reference",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "الأصدقاء",
				back: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "social-list-toolbar mx-4 mb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "social-list-feature-icon",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(tab === "visitors" ? Eye : tab === "friends" ? Users : tab === "following" ? UserPlus : UserRound, { className: "h-5 w-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "social-list-kicker",
									children: "VOX ROYALE · SOCIAL"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "social-list-title",
									children: activeTab.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "تابع مجتمعك وتواصل مع أصدقائك"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "social-list-count",
							children: filteredList.length
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "social-list-search",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "ابحث بالاسم...",
						"aria-label": "ابحث بالاسم"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "social-tab-rail mx-4 mb-4",
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": tab === t.id,
					onClick: () => setTab(t.id),
					className: "social-tab-button",
					children: t.label
				}, t.id))
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-10 text-center text-sm text-muted-foreground",
				children: "جارٍ تحميل القائمة..."
			}) : filteredList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "social-empty mx-4 py-10 text-center text-sm text-muted-foreground",
				children: query.trim() ? "لا توجد نتائج مطابقة للبحث" : "القائمة فارغة حاليًا"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 px-4",
				children: filteredList.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/u/$id",
					params: { id: p.id },
					className: "social-person-row glass card-3d flex items-center gap-3 rounded-2xl p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
							src: p.avatar_url,
							name: p.display_name,
							size: 56,
							vip: p.vip_level
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate font-bold",
								children: p.display_name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityBadges, {
								level: p.level,
								vip: p.vip_level
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "social-person-arrow",
							children: "‹"
						})
					]
				}, p.id))
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Friends, {}) });
//#endregion
export { SplitComponent as component };
