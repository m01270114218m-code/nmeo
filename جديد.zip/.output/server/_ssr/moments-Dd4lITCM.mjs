import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as icons3d, o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { i as uploadImage } from "./media-BXNEENvw.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { a as errMsg, o as flagOf } from "./vox-CkkqXMfh.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as MessageCircle, Q as Heart, Y as ImagePlus, f as Trash2, rt as Flag } from "../_libs/lucide-react.mjs";
import { n as PageHeader, t as AppShell } from "./AppShell-CNN_t4M1.mjs";
import { n as UserAvatar, t as MediaImage } from "./UserAvatar-DvFPapaA.mjs";
import { t as IdentityBadges } from "./IdentityBadges-CjJBvqnl.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/moments-Dd4lITCM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Moments() {
	const { user } = useAuth();
	const uid = user.id;
	const [tab, setTab] = (0, import_react.useState)("all");
	const [posts, setPosts] = (0, import_react.useState)([]);
	const [liked, setLiked] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [following, setFollowing] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [body, setBody] = (0, import_react.useState)("");
	const [file, setFile] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [openComments, setOpenComments] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	async function load() {
		const { data: f } = await supabase.from("follows").select("following_id").eq("follower_id", uid);
		const fset = new Set((f ?? []).map((x) => x.following_id));
		setFollowing(fset);
		let q = supabase.from("posts").select("*, profiles!posts_user_id_fkey(display_name,avatar_url,country,level,vip_level)").order("created_at", { ascending: false }).limit(50);
		if (tab === "following") q = q.in("user_id", [...fset, uid]);
		const { data, error } = await q;
		if (error) {
			toast.error(error.message);
			return;
		}
		setPosts(data ?? []);
		const ids = (data ?? []).map((p) => p.id);
		if (ids.length) {
			const { data: l } = await supabase.from("post_likes").select("post_id").eq("user_id", uid).in("post_id", ids);
			setLiked(new Set((l ?? []).map((x) => x.post_id)));
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [tab]);
	async function publish() {
		if (!body.trim() && !file) return;
		setBusy(true);
		try {
			const image_url = file ? await uploadImage(file, uid) : null;
			const { error } = await supabase.from("posts").insert({
				user_id: uid,
				body: body.trim().slice(0, 1e3),
				image_url
			});
			if (error) throw error;
			setBody("");
			setFile(null);
			toast.success("تم النشر");
			load();
		} catch (e) {
			toast.error(errMsg(e));
		} finally {
			setBusy(false);
		}
	}
	async function toggleLike(p) {
		const isLiked = liked.has(p.id);
		const next = new Set(liked);
		isLiked ? next.delete(p.id) : next.add(p.id);
		setLiked(next);
		setPosts((ps) => ps.map((x) => x.id === p.id ? {
			...x,
			like_count: x.like_count + (isLiked ? -1 : 1)
		} : x));
		const { error } = isLiked ? await supabase.from("post_likes").delete().eq("post_id", p.id).eq("user_id", uid) : await supabase.from("post_likes").insert({
			post_id: p.id,
			user_id: uid
		});
		if (error) toast.error(error.message);
	}
	async function follow(id) {
		const { error } = await supabase.from("follows").insert({
			follower_id: uid,
			following_id: id
		});
		if (error) {
			toast.error(error.message);
			return;
		}
		setFollowing((s) => new Set(s).add(id));
	}
	async function remove(id) {
		if (!confirm("حذف المنشور؟")) return;
		const { error } = await supabase.from("posts").delete().eq("id", id);
		if (error) {
			toast.error(error.message);
			return;
		}
		setPosts((ps) => ps.filter((p) => p.id !== id));
	}
	async function report(id) {
		const { error } = await supabase.rpc("submit_report", {
			_type: "post",
			_target: id,
			_category: "محتوى غير لائق",
			_details: ""
		});
		if (error) toast.error(errMsg(error));
		else toast.success("تم إرسال البلاغ للإدارة");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "اللحظات" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex gap-2 px-4",
			children: ["all", "following"].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setTab(t),
				className: `rounded-full px-4 py-1.5 text-sm font-bold ${tab === t ? "bg-gold" : "glass text-muted-foreground"}`,
				children: t === "all" ? "الحالة" : "أتابعهم"
			}, t))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass mx-4 mb-4 space-y-2 rounded-3xl p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: body,
					onChange: (e) => setBody(e.target.value),
					maxLength: 1e3,
					placeholder: "بماذا تفكر؟",
					className: "min-h-16 border-0 bg-transparent"
				}),
				file && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-primary",
					children: [
						"📷 ",
						file.name,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setFile(null),
							className: "text-destructive",
							children: "✕"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => fileRef.current?.click(),
							className: "flex items-center gap-1 text-sm text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-5 w-5" }), " صورة"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "image/*",
							hidden: true,
							onChange: (e) => setFile(e.target.files?.[0] ?? null)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							disabled: busy || !body.trim() && !file,
							onClick: publish,
							className: "bg-gold font-bold",
							children: "نشر"
						})
					]
				})
			]
		}),
		posts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "glass mx-4 rounded-3xl p-10 text-center text-muted-foreground",
			children: "لا توجد منشورات بعد"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3 px-4",
			children: posts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "glass rounded-3xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/u/$id",
								params: { id: p.user_id },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
									src: p.profiles?.avatar_url,
									name: p.profiles?.display_name,
									size: 52,
									vip: p.profiles?.vip_level
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/u/$id",
									params: { id: p.user_id },
									className: "block truncate font-bold",
									children: p.profiles?.display_name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex gap-1 text-[10px]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityBadges, {
										level: p.profiles?.level,
										vip: p.profiles?.vip_level
									})
								})]
							}),
							p.user_id !== uid && !following.has(p.user_id) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => follow(p.user_id),
								children: "+ متابعة"
							})
						]
					}),
					p.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 whitespace-pre-wrap leading-relaxed",
						children: p.body
					}),
					p.image_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaImage, {
						src: p.image_url,
						className: "mt-3 max-h-96 w-full rounded-2xl object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 text-xs text-muted-foreground",
						children: [
							new Date(p.created_at).toLocaleString("ar-EG"),
							" · ",
							flagOf(p.profiles?.country)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-5 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => toggleLike(p),
								className: `flex items-center gap-1 ${liked.has(p.id) ? "text-destructive" : ""}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: `h-5 w-5 ${liked.has(p.id) ? "fill-current" : ""}` }), p.like_count]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setOpenComments(openComments === p.id ? null : p.id),
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-5 w-5" }), p.comment_count]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1" }),
							p.user_id === uid ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => remove(p.id),
								"aria-label": "حذف",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4 text-muted-foreground" })
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => report(p.id),
								"aria-label": "إبلاغ",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "h-4 w-4 text-muted-foreground" })
							})
						]
					}),
					openComments === p.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comments, {
						postId: p.id,
						onAdded: () => setPosts((ps) => ps.map((x) => x.id === p.id ? {
							...x,
							comment_count: x.comment_count + 1
						} : x))
					})
				]
			}, p.id))
		})
	] });
}
function Comments({ postId, onAdded }) {
	const { user } = useAuth();
	const [items, setItems] = (0, import_react.useState)([]);
	const [text, setText] = (0, import_react.useState)("");
	async function load() {
		const { data } = await supabase.from("post_comments").select("id,user_id,body,created_at,profiles(display_name)").eq("post_id", postId).order("created_at").limit(100);
		setItems(data ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [postId]);
	async function add(e) {
		e.preventDefault();
		if (!text.trim()) return;
		const { error } = await supabase.from("post_comments").insert({
			post_id: postId,
			user_id: user.id,
			body: text.trim().slice(0, 300)
		});
		if (error) {
			toast.error(error.message);
			return;
		}
		setText("");
		onAdded();
		load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 space-y-2 border-t border-border pt-3",
		children: [items.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-bold text-primary",
				children: [c.profiles?.display_name, ": "]
			}), c.body]
		}, c.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: add,
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: text,
				onChange: (e) => setText(e.target.value),
				maxLength: 300,
				placeholder: "اكتب تعليقاً…"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "icon",
				className: "bg-gold",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: icons3d.send,
					alt: "",
					className: "h-6 w-6 object-contain"
				})
			})]
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moments, {}) });
//#endregion
export { SplitComponent as component };
