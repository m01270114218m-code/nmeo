import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as errMsg } from "./vox-CkkqXMfh.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { gt as ChevronLeft, h as Star, o as User } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-CNN_t4M1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wallet-BH6uS7S0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COIN_PACKS = [
	{
		coins: 1e5,
		price: "$9.99"
	},
	{
		coins: 5e4,
		price: "$4.99"
	},
	{
		coins: 6,
		price: "$0.99"
	},
	{
		coins: 5e5,
		price: "$49.99"
	},
	{
		coins: 2e5,
		price: "$19.99"
	}
];
function WalletPage() {
	const { user } = useAuth();
	const nav = useNavigate();
	const [coins, setCoins] = (0, import_react.useState)(0);
	const [name, setName] = (0, import_react.useState)("");
	const [selectedPack, setSelectedPack] = (0, import_react.useState)(2);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		Promise.all([supabase.from("wallets").select("coins").eq("user_id", user.id).maybeSingle(), supabase.from("profiles").select("display_name").eq("id", user.id).single()]).then(([w, p]) => {
			setCoins(Number(w.data?.coins ?? 0));
			setName(p.data?.display_name ?? "");
		});
	}, [user]);
	async function recharge() {
		const pack = COIN_PACKS[selectedPack];
		const { error } = await supabase.rpc("request_wallet_topup", {
			_coins: pack.coins,
			_payment_method: "manual"
		});
		if (error) toast.error(errMsg(error));
		else toast.success("تم إرسال طلب الشحن للإدارة");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "min-h-screen pb-8",
		style: { background: "#f5f5f5" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center justify-between bg-white px-4 py-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => nav({ to: "/profile" }),
						className: "rounded-full p-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-7 w-7 text-gray-700" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-bold text-gray-900",
						children: "إعادة الشحن"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-7" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mt-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-12 w-12 items-center justify-center rounded-full bg-gray-200",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-6 w-6 text-gray-500" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold text-gray-900",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 text-sm text-emerald-600",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
								className: "h-4 w-4",
								fill: "currentColor"
							}),
							" ",
							coins.toLocaleString(),
							" الرصيد"
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "rounded-full border-2 border-emerald-500 px-4 py-1.5 text-sm font-bold text-emerald-600",
					children: "إعادة شحن التاجر"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-3 mt-4 overflow-hidden rounded-2xl p-5",
				style: { background: "linear-gradient(135deg, #3b82f6, #06b6d4)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-2xl font-black text-white",
						children: "New User Exclusive"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xl font-black text-yellow-300",
						children: "Pack Up To 25x Rewards!"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-6xl",
						children: "💎"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-right text-lg font-bold text-gray-900",
					children: "مبلغ الدفع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-3",
					children: COIN_PACKS.map((pack, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setSelectedPack(i),
						className: `flex flex-col items-center gap-1 rounded-2xl p-4 ${selectedPack === i ? "bg-emerald-50 ring-2 ring-emerald-500" : "bg-white"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
								className: "h-8 w-8 text-yellow-500",
								fill: "currentColor"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xl font-bold text-gray-900",
								children: pack.coins.toLocaleString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-emerald-100 px-3 py-0.5 text-sm font-bold text-emerald-600",
								children: pack.price
							})
						]
					}, i))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => void recharge(),
					className: "w-full rounded-2xl bg-emerald-500 py-4 text-xl font-bold text-white",
					children: ["الدفع ", COIN_PACKS[selectedPack].price]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-sm text-gray-500",
					children: "الدفع يعني أنك وافقت اتفاقية إعادة الشحن"
				})]
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletPage, {}) });
//#endregion
export { SplitComponent as component };
