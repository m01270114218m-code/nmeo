import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat._id-Bdxvg7zy.js
var $$splitComponentImporter = () => import("./chat._id-Stt3mNPH.mjs");
var Route = createFileRoute("/chat/$id")({
	head: () => ({ meta: [
		{ title: "محادثة خاصة — صدى شات" },
		{
			name: "description",
			content: "محادثة خاصة مباشرة."
		},
		{
			property: "og:title",
			content: "محادثة خاصة — صدى شات"
		},
		{
			property: "og:description",
			content: "محادثة خاصة مباشرة."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
