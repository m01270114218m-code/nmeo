import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/client-BLH0g87i.js
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function serverSupabaseUrl(publicUrl, supabaseKey) {
	if (typeof window !== "undefined" || typeof process === "undefined") return void 0;
	const serverUrl = process.env["SUPABASE_URL"]?.replace(/\/+$/, "");
	if (!serverUrl || serverUrl === publicUrl || process.env["SUPABASE_PUBLISHABLE_KEY"] !== supabaseKey) return void 0;
	return serverUrl;
}
function createSupabaseFetch(supabaseUrl, supabaseKey) {
	const publicUrl = supabaseUrl.replace(/\/+$/, "");
	const serverUrl = serverSupabaseUrl(publicUrl, supabaseKey);
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		headers.set("x-app-version", APP_VERSION);
		if (serverUrl) {
			const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
			if (url.startsWith(`${publicUrl}/`)) {
				const target = serverUrl + url.slice(publicUrl.length);
				const request = typeof input === "string" || input instanceof URL ? target : new Request(target, input);
				return fetch(request, {
					...init,
					headers
				});
			}
		}
		return fetch(input, {
			...init,
			headers
		});
	};
}
var APP_VERSION = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "gxkdptwkyhwbxyaspagd",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tLtMpyWHcotmyTpaToTNYQ_M2sWXk1r",
	"VITE_SUPABASE_URL": "https://gxkdptwkyhwbxyaspagd.supabase.co"
}["VITE_APP_VERSION"] || "2.0.1";
function createSupabaseClient() {
	const SUPABASE_URL = {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "gxkdptwkyhwbxyaspagd",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tLtMpyWHcotmyTpaToTNYQ_M2sWXk1r",
		"VITE_SUPABASE_URL": "https://gxkdptwkyhwbxyaspagd.supabase.co"
	}["VITE_SUPABASE_URL"] || process.env["SUPABASE_URL"];
	const SUPABASE_PUBLISHABLE_KEY = {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "gxkdptwkyhwbxyaspagd",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tLtMpyWHcotmyTpaToTNYQ_M2sWXk1r",
		"VITE_SUPABASE_URL": "https://gxkdptwkyhwbxyaspagd.supabase.co"
	}["VITE_SUPABASE_PUBLISHABLE_KEY"] || process.env["SUPABASE_PUBLISHABLE_KEY"];
	if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
		const message = `Missing Supabase environment variable(s): ${[...!SUPABASE_URL ? ["SUPABASE_URL"] : [], ...!SUPABASE_PUBLISHABLE_KEY ? ["SUPABASE_PUBLISHABLE_KEY"] : []].join(", ")}. Configure the production Supabase URL and publishable key for VOX ROYALE.`;
		console.error(`[Supabase] ${message}`);
		throw new Error(message);
	}
	return createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
		global: { fetch: createSupabaseFetch(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY) },
		auth: {
			flowType: "pkce",
			persistSession: true,
			autoRefreshToken: true,
			detectSessionInUrl: true
		}
	});
}
var _supabase;
var supabase = new Proxy({}, { get(_, prop, receiver) {
	if (!_supabase) _supabase = createSupabaseClient();
	return Reflect.get(_supabase, prop, receiver);
} });
//#endregion
export { supabase as t };
