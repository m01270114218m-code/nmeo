import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { a as errMsg } from "./vox-CkkqXMfh.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { dt as Diamond, gt as ChevronLeft, h as Star } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-CNN_t4M1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/diamonds-D3xI7g6l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COIN_PACKS = [
	{
		coins: 200,
		diamonds: 220
	},
	{
		coins: 111,
		diamonds: 11
	},
	{
		coins: 10,
		diamonds: 12
	},
	{
		coins: 100,
		diamonds: 120
	},
	{
		coins: 150,
		diamonds: 170
	}
];
function DiamondsPage() {
	const { user } = useAuth();
	const nav = useNavigate();
	const [diamonds, setDiamonds] = (0, import_react.useState)(0);
	const [coins, setCoins] = (0, import_react.useState)(0);
	const [diamondInput, setDiamondInput] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function load() {
		if (!user) return;
		const { data: w } = await supabase.from("wallets").select("coins,diamonds").eq("user_id", user.id).maybeSingle();
		setDiamonds(Number(w?.diamonds ?? 0));
		setCoins(Number(w?.coins ?? 0));
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [user]);
	async function convert(pack) {
		const d = pack?.diamonds ?? (Number(diamondInput) || 0);
		if (d <= 0 || d > diamonds) {
			toast.error("رصيد الألماس غير كافٍ");
			return;
		}
		const c = pack?.coins ?? Math.floor(d * 1.2);
		setBusy(true);
		const { error } = await supabase.rpc("convert_diamonds_to_coins", { _diamonds: d });
		setBusy(false);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success(`تم تحويل ${d} ألماس إلى ${c} عملة`);
		await load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "min-h-screen pb-8",
		style: { background: "#f0fdf4" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center justify-between bg-white px-4 py-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => nav({ to: "/profile" }),
						className: "rounded-full p-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-7 w-7 text-gray-700" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-bold text-gray-900",
						children: "تبادل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-7" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-3 mt-3 overflow-hidden rounded-2xl p-4",
				style: { background: "linear-gradient(135deg, #3b82f6, #06b6d4)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm opacity-90",
							children: "ادفع من خلال المشاركة أو رحلة الهدايا"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-16 w-16 items-center justify-center rounded-full bg-yellow-400 text-2xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
								className: "h-10 w-10 text-white",
								fill: "currentColor"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -bottom-1 -right-1 rounded-full bg-white px-2 text-sm font-bold text-gray-900",
							children: "Coin"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mt-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-2xl",
						children: "💎"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-2xl font-bold text-gray-900",
						children: diamonds.toFixed(2)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-lg font-bold text-gray-900",
						children: "تبادل"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-5 w-1 bg-emerald-500" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-3 mt-4 grid grid-cols-3 gap-3",
				children: COIN_PACKS.map((pack, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => void convert(pack),
					disabled: busy || diamonds < pack.diamonds,
					className: "flex flex-col items-center gap-2 rounded-2xl bg-emerald-50 p-4 disabled:opacity-50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-14 w-14 items-center justify-center rounded-full bg-yellow-100",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
								className: "h-8 w-8 text-yellow-500",
								fill: "currentColor"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xl font-bold text-gray-900",
							children: pack.coins
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1 rounded-full bg-emerald-400 px-3 py-1 text-sm font-bold text-white",
							children: [
								pack.diamonds,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diamond, { className: "h-3.5 w-3.5" })
							]
						})
					]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mt-6 rounded-2xl bg-white p-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-3 text-center text-lg font-bold text-emerald-600",
						children: "100 Diamonds = 120 Coin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 rounded-xl bg-gray-50 px-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 text-gray-500",
									children: "أدخل عدد الألماس ×100"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: diamondInput,
									onChange: (e) => setDiamondInput(e.target.value),
									placeholder: "0",
									className: "w-24 border-0 bg-transparent text-left text-lg font-bold"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diamond, { className: "h-6 w-6 text-cyan-500" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 rounded-xl bg-gray-50 px-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 text-gray-500",
									children: "احصل على عدد العملات"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg font-bold text-gray-900",
									children: Math.floor((Number(diamondInput) || 0) * 1.2)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
									className: "h-6 w-6 text-yellow-500",
									fill: "currentColor"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => void convert(),
						disabled: busy || !diamondInput || Number(diamondInput) <= 0,
						className: "mt-4 w-full rounded-xl bg-emerald-500 py-3 font-bold text-white disabled:opacity-50",
						children: busy ? "جارٍ التحويل…" : "تحويل"
					})
				]
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiamondsPage, {}) });
//#endregion
export { SplitComponent as component };
