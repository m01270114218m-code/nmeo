import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { a as useAdminAsset, i as uploadImage } from "./media-BXNEENvw.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { a as errMsg, n as COUNTRIES, o as flagOf } from "./vox-CkkqXMfh.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { $ as Gift, H as Mail, Q as Heart, T as Settings, a as Users, ft as Crown, gt as ChevronLeft, h as Star, x as ShoppingBag, xt as Camera } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-CNN_t4M1.mjs";
import { n as UserAvatar } from "./UserAvatar-DvFPapaA.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-CQYGmq_y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const { user } = useAuth();
	const nav = useNavigate();
	const [p, setP] = (0, import_react.useState)(null);
	const [equippedBadges, setEquippedBadges] = (0, import_react.useState)([]);
	useAdminAsset(p?.profile_card_asset_key);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [stats, setStats] = (0, import_react.useState)({
		followers: 0,
		friends: 0,
		posts: 0,
		likes: 0,
		visitors: 0
	});
	const [coins, setCoins] = (0, import_react.useState)(0);
	const [diamonds, setDiamonds] = (0, import_react.useState)(0);
	const [linkEmail, setLinkEmail] = (0, import_react.useState)("");
	const [phoneToLink, setPhoneToLink] = (0, import_react.useState)("");
	const [phoneOtp, setPhoneOtp] = (0, import_react.useState)("");
	const [phoneOtpSent, setPhoneOtpSent] = (0, import_react.useState)(false);
	const isGuest = !!user?.is_anonymous;
	async function daily() {
		const { error } = await supabase.rpc("claim_daily_bonus");
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("+100 عملة 🎉");
	}
	async function link() {
		const { error } = await supabase.auth.updateUser({ email: linkEmail.trim().toLowerCase() });
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("أرسلنا رابط تأكيد إلى بريدك لربط الحساب");
	}
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let alive = true;
		const refreshBadges = async () => {
			const { data, error } = await supabase.from("user_badges").select("user_id,badge_name,badge_asset_key,badge_color,is_equipped").eq("user_id", user.id).eq("is_equipped", true);
			if (alive && !error) setEquippedBadges(data ?? []);
		};
		const channel = supabase.channel(`profile-live-${user.id}`).on("postgres_changes", {
			event: "UPDATE",
			schema: "public",
			table: "profiles",
			filter: `id=eq.${user.id}`
		}, (payload) => {
			if (!alive) return;
			setP((current) => current ? {
				...current,
				...payload.new
			} : payload.new);
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "user_badges",
			filter: `user_id=eq.${user.id}`
		}, () => {
			refreshBadges();
		}).subscribe();
		(async () => {
			const [{ data }, { data: w }] = await Promise.all([supabase.from("profiles").select("*").eq("id", user.id).single(), supabase.from("wallets").select("coins,diamonds").eq("user_id", user.id).maybeSingle()]);
			if (data && alive) setP(data);
			if (w && alive) {
				setCoins(Number(w.coins ?? 0));
				setDiamonds(Number(w.diamonds ?? 0));
			}
			refreshBadges();
		})();
		return () => {
			alive = false;
			supabase.removeChannel(channel);
		};
	}, [user]);
	async function changeAvatar(f) {
		if (!f || !p) return;
		try {
			const path = await uploadImage(f, p.id, "profile");
			const { error } = await supabase.from("profiles").update({ avatar_url: path }).eq("id", p.id);
			if (error) throw error;
			setP({
				...p,
				avatar_url: path
			});
			if (draft) setDraft({
				...draft,
				avatar_url: path
			});
			toast.success("تم تحديث الصورة");
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "فشل الرفع");
		}
	}
	async function save() {
		if (!draft) return;
		const { error } = await supabase.from("profiles").update({
			display_name: draft.display_name.trim().slice(0, 30),
			bio: (draft.bio ?? "").slice(0, 200),
			country: draft.country,
			avatar_url: draft.avatar_url || null
		}).eq("id", draft.id);
		if (error) {
			toast.error(error.message);
			return;
		}
		setP(draft);
		setEditing(false);
		toast.success("تم الحفظ");
	}
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let cancelled = false;
		(async () => {
			const [{ data: follows }, { data: posts }, visitAgg] = await Promise.all([
				supabase.from("follows").select("follower_id,following_id").or(`follower_id.eq.${user.id},following_id.eq.${user.id}`),
				supabase.from("posts").select("id").eq("user_id", user.id),
				supabase.from("profile_visits").select("visitor_id", {
					count: "exact",
					head: true
				}).eq("profile_id", user.id)
			]);
			const rows = follows ?? [];
			const followerIds = new Set(rows.filter((r) => r.following_id === user.id).map((r) => r.follower_id));
			const followingIds = new Set(rows.filter((r) => r.follower_id === user.id).map((r) => r.following_id));
			const friends = [...followerIds].filter((id) => followingIds.has(id)).length;
			const postIds = (posts ?? []).map((r) => r.id);
			let likes = 0;
			if (postIds.length) {
				const { count } = await supabase.from("post_likes").select("post_id", {
					count: "exact",
					head: true
				}).in("post_id", postIds);
				likes = count ?? 0;
			}
			if (!cancelled) setStats({
				followers: followerIds.size,
				friends,
				posts: postIds.length,
				likes,
				visitors: visitAgg.count ?? 0
			});
		})();
		return () => {
			cancelled = true;
		};
	}, [user]);
	if (!p) return null;
	const shown = editing && draft ? draft : p;
	const fmtCoins = coins >= 1e3 ? (coins / 1e3).toFixed(2) + "k" : coins.toLocaleString();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "profile-reference min-h-screen pb-8",
		style: { background: "linear-gradient(180deg, #e0f2f1 0%, #f5f5f5 40%, #f5f5f5 100%)" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative px-4 pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "absolute left-4 top-6 rounded-full bg-white/60 p-2 text-gray-700 shadow-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-6 w-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
									src: shown.avatar_url,
									name: shown.display_name,
									size: 120,
									ring: true,
									vip: p.vip_level,
									frameKey: p.equipped_frame
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "absolute bottom-1 right-1 cursor-pointer rounded-full bg-white p-1.5 shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4 text-gray-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/*",
										className: "hidden",
										onChange: (e) => {
											changeAvatar(e.target.files?.[0]);
											e.currentTarget.value = "";
										}
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-3 text-2xl font-bold text-gray-900",
								children: [
									flagOf(shown.country),
									" ",
									shown.display_name
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 flex items-center gap-1.5 text-gray-500",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm",
									children: ["ID:", p.display_no]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1 rounded-full bg-pink-500 px-2 py-0.5 text-xs font-bold text-white",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-3 w-3" }),
										" ",
										p.level
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1 rounded-full bg-amber-500 px-2 py-0.5 text-xs font-bold text-white",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-3 w-3" }),
										" ",
										p.vip_level || 0
									]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-center justify-around",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-2xl font-bold text-gray-900",
									children: stats.visitors
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-gray-500",
									children: "الزوار"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-px bg-gray-300" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-2xl font-bold text-gray-900",
									children: stats.followers
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-gray-500",
									children: "المعجبين"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-px bg-gray-300" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-2xl font-bold text-gray-900",
									children: stats.friends
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-gray-500",
									children: "متابعة"
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-4 mt-5 overflow-hidden rounded-2xl p-4",
				style: { background: "linear-gradient(135deg, #1a1a2e, #16213e, #0f3460)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-8 w-8 text-yellow-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xl font-bold text-yellow-400",
								children: "VIP"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm text-white/80",
								children: "افتح النبلاء للتمتع بامتياز.."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/vip",
							className: "rounded-full bg-amber-100 px-4 py-2 text-sm font-bold text-amber-900",
							children: "عرض التفاصيل"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mt-4 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/diamonds",
					className: "flex items-center justify-between rounded-2xl bg-white p-4 shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-2xl font-bold text-gray-900",
						children: diamonds.toFixed(2)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-gray-500",
						children: "Amount"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-10 w-10 items-center justify-center rounded-full bg-cyan-100",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-2xl",
							children: "💎"
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/wallet",
					className: "flex items-center justify-between rounded-2xl bg-white p-4 shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-2xl font-bold text-gray-900",
						children: fmtCoins
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-gray-500",
						children: "Coin"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-10 w-10 items-center justify-center rounded-full bg-yellow-100",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
							className: "h-6 w-6 text-yellow-500",
							fill: "currentColor"
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mt-4 grid grid-cols-4 gap-3 rounded-2xl bg-white p-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/friends",
						className: "flex flex-col items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-6 w-6 text-blue-500" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-gray-700",
							children: "دعوة"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/tasks",
						className: "flex flex-col items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-xl bg-purple-100",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-6 w-6 text-purple-500" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-gray-700",
							children: "المهام"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/store",
						className: "flex flex-col items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-xl bg-pink-100",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "h-6 w-6 text-pink-500" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-gray-700",
							children: "متجر"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/level",
						className: "flex flex-col items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-xl bg-yellow-100",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
								className: "h-6 w-6 text-yellow-600",
								fill: "currentColor"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-gray-700",
							children: "المستوى"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mt-4 overflow-hidden rounded-2xl bg-white shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/bag",
						className: "flex items-center justify-between border-b border-gray-100 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-9 w-9 items-center justify-center rounded-lg bg-orange-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "h-5 w-5 text-orange-500" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gray-800",
								children: "حقيبة الظهر"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5 text-gray-400" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/families",
						className: "flex items-center justify-between border-b border-gray-100 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-9 w-9 items-center justify-center rounded-lg bg-yellow-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-5 w-5 text-yellow-600" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gray-800",
								children: "الوكالة"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5 text-gray-400" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-gray-100 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-9 w-9 items-center justify-center rounded-lg bg-pink-100 text-sm font-bold text-pink-600",
								children: "EN"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gray-800",
								children: "اللغة"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5 text-gray-400" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/settings",
						className: "flex items-center justify-between px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-9 w-9 items-center justify-center rounded-lg bg-gray-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-5 w-5 text-gray-600" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gray-800",
								children: "الإعدادات"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5 text-gray-400" })]
					})
				]
			}),
			editing && draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mt-4 space-y-3 rounded-2xl bg-white p-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: draft.display_name,
						maxLength: 30,
						onChange: (e) => setDraft({
							...draft,
							display_name: e.target.value
						}),
						placeholder: "الاسم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: draft.bio ?? "",
						maxLength: 200,
						onChange: (e) => setDraft({
							...draft,
							bio: e.target.value
						}),
						placeholder: "نبذة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm",
						value: draft.country ?? "EG",
						onChange: (e) => setDraft({
							...draft,
							country: e.target.value
						}),
						children: COUNTRIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: c.code,
							children: [
								c.flag,
								" ",
								c.name
							]
						}, c.code))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: save,
							className: "flex-1 bg-emerald-500",
							children: "حفظ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setEditing(false),
							children: "إلغاء"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mt-4 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => {
							setDraft(p);
							setEditing(true);
						},
						className: "w-full rounded-xl border-gray-300 bg-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-5 w-5" }), " تعديل الملف"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: daily,
						className: "w-full rounded-xl bg-emerald-500 font-bold text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-5 w-5" }), " مكافأة يومية +100"]
					}),
					isGuest && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-white p-3 text-sm shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-emerald-600",
							children: "أنت تستخدم حساب الجهاز السريع. اربط بريدك حتى لا تفقد حسابك."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "email",
								dir: "ltr",
								value: linkEmail,
								onChange: (e) => setLinkEmail(e.target.value),
								placeholder: "email@example.com"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: link,
								variant: "outline",
								children: "ربط"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: async () => {
							if (isGuest) {
								const { data: cur, error } = await supabase.auth.getSession();
								if (error || !cur.session?.user?.is_anonymous) {
									toast.error("تعذر حفظ جلسة الحساب السريع. حاول مرة أخرى.");
									return;
								}
								localStorage.setItem("vox_guest_refresh", cur.session.refresh_token);
								localStorage.setItem("vox_guest_account_created", "1");
								localStorage.setItem("vox_guest_logged_out", "1");
								window.dispatchEvent(new Event("vox-auth-visibility-change"));
							} else await supabase.auth.signOut();
							nav({ to: "/auth" });
						},
						className: "w-full rounded-xl",
						children: "تسجيل الخروج"
					})
				]
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfilePage, {}) });
//#endregion
export { SplitComponent as component };
