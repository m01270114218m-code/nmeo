import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { gt as ChevronLeft, q as Info } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-CNN_t4M1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/level-D2FPi_Vt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHARM_LEVELS = [
	{
		range: "Charm 1-9",
		color: "from-yellow-200 to-yellow-400",
		icon: "✦"
	},
	{
		range: "Charm 10-19",
		color: "from-blue-200 to-blue-400",
		icon: "★"
	},
	{
		range: "Charm 20-29",
		color: "from-purple-200 to-purple-400",
		icon: "✧"
	},
	{
		range: "Charm 30-39",
		color: "from-red-200 to-red-400",
		icon: "♥"
	},
	{
		range: "Charm 40-49",
		color: "from-orange-200 to-orange-400",
		icon: "✦"
	},
	{
		range: "Charm 50-59",
		color: "from-pink-200 to-pink-400",
		icon: "✺"
	},
	{
		range: "Charm 60-69",
		color: "from-orange-300 to-orange-500",
		icon: "✸"
	},
	{
		range: "Charm 70-79",
		color: "from-purple-300 to-purple-500",
		icon: "♥"
	},
	{
		range: "Charm 80-89",
		color: "from-fuchsia-300 to-fuchsia-500",
		icon: "✦"
	},
	{
		range: "Charm 90-99",
		color: "from-yellow-400 to-purple-500",
		icon: "👑"
	}
];
var WEALTH_LEVELS = [
	{
		range: "Wealth 1-9",
		color: "from-yellow-200 to-yellow-400",
		icon: "✦"
	},
	{
		range: "Wealth 10-19",
		color: "from-gray-200 to-gray-400",
		icon: "⚙"
	},
	{
		range: "Wealth 20-29",
		color: "from-yellow-300 to-yellow-500",
		icon: "💎"
	},
	{
		range: "Wealth 30-39",
		color: "from-blue-200 to-blue-400",
		icon: "♛"
	},
	{
		range: "Wealth 40-49",
		color: "from-orange-200 to-orange-400",
		icon: "💎"
	},
	{
		range: "Wealth 50-59",
		color: "from-purple-300 to-purple-500",
		icon: "✦"
	},
	{
		range: "Wealth 60-69",
		color: "from-red-300 to-red-500",
		icon: "♥"
	},
	{
		range: "Wealth 70-79",
		color: "from-red-400 to-red-700",
		icon: "🛡"
	},
	{
		range: "Wealth 80-89",
		color: "from-purple-400 to-purple-700",
		icon: "👑"
	},
	{
		range: "Wealth 90-99",
		color: "from-yellow-500 to-purple-700",
		icon: "👑"
	}
];
function LevelPage() {
	const { user } = useAuth();
	const nav = useNavigate();
	const [tab, setTab] = (0, import_react.useState)("charm");
	const [level, setLevel] = (0, import_react.useState)(0);
	const [xp, setXp] = (0, import_react.useState)(0);
	const [avatarUrl, setAvatarUrl] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		supabase.from("profiles").select("level,xp,avatar_url").eq("id", user.id).single().then(({ data }) => {
			if (data) {
				setLevel(Number(data.level ?? 0));
				setXp(Number(data.xp ?? 0));
				setAvatarUrl(data.avatar_url);
			}
		});
	}, [user]);
	const levels = tab === "charm" ? CHARM_LEVELS : WEALTH_LEVELS;
	const bgGradient = tab === "charm" ? "linear-gradient(180deg, #fce7f3 0%, #fbcfe8 40%, #f5f5f5 60%)" : "linear-gradient(180deg, #ffedd5 0%, #fdba74 40%, #f5f5f5 60%)";
	const nextLevelXp = (level + 1) * 1e3;
	const progress = Math.min(100, xp / nextLevelXp * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "min-h-screen pb-8",
		style: { background: bgGradient },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => nav({ to: "/profile" }),
						className: "rounded-full p-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-7 w-7 text-white" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-bold text-white",
						children: "مستوى"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "rounded-full p-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "h-7 w-7 text-white" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex justify-center gap-12 text-lg font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setTab("charm"),
					className: `relative pb-2 ${tab === "charm" ? "text-white" : "text-white/60"}`,
					children: ["الجاذبية", tab === "charm" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-1 left-1/2 h-1 w-8 -translate-x-1/2 rounded-full bg-white" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setTab("wealth"),
					className: `relative pb-2 ${tab === "wealth" ? "text-white" : "text-white/60"}`,
					children: ["الثروة", tab === "wealth" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-1 left-1/2 h-1 w-8 -translate-x-1/2 rounded-full bg-white" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-24 w-24 rounded-full border-4 border-white bg-white/30",
						style: avatarUrl ? {
							backgroundImage: `url(${avatarUrl})`,
							backgroundSize: "cover"
						} : {}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-purple-600 px-3 py-0.5 text-sm font-bold text-white",
						children: [
							tab === "charm" ? "♥" : "👑",
							" ",
							level
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 w-full px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-sm font-bold text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Lv.", level] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Lv.", level + 1] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 h-3 w-full overflow-hidden rounded-full bg-white/40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-orange-500",
								style: { width: `${progress}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 text-center text-sm text-white/80",
							children: ["المسافة إلى الترقية ", Math.max(0, nextLevelXp - xp)]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 mt-6 rounded-t-3xl bg-white p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-lg font-bold text-gray-900",
					children: "Level"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-3",
					children: levels.map((lv, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-gray-50 p-3 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `mx-auto mb-2 flex h-10 items-center justify-center rounded-full bg-gradient-to-r ${lv.color} text-lg`,
							children: lv.icon
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold text-gray-700",
							children: lv.range
						})]
					}, i))
				})]
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelPage, {}) });
//#endregion
export { SplitComponent as component };
