import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as App } from "../_libs/capacitor__app+capacitor__core.mjs";
import { n as icons3d, o as useAuth, t as getDeviceId } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as Shield } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AppShell-CNN_t4M1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fallback = {
	branding: { app_name: "صدى شات" },
	bottom_nav: {
		home_label: "الغرف",
		explore_label: "اللحظات",
		room_label: "غرفتي",
		messages_label: "الرسائل",
		profile_label: "أنا"
	},
	mic: {},
	buttons: {},
	routes: {},
	features: {
		gifts: true,
		store: true,
		vip: true,
		wallet: true,
		rooms: true,
		moments: true,
		messages: true
	}
};
function useAppUiConfig() {
	const [config, setConfig] = (0, import_react.useState)(fallback);
	(0, import_react.useEffect)(() => {
		let alive = true;
		async function load() {
			const { data } = await supabase.from("admin_settings").select("key,value").in("key", [
				"ui.branding",
				"app_branding",
				"home_banner",
				"ui.bottom_nav",
				"ui.mic",
				"ui.buttons",
				"ui.routes",
				"features"
			]);
			if (!alive) return;
			const next = JSON.parse(JSON.stringify(fallback));
			for (const row of data ?? []) {
				const v = row.value ?? {};
				if (row.key === "ui.branding" || row.key === "app_branding") next.branding = {
					...next.branding,
					...row.key === "app_branding" ? {
						app_name: v.app_name,
						logo_url: v.logo_url ?? v.logo_path
					} : v
				};
				if (row.key === "ui.bottom_nav") next.bottom_nav = {
					...next.bottom_nav,
					...v
				};
				if (row.key === "ui.mic") next.mic = {
					...next.mic,
					...v
				};
				if (row.key === "ui.buttons") next.buttons = {
					...next.buttons,
					...v
				};
				if (row.key === "ui.routes") next.routes = {
					...next.routes,
					...v
				};
				if (row.key === "features") next.features = {
					...next.features,
					...v
				};
			}
			setConfig(next);
		}
		load();
		const ch = supabase.channel("app-ui-config").on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "admin_settings"
		}, load).subscribe();
		return () => {
			alive = false;
			supabase.removeChannel(ch);
		};
	}, []);
	return config;
}
function RequireAuth({ children }) {
	const { user, loading } = useAuth();
	const nav = useNavigate();
	const [deviceAllowed, setDeviceAllowed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!loading && !user) nav({ to: "/auth" });
	}, [
		loading,
		user,
		nav
	]);
	(0, import_react.useEffect)(() => {
		let active = true;
		if (loading || !user?.id) {
			setDeviceAllowed(false);
			return () => {
				active = false;
			};
		}
		setDeviceAllowed(false);
		let checking = false;
		let deviceId = getDeviceId();
		const registrationKey = `vox_device_registered:${user.id}`;
		const checkDeviceAccess = async (retry = false) => {
			if (checking || !active) return;
			checking = true;
			try {
				let { data: sessionData } = await supabase.auth.getSession();
				if (!sessionData.session) {
					const refreshed = await supabase.auth.refreshSession();
					if (refreshed.error) throw refreshed.error;
					sessionData = { session: refreshed.data.session };
				}
				if (!sessionData.session) throw new Error("not_authenticated");
				const { data: allowed, error } = await supabase.rpc("check_device_access", { _device: deviceId });
				if (error) throw error;
				if (allowed !== true) throw new Error("device_access_denied");
				const { error: expiryError } = await supabase.rpc("enforce_user_asset_expirations", { _user: user.id });
				if (expiryError) console.warn("[Asset expiry] verification failed:", expiryError.message);
				if (!user.is_anonymous && localStorage.getItem(registrationKey) !== "1") {
					const { error: registerError } = await supabase.rpc("register_device", { _device: deviceId });
					if (registerError) throw registerError;
					localStorage.setItem(registrationKey, "1");
				}
				if (active) setDeviceAllowed(true);
			} catch (error) {
				if (!active) return;
				const message = error instanceof Error ? error.message : String(error);
				const banned = message.includes("account_banned") || message.includes("device_banned");
				const linked = message.includes("device_already_linked");
				const invalidDevice = message.includes("invalid_device_id");
				const denied = message.includes("device_access_denied");
				if (invalidDevice && !retry) {
					localStorage.removeItem("vox_royale_device_id");
					localStorage.removeItem("vox_device_id");
					deviceId = getDeviceId();
					checking = false;
					await checkDeviceAccess(true);
					return;
				}
				if (banned) {
					toast.error(message.includes("account_banned") ? "هذا الحساب محظور من استخدام التطبيق" : "هذا الجهاز محظور من استخدام التطبيق");
					await supabase.auth.signOut({ scope: "local" });
					if (active) setDeviceAllowed(false);
				} else if (linked || denied) {
					toast.error(linked ? "هذا الجهاز مرتبط بحساب آخر بالفعل" : "تم رفض صلاحية هذا الجهاز");
					if (active) setDeviceAllowed(false);
				} else {
					console.warn("[Device access] verification failed:", message);
					if (active) setDeviceAllowed(false);
					toast.error("تعذر التحقق من صلاحية الحساب والجهاز؛ لن يتم فتح التطبيق حتى ينجح التحقق");
				}
			} finally {
				checking = false;
			}
		};
		checkDeviceAccess();
		const onVisibility = () => {
			if (document.visibilityState === "visible") checkDeviceAccess();
		};
		const nativeStateListener = App.addListener("appStateChange", ({ isActive }) => {
			if (isActive) checkDeviceAccess();
		});
		document.addEventListener("visibilitychange", onVisibility);
		return () => {
			active = false;
			document.removeEventListener("visibilitychange", onVisibility);
			nativeStateListener.then((listener) => listener.remove()).catch(() => void 0);
		};
	}, [loading, user?.id]);
	if (loading || !user || !deviceAllowed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: icons3d.micHost,
			alt: "صدى شات",
			className: "h-14 w-14 object-contain animate-pulse"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function useUnread(uid) {
	const [n, setN] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!uid) return;
		const load = async () => {
			const [{ count: a }, { data: convs }] = await Promise.all([supabase.from("notifications").select("id", {
				count: "exact",
				head: true
			}).eq("user_id", uid).eq("is_read", false), supabase.from("conversations").select("id").or(`user_a.eq.${uid},user_b.eq.${uid}`)]);
			let b = 0;
			if (convs?.length) {
				const { count } = await supabase.from("messages").select("id", {
					count: "exact",
					head: true
				}).in("conversation_id", convs.map((c) => c.id)).neq("sender_id", uid).is("read_at", null);
				b = count ?? 0;
			}
			setN((a ?? 0) + b);
		};
		load();
		const ch = supabase.channel(`unread-${Math.random().toString(36).slice(2)}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "notifications",
			filter: `user_id=eq.${uid}`
		}, load).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "messages"
		}, load).subscribe();
		return () => {
			supabase.removeChannel(ch);
		};
	}, [uid]);
	return n;
}
function AppShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShellInner, { children }) });
}
function ShellInner({ children }) {
	const { user } = useAuth();
	const nav = useNavigate();
	const unread = useUnread(user?.id);
	(0, import_react.useEffect)(() => {
		const onPop = () => {
			if (window.history.length <= 1) return;
		};
		window.addEventListener("popstate", onPop);
		let listener = null;
		App.addListener("backButton", ({ canGoBack }) => {
			if (canGoBack || window.history.length > 1) window.history.back();
			else nav({ to: "/" });
		}).then((h) => {
			listener = h;
		});
		return () => {
			window.removeEventListener("popstate", onPop);
			listener?.remove();
		};
	}, [nav]);
	const ui = useAppUiConfig();
	const [adminEntry, setAdminEntry] = (0, import_react.useState)({ mode: "section" });
	(0, import_react.useEffect)(() => {
		let active = true;
		if (!user?.id) {
			setAdminEntry({ mode: "section" });
			return;
		}
		const refresh = async () => {
			const [{ data: dashboard, error: dashboardError }, { data: permissions, error: permissionsError }] = await Promise.all([supabase.rpc("can_access_admin_dashboard"), supabase.rpc("my_admin_permissions")]);
			if (!active) return;
			if (!permissionsError) {
				const section = (permissions ?? []).find((key) => key.startsWith("section_"));
				if (section) {
					setAdminEntry({
						mode: "section",
						section
					});
					return;
				}
			}
			if (!dashboardError && dashboard === true) {
				setAdminEntry({ mode: "dashboard" });
				return;
			}
			setAdminEntry({ mode: "section" });
		};
		refresh();
		const onVisible = () => {
			if (document.visibilityState === "visible") refresh();
		};
		window.addEventListener("focus", onVisible);
		document.addEventListener("visibilitychange", onVisible);
		return () => {
			active = false;
			window.removeEventListener("focus", onVisible);
			document.removeEventListener("visibilitychange", onVisible);
		};
	}, [user?.id]);
	const adminSectionLabels = {
		section_reports: "البلاغات",
		section_rooms: "الغرف",
		section_seats: "المقاعد",
		section_posts: "المنشورات",
		section_users: "المستخدمون",
		section_wallet: "المحافظ",
		section_gifts: "الهدايا",
		section_vip: "VIP",
		section_store: "المتجر",
		section_assets: "الأصول",
		section_banners: "البانرات",
		section_notifications: "الإشعارات",
		section_roles: "الصلاحيات",
		section_settings: "الإعدادات",
		section_app_builder: "تطوير التطبيق",
		section_analytics: "التحليلات",
		section_audit: "سجل الإجراءات"
	};
	const item = "flex flex-1 flex-col items-center gap-0.5 text-[11px] text-muted-foreground";
	const active = { className: "text-primary" };
	async function myRoom() {
		const { data } = await supabase.from("rooms").select("id").eq("owner_id", user.id).order("created_at", { ascending: false }).limit(1).maybeSingle();
		if (data) nav({
			to: "/room/$id",
			params: { id: data.id }
		});
		else {
			toast("أنشئ غرفتك الأولى");
			nav({
				to: "/",
				search: { create: 1 }
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "app-shell-content min-h-dvh w-full pb-24",
		children
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: "app-bottom-nav glass fixed inset-x-3 bottom-[max(0.5rem,env(safe-area-inset-bottom))] z-40 mx-auto flex max-w-md items-end justify-around gap-1 rounded-full px-2 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: item,
				activeProps: active,
				activeOptions: { exact: true },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: ui.bottom_nav.home_icon || icons3d.home,
					alt: "",
					className: "h-7 w-7 drop-shadow-lg"
				}), ui.bottom_nav.home_label || "الغرف"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/moments",
				className: item,
				activeProps: active,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: ui.bottom_nav.explore_icon || icons3d.explore,
					alt: "",
					className: "h-8 w-8 drop-shadow-lg"
				}), ui.bottom_nav.explore_label || "اللحظات"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: myRoom,
				"aria-label": "غرفتي",
				title: "غرفتي",
				className: "-mt-8 h-16 w-16 rounded-full bg-gold p-1 shadow-gold",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: ui.bottom_nav.room_icon || ui.mic.host_asset_url || icons3d.micHost,
					alt: "",
					className: "h-14 w-14 object-contain"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/messages",
				className: `${item} relative`,
				activeProps: active,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: ui.bottom_nav.messages_icon || icons3d.messages,
						alt: "",
						className: "h-8 w-8 drop-shadow-lg"
					}),
					unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute -top-1 right-3 min-w-5 rounded-full bg-destructive px-1 text-[10px] text-destructive-foreground",
						children: unread > 99 ? "99+" : unread
					}),
					ui.bottom_nav.messages_label || "الرسائل"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/profile",
				className: item,
				activeProps: active,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: ui.bottom_nav.profile_icon || icons3d.profile,
					alt: "",
					className: "h-8 w-8 drop-shadow-lg"
				}), ui.bottom_nav.profile_label || "أنا"]
			}),
			(adminEntry.mode === "dashboard" || adminEntry.section) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/admin",
				search: adminEntry.mode === "section" ? { section: adminEntry.section } : {},
				className: item,
				activeProps: active,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-7 w-7" }), adminEntry.mode === "dashboard" ? "الإدارة" : "إدارة " + (adminSectionLabels[adminEntry.section] ?? "القسم")]
			})
		]
	})] });
}
function PageHeader({ title, back, right }) {
	const nav = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 flex items-center gap-3 bg-background/70 px-4 py-4 backdrop-blur",
		children: [
			back && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				onClick: () => history.length > 1 ? history.back() : nav({ to: "/profile" }),
				"aria-label": "رجوع",
				title: "رجوع",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: icons3d.back,
					alt: "",
					className: "h-7 w-7 rotate-180 object-contain"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-gold flex-1 text-2xl",
				children: title
			}),
			right
		]
	});
}
//#endregion
export { PageHeader as n, RequireAuth as r, AppShell as t };
