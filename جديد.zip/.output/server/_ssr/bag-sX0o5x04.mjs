import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useAdminAsset } from "./media-BXNEENvw.mjs";
import { a as errMsg } from "./vox-CkkqXMfh.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { gt as ChevronLeft, pt as Clock, t as X } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-CNN_t4M1.mjs";
import { t as AdminAssetMedia } from "./AdminAssetMedia-CBSs12zp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bag-sX0o5x04.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		id: "frame",
		label: "إطار الصورة"
	},
	{
		id: "entry",
		label: "تأثيرات المدخل"
	},
	{
		id: "vehicle",
		label: "مركبات الدخول"
	},
	{
		id: "bubble",
		label: "فقاعة الدردشة"
	},
	{
		id: "badge",
		label: "الاوسمة"
	},
	{
		id: "sound_wave",
		label: "موجات الصوت"
	}
];
function Asset({ item, equipped, onToggle }) {
	const src = useAdminAsset(item.store_items?.asset_key ?? void 0);
	const name = item.store_items?.name ?? "عنصر";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-2xl bg-white p-3 shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1 text-xs text-gray-400",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }),
						" ",
						new Date(item.acquired_at).toISOString().slice(0, 10)
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-bold text-emerald-600",
					children: name
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-28 items-center justify-center",
				children: src && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
					src,
					className: "h-full w-full object-contain"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onToggle,
				className: `mt-3 w-full rounded-xl py-2.5 text-sm font-bold text-white ${equipped ? "bg-gray-400" : "bg-emerald-500"}`,
				children: equipped ? "قيد الارتداء" : "ارتداء"
			})
		]
	});
}
function BagPage() {
	const nav = useNavigate();
	const { user } = useAuth();
	const [items, setItems] = (0, import_react.useState)([]);
	const [badges, setBadges] = (0, import_react.useState)([]);
	const [activeTab, setActiveTab] = (0, import_react.useState)("frame");
	const [p, setP] = (0, import_react.useState)({
		equipped_frame: null,
		equipped_entry: null,
		chat_bubble_asset_key: null,
		sound_wave_asset_key: null,
		profile_card_asset_key: null
	});
	async function load() {
		if (!user) return;
		const [{ data: i }, { data: b }, { data: pr }] = await Promise.all([
			supabase.from("user_items").select("id,item_id,acquired_at,store_items(name,kind,asset_key)").eq("user_id", user.id).order("acquired_at", { ascending: false }),
			supabase.from("user_badges").select("id,badge_key,badge_name,badge_asset_key,badge_color,is_equipped").eq("user_id", user.id),
			supabase.from("profiles").select("equipped_frame,equipped_entry,chat_bubble_asset_key,sound_wave_asset_key,profile_card_asset_key").eq("id", user.id).single()
		]);
		setItems(i ?? []);
		setBadges(b ?? []);
		if (pr) setP(pr);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [user]);
	async function toggle(item) {
		if (!item.store_items) return;
		const equipped = item.store_items.kind === "frame" ? p.equipped_frame === item.store_items.asset_key : item.store_items.kind === "entry" ? p.equipped_entry === item.store_items.asset_key : item.store_items.kind === "bubble" ? p.chat_bubble_asset_key === item.store_items.asset_key : item.store_items.kind === "sound_wave" ? p.sound_wave_asset_key === item.store_items.asset_key : item.store_items.kind === "profile_card" ? p.profile_card_asset_key === item.store_items.asset_key : false;
		if (equipped && !["frame", "entry"].includes(item.store_items.kind)) return;
		const { error } = await supabase.rpc("equip_item", {
			_item_id: item.item_id,
			_equip: !equipped
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		await load();
		toast.success(!equipped ? "تم التفعيل" : "تم الإيقاف");
	}
	async function badgeToggle(b) {
		const { error } = await supabase.rpc("equip_badge", {
			_badge: b.id,
			_equip: !b.is_equipped
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		await load();
	}
	const filteredItems = activeTab === "badge" ? [] : items.filter((i) => i.store_items?.kind === activeTab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "min-h-screen pb-8",
		style: { background: "#f0fdf4" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center justify-between bg-white px-4 py-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => nav({ to: "/profile" }),
						className: "rounded-full p-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-7 w-7 text-gray-700" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-bold text-gray-900",
						children: "حقيبة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => nav({ to: "/" }),
						className: "rounded-full p-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-7 w-7 text-gray-700" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-3 mt-3 flex h-40 items-center justify-center overflow-hidden rounded-2xl",
				style: { background: "linear-gradient(135deg, #4ade80, #22d3ee)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 w-24 rounded-full border-4 border-white bg-white/30" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-[65px] z-20 flex gap-1 overflow-x-auto border-b border-gray-200 bg-white px-2",
				children: TABS.map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setActiveTab(tab.id),
					className: `whitespace-nowrap px-4 py-3 text-sm font-bold ${activeTab === tab.id ? "border-b-2 border-emerald-500 text-emerald-600" : "text-gray-500"}`,
					children: tab.label
				}, tab.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-3 mt-4 grid grid-cols-2 gap-3",
				children: activeTab === "badge" ? badges.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-2 rounded-2xl bg-white p-8 text-center text-gray-400",
					children: "لا توجد شارات"
				}) : badges.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-2xl bg-white p-3 text-center shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto mb-2 h-20 w-20 rounded-full",
							style: { background: b.badge_color || "#e5e7eb" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-gray-900",
							children: b.badge_name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => void badgeToggle(b),
							className: `mt-2 w-full rounded-xl py-2 text-sm font-bold text-white ${b.is_equipped ? "bg-gray-400" : "bg-emerald-500"}`,
							children: b.is_equipped ? "قيد الارتداء" : "ارتداء"
						})
					]
				}, b.id)) : filteredItems.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-2 rounded-2xl bg-white p-8 text-center text-gray-400",
					children: "لا توجد عناصر في هذا القسم"
				}) : filteredItems.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Asset, {
					item: i,
					equipped: i.store_items?.kind === "frame" ? p.equipped_frame === i.store_items.asset_key : i.store_items?.kind === "entry" ? p.equipped_entry === i.store_items.asset_key : i.store_items?.kind === "bubble" ? p.chat_bubble_asset_key === i.store_items.asset_key : i.store_items?.kind === "sound_wave" ? p.sound_wave_asset_key === i.store_items.asset_key : i.store_items?.kind === "profile_card" ? p.profile_card_asset_key === i.store_items.asset_key : false,
					onToggle: () => void toggle(i)
				}, i.id))
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BagPage, {}) });
//#endregion
export { SplitComponent as component };
