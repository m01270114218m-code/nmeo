import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { a as errMsg } from "./vox-CkkqXMfh.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Dt as ArrowRight, E as Send, _t as Check, vt as CheckCheck } from "../_libs/lucide-react.mjs";
import { r as RequireAuth } from "./AppShell-CNN_t4M1.mjs";
import { n as UserAvatar } from "./UserAvatar-DvFPapaA.mjs";
import { t as Route } from "./chat._id-Bdxvg7zy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat._id-Stt3mNPH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Chat() {
	const { id } = Route.useParams();
	const { user } = useAuth();
	const uid = user.id;
	const nav = useNavigate();
	const [other, setOther] = (0, import_react.useState)(null);
	const [msgs, setMsgs] = (0, import_react.useState)([]);
	const [text, setText] = (0, import_react.useState)("");
	const end = (0, import_react.useRef)(null);
	const loadMsgs = (0, import_react.useCallback)(async () => {
		const { data, error } = await supabase.from("messages").select("id,sender_id,body,created_at,read_at").eq("conversation_id", id).order("created_at", { ascending: false }).limit(100);
		if (error) {
			console.warn("[chat] refresh failed:", error.message);
			return;
		}
		setMsgs((data ?? []).reverse());
		supabase.rpc("mark_conv_read", { _conv: id });
	}, [id]);
	(0, import_react.useEffect)(() => {
		(async () => {
			const { data: c } = await supabase.from("conversations").select("*").eq("id", id).maybeSingle();
			if (!c) {
				toast.error("المحادثة غير موجودة");
				return nav({ to: "/messages" });
			}
			const oid = c.user_a === uid ? c.user_b : c.user_a;
			const { data: p } = await supabase.from("profiles").select("id,display_name,avatar_url").eq("id", oid).single();
			setOther(p);
			loadMsgs();
		})();
		const ch = supabase.channel(`chat-${id}-${Math.random().toString(36).slice(2)}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "messages",
			filter: `conversation_id=eq.${id}`
		}, () => {
			loadMsgs();
		}).subscribe();
		const poll = window.setInterval(() => {
			if (document.visibilityState === "visible") loadMsgs();
		}, 1500);
		const onVisible = () => {
			if (document.visibilityState === "visible") loadMsgs();
		};
		document.addEventListener("visibilitychange", onVisible);
		return () => {
			window.clearInterval(poll);
			document.removeEventListener("visibilitychange", onVisible);
			supabase.removeChannel(ch);
		};
	}, [
		id,
		loadMsgs,
		nav,
		uid
	]);
	(0, import_react.useEffect)(() => {
		end.current?.scrollIntoView({ behavior: "smooth" });
	}, [msgs]);
	async function send(e) {
		e.preventDefault();
		if (!text.trim()) return;
		const b = text;
		setText("");
		const { error } = await supabase.rpc("send_dm", {
			_conv: id,
			_body: b
		});
		if (error) {
			toast.error(errMsg(error));
			setText(b);
			return;
		}
		loadMsgs();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-screen max-w-2xl flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "glass m-3 flex items-center gap-3 rounded-2xl p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => nav({ to: "/messages" }),
					"aria-label": "رجوع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})
				}), other && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/u/$id",
					params: { id: other.id },
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
						src: other.avatar_url,
						name: other.display_name,
						size: 36
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-bold",
						children: other.display_name
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 space-y-2 overflow-y-auto px-4",
				children: [msgs.map((m) => {
					const mine = m.sender_id === uid;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `flex ${mine ? "justify-start" : "justify-end"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `max-w-[80%] rounded-2xl px-3 py-2 text-sm ${mine ? "bg-gold" : "glass"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "whitespace-pre-wrap",
								children: m.body
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-0.5 flex items-center gap-1 text-[10px] opacity-70",
								children: [new Date(m.created_at).toLocaleTimeString("ar-EG", {
									hour: "2-digit",
									minute: "2-digit"
								}), mine && (m.read_at ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" }))]
							})]
						})
					}, m.id);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: end })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: send,
				className: "glass m-3 flex gap-2 rounded-full p-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: text,
					onChange: (e) => setText(e.target.value),
					maxLength: 1e3,
					placeholder: "اكتب رسالة…",
					className: "border-0 bg-transparent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "icon",
					className: "rounded-full bg-gold",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4" })
				})]
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chat, {}) });
//#endregion
export { SplitComponent as component };
