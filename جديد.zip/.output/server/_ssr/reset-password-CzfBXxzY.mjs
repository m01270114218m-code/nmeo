import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-CzfBXxzY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Reset() {
	const [pw, setPw] = (0, import_react.useState)("");
	const nav = useNavigate();
	async function save(e) {
		e.preventDefault();
		const { error } = await supabase.auth.updateUser({ password: pw });
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("تم تغيير كلمة المرور");
		nav({ to: "/" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: save,
			className: "glass w-full max-w-sm space-y-3 rounded-3xl p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-gold text-2xl",
					children: "كلمة مرور جديدة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "password",
					minLength: 6,
					required: true,
					value: pw,
					onChange: (e) => setPw(e.target.value),
					dir: "ltr"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full bg-gold",
					children: "حفظ"
				})
			]
		})
	});
}
//#endregion
export { Reset as component };
