import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { n as PageHeader, t as AppShell } from "./AppShell-CNN_t4M1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/help-B8olPXfl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS = {
	open: "مفتوحة",
	reviewing: "قيد المراجعة",
	resolved: "تم الحل",
	rejected: "مرفوضة"
};
function Help() {
	const { user } = useAuth();
	const [list, setList] = (0, import_react.useState)([]);
	const [cat, setCat] = (0, import_react.useState)("مشكلة تقنية");
	const [details, setDetails] = (0, import_react.useState)("");
	async function load() {
		const { data } = await supabase.from("reports").select("*").eq("reporter_id", user.id).order("created_at", { ascending: false });
		setList(data ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	async function send() {
		const { error } = await supabase.rpc("submit_report", {
			_type: "support",
			_target: user.id,
			_category: cat,
			_details: details.trim()
		});
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("أُرسلت التذكرة");
		setDetails("");
		load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "مركز الدعم",
			back: true
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass card-3d mx-4 space-y-2 rounded-3xl p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						"مشكلة تقنية",
						"الشحن والمحفظة",
						"حساب",
						"اقتراح"
					].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setCat(c),
						className: `rounded-full px-3 py-1 text-sm ${cat === c ? "bg-gold" : "bg-secondary"}`,
						children: c
					}, c))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "اشرح مشكلتك",
					value: details,
					maxLength: 1e3,
					onChange: (e) => setDetails(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					disabled: details.trim().length < 5,
					onClick: send,
					children: "إرسال"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "px-4 pb-2 pt-4 text-sm font-bold text-muted-foreground",
			children: "تذاكري وبلاغاتي"
		}),
		list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-4 text-center text-sm text-muted-foreground",
			children: "لا توجد تذاكر."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2 px-4",
			children: list.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass rounded-2xl p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: r.category }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary",
							children: STATUS[r.status] ?? r.status
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: r.details
					}),
					r.admin_reply && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 rounded-xl bg-secondary/60 p-2",
						children: ["رد الإدارة: ", r.admin_reply]
					})
				]
			}, r.id))
		})
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Help, {}) });
//#endregion
export { SplitComponent as component };
