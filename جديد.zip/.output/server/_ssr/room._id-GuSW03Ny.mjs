import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/room._id-GuSW03Ny.js
var $$splitComponentImporter = () => import("./room._id-CSTJIogE.mjs");
var Route = createFileRoute("/room/$id")({
	head: () => ({ meta: [
		{ title: "غرفة صوتية — صدى شات" },
		{
			name: "description",
			content: "انضم إلى الغرفة الصوتية، اجلس على المقاعد وتحدث مباشرة."
		},
		{
			property: "og:title",
			content: "غرفة صوتية — صدى شات"
		},
		{
			property: "og:description",
			content: "انضم إلى الغرفة الصوتية وتحدث مباشرة."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
