import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { n as getAdminAssetUrl } from "./media-BXNEENvw.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { a as errMsg } from "./vox-CkkqXMfh.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./admin-BY3pKqIL.mjs";
import { $ as Gift, A as Power, C as ShieldCheck, Ct as Bell, D as Search, F as PanelsTopLeft, J as Image, O as ScrollText, S as Shield, St as Box, T as Settings, a as Users, at as FileText, f as Trash2, it as File, k as RefreshCw, kt as Armchair, lt as DoorOpen, m as Store, n as Wallet, rt as Flag, st as ExternalLink, u as Upload, yt as ChartColumn } from "../_libs/lucide-react.mjs";
import { r as RequireAuth } from "./AppShell-CNN_t4M1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DZYL49i1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Subscribe to committed Postgres changes and refresh the current admin view. */
function useAdminRealtime(tables, onChange) {
	const callback = (0, import_react.useRef)(onChange);
	const tableKey = [...new Set(tables)].sort().join(",");
	(0, import_react.useEffect)(() => {
		callback.current = onChange;
	}, [onChange]);
	(0, import_react.useEffect)(() => {
		if (!tableKey) return;
		const channel = supabase.channel("admin-live:" + tableKey);
		let timer = null;
		const schedule = () => {
			if (timer) clearTimeout(timer);
			timer = setTimeout(() => {
				timer = null;
				callback.current();
			}, 180);
		};
		tableKey.split(",").forEach((table) => {
			channel.on("postgres_changes", {
				event: "*",
				schema: "public",
				table
			}, schedule);
		});
		channel.subscribe();
		return () => {
			if (timer) clearTimeout(timer);
			supabase.removeChannel(channel);
		};
	}, [tableKey]);
}
var fmt$1 = (value) => new Date(value).toLocaleString("ar-EG");
function SeatsTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [query, setQuery] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	async function load() {
		setLoading(true);
		const { data, error } = await supabase.from("room_seats").select("room_id,seat_index,is_locked,is_muted,user_id,rooms(name,room_no),profiles(display_name,display_no)").order("room_id").order("seat_index").limit(300);
		if (error) toast.error(errMsg(error));
		const normalized = (data ?? []).filter((row) => !query || row.rooms?.name?.toLowerCase().includes(query.toLowerCase()) || String(row.rooms?.room_no ?? "").includes(query) || row.profiles?.display_name?.toLowerCase().includes(query.toLowerCase()));
		setRows(normalized);
		setLoading(false);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [query]);
	useAdminRealtime(["room_seats", "room_members"], load);
	async function act(row, action) {
		const { error } = await supabase.rpc("admin_seat_action", {
			_room: row.room_id,
			_seat: row.seat_index,
			_action: action
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم تحديث المقعد");
		await load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "ابحث باسم الغرفة أو العضو أو رقمها"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => void load(),
					disabled: loading,
					children: "تحديث"
				})]
			}),
			rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "glass rounded-2xl p-6 text-center text-muted-foreground",
				children: loading ? "جارٍ التحميل…" : "لا توجد مقاعد في قاعدة البيانات بعد"
			}),
			rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-2 rounded-xl p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
							row.rooms?.name ?? "غرفة",
							" · مقعد ",
							row.seat_index + 1
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted-foreground",
							children: [
								row.profiles?.display_name ?? "مقعد فارغ",
								" ",
								row.profiles?.display_no ? "· ID " + row.profiles.display_no : ""
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-1 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: row.is_locked ? "rounded-full bg-destructive/15 px-2 py-1 text-destructive" : "rounded-full bg-secondary px-2 py-1",
							children: row.is_locked ? "مقفل" : "مفتوح"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: row.is_muted ? "rounded-full bg-destructive/15 px-2 py-1 text-destructive" : "rounded-full bg-secondary px-2 py-1",
							children: row.is_muted ? "مكتوم" : "الصوت متاح"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => void act(row, row.is_locked ? "unlock" : "lock"),
								children: row.is_locked ? "فتح" : "قفل"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => void act(row, row.is_muted ? "unmute" : "mute"),
								children: row.is_muted ? "إلغاء الكتم" : "كتم"
							}),
							row.user_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "destructive",
								onClick: () => {
									if (confirm("إخلاء المقعد؟")) act(row, "kick");
								},
								children: "إخلاء المقعد"
							})
						]
					})
				]
			}, row.room_id + ":" + row.seat_index))
		]
	});
}
function BannersTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		title: "",
		image_url: "",
		target_url: "",
		sort_order: "0"
	});
	async function load() {
		const { data, error } = await supabase.from("banners").select("*").order("sort_order").order("created_at", { ascending: false }).limit(200);
		if (error) toast.error(errMsg(error));
		setRows(data ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime(["banners"], load);
	async function save() {
		if (!form.title.trim() || !/^https?:\/\//i.test(form.image_url.trim())) {
			toast.error("أدخل عنواناً ورابط صورة صحيحاً");
			return;
		}
		const payload = {
			title: form.title.trim(),
			image_url: form.image_url.trim(),
			target_url: form.target_url.trim() || null,
			sort_order: Number(form.sort_order) || 0,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		};
		const { error } = editingId ? await supabase.from("banners").update(payload).eq("id", editingId) : await supabase.from("banners").insert({
			...payload,
			is_active: true
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success(editingId ? "تم تغيير البانر" : "تم نشر البانر في قاعدة بيانات التطبيق");
		setEditingId(null);
		setForm({
			title: "",
			image_url: "",
			target_url: "",
			sort_order: "0"
		});
		await load();
	}
	async function toggle(row) {
		const { error } = await supabase.from("banners").update({
			is_active: !row.is_active,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", row.id);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		await load();
	}
	async function remove(row) {
		if (!confirm("حذف هذا البانر؟")) return;
		const { error } = await supabase.from("banners").delete().eq("id", row.id);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		if (editingId === row.id) {
			setEditingId(null);
			setForm({
				title: "",
				image_url: "",
				target_url: "",
				sort_order: "0"
			});
		}
		await load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass space-y-2 rounded-2xl p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: editingId ? "تغيير بانر الغرف" : "إضافة بانر يظهر داخل قائمة الغرف" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "عنوان البانر",
					value: form.title,
					onChange: (e) => setForm({
						...form,
						title: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "رابط الصورة HTTPS",
					dir: "ltr",
					value: form.image_url,
					onChange: (e) => setForm({
						...form,
						image_url: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "رابط الوجهة (اختياري)",
					dir: "ltr",
					value: form.target_url,
					onChange: (e) => setForm({
						...form,
						target_url: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					placeholder: "الترتيب",
					value: form.sort_order,
					onChange: (e) => setForm({
						...form,
						sort_order: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "bg-gold",
						onClick: () => void save(),
						children: editingId ? "حفظ تغيير البانر" : "نشر البانر"
					}), editingId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => {
							setEditingId(null);
							setForm({
								title: "",
								image_url: "",
								target_url: "",
								sort_order: "0"
							});
						},
						children: "إلغاء"
					})]
				})
			]
		}), rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass flex items-center gap-3 rounded-xl p-3 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: row.image_url,
					alt: "",
					className: "h-14 w-20 rounded-lg object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: row.title }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-xs text-muted-foreground",
							dir: "ltr",
							children: row.image_url
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs",
							children: [
								row.is_active ? "نشط" : "متوقف",
								" · ترتيب ",
								row.sort_order
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => {
								setEditingId(row.id);
								setForm({
									title: row.title,
									image_url: row.image_url,
									target_url: row.target_url || "",
									sort_order: String(row.sort_order)
								});
							},
							children: "تغيير"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => void toggle(row),
							children: row.is_active ? "إيقاف" : "تفعيل"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "destructive",
							onClick: () => void remove(row),
							children: "حذف"
						})
					]
				})
			]
		}, row.id))]
	});
}
function NotificationsTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [sending, setSending] = (0, import_react.useState)(false);
	async function load() {
		const { data, error } = await supabase.from("notifications").select("id,user_id,title,body,kind,is_read,created_at").order("created_at", { ascending: false }).limit(100);
		if (error) toast.error(errMsg(error));
		setRows(data ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime(["notifications"], load);
	async function send() {
		if (!title.trim() || !body.trim()) return;
		setSending(true);
		const { data, error } = await supabase.rpc("admin_broadcast", {
			_title: title.trim(),
			_body: body.trim()
		});
		setSending(false);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم إرسال الإشعار إلى " + Number(data ?? 0).toLocaleString("ar-EG") + " حساب");
		setTitle("");
		setBody("");
		await load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-2 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "إرسال إشعار حقيقي لكل مستخدمي التطبيق" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value),
						placeholder: "عنوان الإشعار"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "min-h-24 w-full rounded-md border border-input bg-input px-3 py-2 text-sm",
						value: body,
						onChange: (e) => setBody(e.target.value),
						placeholder: "محتوى الإشعار"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "bg-gold",
						disabled: sending || !title.trim() || !body.trim(),
						onClick: () => void send(),
						children: sending ? "جارٍ الإرسال…" : "إرسال للجميع"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "آخر الإشعارات المسجلة" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => void load(),
					children: "تحديث"
				})]
			}),
			rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass rounded-xl p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: row.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: fmt$1(row.created_at)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1",
						children: row.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground",
						dir: "ltr",
						children: [
							"user: ",
							row.user_id,
							" · ",
							row.kind,
							" · ",
							row.is_read ? "read" : "unread"
						]
					})
				]
			}, row.id))
		]
	});
}
var ADMIN_PERMISSION_OPTIONS = [
	["send_frame", "إرسال الإطارات"],
	["send_entry", "إرسال الدخوليات"],
	["send_badge", "إرسال الشارات"],
	["send_profile_assets", "إرسال أصول الملف الشخصي"],
	["edit_user_id", "تعديل ID والهوية"],
	["ban_account", "حظر الحساب"],
	["ban_device", "حظر الجهاز"],
	["manage_wallet", "تعديل رصيد العملات"],
	["manage_vip", "تعديل VIP"],
	["section_reports", "قسم البلاغات"],
	["section_rooms", "قسم الغرف"],
	["section_seats", "قسم المقاعد"],
	["section_posts", "قسم المنشورات"],
	["section_users", "قسم المستخدمين"],
	["section_wallet", "قسم المحافظ"],
	["section_gifts", "قسم الهدايا"],
	["section_vip", "قسم مستويات VIP"],
	["section_store", "قسم المتجر"],
	["section_assets", "قسم الأصول"],
	["section_banners", "قسم البانرات"],
	["section_notifications", "قسم الإشعارات"],
	["section_roles", "قسم صلاحيات الإدارة"],
	["section_settings", "قسم الإعدادات"],
	["section_app_builder", "قسم تطوير التطبيق"],
	["section_analytics", "قسم التحليلات"],
	["section_audit", "قسم سجل الإجراءات"]
];
function AdminRolesTab({ isSuper }) {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [query, setQuery] = (0, import_react.useState)("");
	const [dashboardEnabled, setDashboardEnabled] = (0, import_react.useState)([]);
	const [permissions, setPermissions] = (0, import_react.useState)({});
	async function load() {
		const { data, error } = await supabase.rpc("admin_list_users", { _q: query });
		if (error) toast.error(errMsg(error));
		const users = (data ?? []).filter((user) => user.roles.length > 0);
		setRows(users);
		if (isSuper) {
			const [{ data: accessRows, error: accessError }, { data: permissionRows, error: permissionError }] = await Promise.all([supabase.from("admin_dashboard_access").select("user_id").eq("enabled", true), supabase.from("admin_user_permissions").select("user_id,permission_key").eq("enabled", true)]);
			if (accessError) toast.error(errMsg(accessError));
			if (permissionError) toast.error(errMsg(permissionError));
			setDashboardEnabled((accessRows ?? []).map((row) => row.user_id));
			const grouped = {};
			(permissionRows ?? []).forEach((row) => {
				(grouped[row.user_id] ??= []).push(row.permission_key);
			});
			setPermissions(grouped);
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [isSuper]);
	useAdminRealtime([
		"user_roles",
		"profiles",
		"admin_user_permissions",
		"admin_dashboard_access"
	], load);
	async function change(user, role, grant) {
		if (!isSuper) {
			toast.error("إدارة الصلاحيات متاحة للمشرف الأعلى فقط");
			return;
		}
		const { error } = await supabase.rpc("admin_set_role", {
			_user: user.id,
			_role: role,
			_grant: grant
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم تحديث دور المستخدم");
		await load();
	}
	async function toggleDashboard(user) {
		if (!isSuper) return;
		const enabled = dashboardEnabled.includes(user.id);
		const { error } = await supabase.rpc("admin_set_dashboard_access", {
			_user: user.id,
			_enabled: !enabled
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success(!enabled ? "تم إظهار زر لوحة التحكم لهذا الحساب" : "تم إخفاء زر لوحة التحكم لهذا الحساب");
		await load();
	}
	async function togglePermission(user, permission) {
		if (!isSuper) return;
		const enabled = (permissions[user.id] ?? []).includes(permission);
		const { error } = await supabase.rpc("admin_set_user_permission", {
			_user: user.id,
			_permission: permission,
			_enabled: !enabled
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success(!enabled ? "تم تفعيل الصلاحية لهذا الأدمن" : "تم إلغاء الصلاحية");
		await load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			!isSuper && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-destructive/10 p-3 text-sm text-destructive",
				children: "عرض الصلاحيات فقط. التعديل متاح للمشرف الأعلى."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "ابحث بالاسم أو رقم المستخدم"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => void load(),
					children: "بحث"
				})]
			}),
			rows.map((user) => {
				const canHaveDashboard = user.roles.includes("admin") || user.roles.includes("moderator");
				const dashboardIsEnabled = dashboardEnabled.includes(user.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass space-y-3 rounded-xl p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: user.display_name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground",
							children: [
								"ID ",
								user.display_no,
								" · ",
								user.roles.join(", ")
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-1",
							children: [["admin", "moderator"].map((role) => {
								const active = user.roles.includes(role);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									disabled: !isSuper,
									variant: active ? "destructive" : "outline",
									onClick: () => void change(user, role, !active),
									children: [active ? "إزالة " : "منح ", role]
								}, role);
							}), canHaveDashboard && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								disabled: !isSuper,
								variant: dashboardIsEnabled ? "default" : "outline",
								onClick: () => void toggleDashboard(user),
								children: dashboardIsEnabled ? "إخفاء لوحة التحكم" : "إظهار لوحة التحكم"
							})]
						})]
					}), canHaveDashboard && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-white/10 bg-background/30 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-xs",
							children: "الصلاحيات الممنوحة لهذا الحساب"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: ADMIN_PERMISSION_OPTIONS.map(([permission, label]) => {
								const enabled = (permissions[user.id] ?? []).includes(permission);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									disabled: !isSuper,
									variant: enabled ? "default" : "outline",
									onClick: () => void togglePermission(user, permission),
									children: [enabled ? "✓ " : "+ ", label]
								}, permission);
							})
						})]
					})]
				}, user.id);
			}),
			rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "glass rounded-xl p-5 text-center text-sm text-muted-foreground",
				children: "لا توجد صلاحيات إضافية مسجلة"
			})
		]
	});
}
function SettingsTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [key, setKey] = (0, import_react.useState)("");
	const [value, setValue] = (0, import_react.useState)("{}");
	const [authMethods, setAuthMethods] = (0, import_react.useState)({
		email_enabled: true,
		quick_enabled: true,
		google_enabled: true,
		phone_enabled: true
	});
	const [authBusy, setAuthBusy] = (0, import_react.useState)(false);
	async function load() {
		const { data, error } = await supabase.from("admin_settings").select("key,value,updated_at,updated_by").order("key");
		if (error) toast.error(errMsg(error));
		setRows(data ?? []);
		const authRow = (data ?? []).find((r) => r.key === "auth_methods");
		if (authRow) {
			const v = authRow.value ?? {};
			setAuthMethods({
				email_enabled: v.email_enabled !== false,
				quick_enabled: v.quick_enabled !== false,
				google_enabled: v.google_enabled !== false,
				phone_enabled: v.phone_enabled !== false
			});
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime(["admin_settings"], load);
	async function saveAuthMethods(next) {
		setAuthBusy(true);
		const { data: auth } = await supabase.auth.getUser();
		const { error } = await supabase.from("admin_settings").upsert({
			key: "auth_methods",
			value: next,
			updated_at: (/* @__PURE__ */ new Date()).toISOString(),
			updated_by: auth.user?.id ?? null
		});
		setAuthBusy(false);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		setAuthMethods(next);
		toast.success("تم تحديث أزرار تسجيل الدخول");
		await load();
	}
	async function save() {
		let parsed;
		try {
			parsed = JSON.parse(value);
		} catch {
			toast.error("قيمة JSON غير صحيحة");
			return;
		}
		if (!key.trim()) {
			toast.error("أدخل مفتاح الإعداد");
			return;
		}
		const { data: auth } = await supabase.auth.getUser();
		const { error } = await supabase.from("admin_settings").upsert({
			key: key.trim(),
			value: parsed,
			updated_at: (/* @__PURE__ */ new Date()).toISOString(),
			updated_by: auth.user?.id ?? null
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم حفظ الإعداد في قاعدة البيانات");
		setKey("");
		setValue("{}");
		await load();
	}
	async function remove(k) {
		if (!confirm("حذف الإعداد " + k + "؟")) return;
		const { error } = await supabase.from("admin_settings").delete().eq("key", k);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		await load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass rounded-2xl border border-gold/20 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-lg",
						children: "أزرار تسجيل الدخول"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "إخفاء أو إظهار كل طريقة من واجهة تسجيل الدخول بدون تعديل الكود."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid gap-2 sm:grid-cols-2",
						children: [
							{
								key: "email_enabled",
								title: "البريد الإلكتروني",
								description: "زر البريد + كلمة المرور + إنشاء الحساب"
							},
							{
								key: "google_enabled",
								title: "Google",
								description: "زر الدخول عبر حساب Google الحقيقي"
							},
							{
								key: "phone_enabled",
								title: "رقم الهاتف",
								description: "OTP عبر SMS وتسجيل الرقم في Supabase Auth"
							},
							{
								key: "quick_enabled",
								title: "الدخول السريع",
								description: "حساب واحد مرتبط بهذا الجهاز"
							}
						].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-background/30 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "text-sm",
								children: option.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: option.description
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: authBusy,
								onClick: () => void saveAuthMethods({
									...authMethods,
									[option.key]: !authMethods[option.key]
								}),
								className: `relative h-7 w-12 rounded-full transition ${authMethods[option.key] ? "bg-gold" : "bg-muted"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-1 h-5 w-5 rounded-full bg-white shadow transition ${authMethods[option.key] ? "right-1" : "left-1"}` })
							})]
						}, option.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 rounded-xl bg-emerald-500/10 p-3 text-xs text-emerald-300",
						children: "سياسة الجهاز: بعد ربط حساب بالجهاز، لا يمكن لحساب آخر الاستيلاء على نفس الجهاز عبر تسجيل الدخول السريع أو التسجيل الجديد."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-2 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "إعدادات التطبيق المركزية" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: key,
						onChange: (e) => setKey(e.target.value),
						placeholder: "مفتاح الإعداد مثل maintenance_mode",
						dir: "ltr"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "min-h-28 w-full rounded-md border border-input bg-input px-3 py-2 font-mono text-xs",
						value,
						onChange: (e) => setValue(e.target.value),
						dir: "ltr",
						placeholder: "{\"enabled\":false}"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "bg-gold",
						onClick: () => void save(),
						children: "حفظ الإعداد"
					})
				]
			}),
			rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass flex items-start justify-between gap-2 rounded-xl p-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							dir: "ltr",
							children: row.key
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "mt-1 overflow-x-auto text-xs text-muted-foreground",
							children: JSON.stringify(row.value, null, 2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground",
							children: fmt$1(row.updated_at)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => {
							setKey(row.key);
							setValue(JSON.stringify(row.value, null, 2));
						},
						children: "تعديل"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "destructive",
						onClick: () => void remove(row.key),
						children: "حذف"
					})]
				})]
			}, row.key))
		]
	});
}
function AnalyticsTab() {
	const [data, setData] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	async function load() {
		setLoading(true);
		const { data: result, error } = await supabase.rpc("get_analytics");
		if (error) toast.error(errMsg(error));
		setData(result ?? null);
		setLoading(false);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime([
		"profiles",
		"rooms",
		"wallets",
		"gift_transactions",
		"reports"
	], load);
	const renderValue = (value) => typeof value === "object" && value !== null ? JSON.stringify(value, null, 2) : String(value ?? "—");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "تحليلات مباشرة من قاعدة البيانات" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					disabled: loading,
					onClick: () => void load(),
					children: "تحديث"
				})]
			}),
			!data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "glass rounded-xl p-5 text-center text-sm text-muted-foreground",
				children: loading ? "جارٍ التحميل…" : "لا توجد بيانات تحليلات متاحة"
			}),
			data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: Object.entries(data).map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass rounded-xl p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "capitalize",
						children: key.replaceAll("_", " ")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-2 overflow-x-auto whitespace-pre-wrap text-xs text-muted-foreground",
						children: renderValue(value)
					})]
				}, key))
			})
		]
	});
}
function AppBuilderTab() {
	const defaults = {
		"ui.branding": JSON.stringify({
			app_name: "صدي شات",
			logo_url: "",
			logo_path: ""
		}, null, 2),
		"app_branding": JSON.stringify({
			app_name: "صدي شات",
			logo_path: "",
			logo_url: ""
		}, null, 2),
		"home_banner": JSON.stringify({
			title: "",
			image_path: "",
			enabled: true
		}, null, 2),
		"auth_methods": JSON.stringify({
			email_enabled: true,
			quick_enabled: true,
			google_enabled: true,
			phone_enabled: true
		}, null, 2),
		"ui.bottom_nav": JSON.stringify({
			home_label: "الغرف",
			explore_label: "اللحظات",
			room_label: "غرفتي",
			messages_label: "الرسائل",
			profile_label: "أنا",
			home_icon: "",
			explore_icon: "",
			room_icon: "",
			messages_icon: "",
			profile_icon: ""
		}, null, 2),
		"ui.mic": JSON.stringify({
			mic_style: "neon",
			show_mic_effect: true,
			mic_asset_key: "",
			muted_asset_key: "",
			effect_asset_key: ""
		}, null, 2),
		"ui.buttons": JSON.stringify({
			primary_asset_url: "",
			secondary_asset_url: "",
			gift_asset_url: "",
			send_asset_url: ""
		}, null, 2),
		"ui.routes": JSON.stringify({
			home_title: "الرئيسية",
			room_title: "الغرفة",
			store_title: "المتجر",
			vip_title: "VIP",
			profile_title: "الملف الشخصي"
		}, null, 2),
		"features": JSON.stringify({
			gifts: true,
			store: true,
			vip: true,
			wallet: true,
			rooms: true,
			moments: true,
			messages: true
		}, null, 2),
		"app_update_policy": JSON.stringify({
			enabled: false,
			min_version: "2.0.0",
			blocked_versions: [],
			latest_version: "2.0.0",
			download_url: "",
			message: "هذا الإصدار قديم. حدّث صدى شات إلى الإصدار 2 للمتابعة."
		}, null, 2)
	};
	const [rows, setRows] = (0, import_react.useState)(defaults);
	const [active, setActive] = (0, import_react.useState)("ui.branding");
	const [loading, setLoading] = (0, import_react.useState)(false);
	async function load() {
		const { data, error } = await supabase.from("admin_settings").select("key,value").in("key", Object.keys(defaults));
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		const next = { ...defaults };
		for (const r of data ?? []) next[r.key] = JSON.stringify(r.value, null, 2);
		setRows(next);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime(["admin_settings"], load);
	async function save(key) {
		let parsed;
		try {
			parsed = JSON.parse(rows[key]);
		} catch {
			toast.error("JSON غير صحيح");
			return;
		}
		setLoading(true);
		const { data: auth } = await supabase.auth.getUser();
		const { error } = await supabase.from("admin_settings").upsert({
			key,
			value: parsed,
			updated_at: (/* @__PURE__ */ new Date()).toISOString(),
			updated_by: auth.user?.id ?? null
		});
		setLoading(false);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم حفظ التعديل وسيظهر للتطبيق عند تحديث الإعدادات");
	}
	const labels = {
		"ui.branding": "هوية التطبيق والرئيسية",
		"app_branding": "اسم التطبيق وشعاره",
		"home_banner": "بنر شاشة الدخول",
		"auth_methods": "طرق تسجيل الدخول",
		"ui.bottom_nav": "الشريط السفلي والأيقونات",
		"ui.mic": "شكل الميك المفتوح والمغلق",
		"ui.buttons": "أصول الأزرار",
		"ui.routes": "عناوين وواجهات الصفحات",
		"features": "تشغيل وإيقاف الخدمات",
		"app_update_policy": "قفل الإصدارات وطلب التحديث"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass rounded-2xl p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "مركز تطوير التطبيق" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: "تحكم مركزي في الأسماء والروابط والأصول وشكل الميك والأزرار والشريط السفلي والخدمات. استخدم روابط HTTPS أو روابط Supabase Storage."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto",
				children: Object.keys(defaults).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setActive(k),
					className: `whitespace-nowrap rounded-full px-3 py-2 text-xs ${active === k ? "bg-gold" : "bg-secondary"}`,
					children: labels[k]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-3 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: labels[active] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "min-h-72 w-full rounded-md border border-input bg-input p-3 font-mono text-xs",
						dir: "ltr",
						value: rows[active] ?? defaults[active],
						onChange: (e) => setRows({
							...rows,
							[active]: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "bg-gold",
						disabled: loading,
						onClick: () => void save(active),
						children: "حفظ وتفعيل الإعداد"
					})
				]
			})
		]
	});
}
/** Full administration UI embedded in the Android/web app.
* The static control center is bundled at public/control-center/index.html
* and shares the same origin + Supabase auth storage as the app.
*/
function FullAdminPanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-[100dvh] bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPage, {})
	});
}
var fmt = (d) => new Date(d).toLocaleString("ar-EG");
function AdminPage() {
	const { user } = useAuth();
	const { section: requestedSection } = Route.useSearch();
	const externalAdminUrl = "/control-center/";
	const [allowed, setAllowed] = (0, import_react.useState)(null);
	const [isSuper, setIsSuper] = (0, import_react.useState)(false);
	const [hasAdminRole, setHasAdminRole] = (0, import_react.useState)(false);
	const [sectionPermissions, setSectionPermissions] = (0, import_react.useState)([]);
	const [sectionOnly, setSectionOnly] = (0, import_react.useState)(false);
	const [stats, setStats] = (0, import_react.useState)(null);
	const [tab, setTab] = (0, import_react.useState)("reports");
	async function check() {
		if (!user?.id) {
			setAllowed(false);
			setHasAdminRole(false);
			setIsSuper(false);
			return;
		}
		const [{ data: access }, { data: adminRole }, { data: moderatorRole }, { data: superRole }, { data: sectionData, error: sectionError }] = await Promise.all([
			supabase.rpc("can_access_admin_dashboard"),
			supabase.rpc("is_admin", { _uid: user.id }),
			supabase.rpc("has_role", {
				_user_id: user.id,
				_role: "moderator"
			}),
			supabase.rpc("has_role", {
				_user_id: user.id,
				_role: "super_admin"
			}),
			supabase.rpc("my_admin_permissions")
		]);
		if (sectionError) toast.error(errMsg(sectionError));
		const permissions = sectionData ?? [];
		const isSectionOnly = !superRole && permissions.some((key) => key.startsWith("section_"));
		setSectionPermissions(superRole ? ["*"] : permissions.filter((key) => key.startsWith("section_")));
		setSectionOnly(isSectionOnly);
		setAllowed(access === true || !!superRole || isSectionOnly);
		setHasAdminRole(!!adminRole || !!moderatorRole || !!superRole);
		setIsSuper(!!superRole);
		if ((access === true || !!superRole) && !isSectionOnly) {
			const { data } = await supabase.rpc("admin_stats");
			setStats(data);
		} else setStats(null);
	}
	(0, import_react.useEffect)(() => {
		if (!user?.id) {
			check();
			return;
		}
		check();
		const refresh = () => {
			if (document.visibilityState === "visible") check();
		};
		const channel = supabase.channel(`admin-access-${user.id}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "admin_user_permissions",
			filter: `user_id=eq.${user.id}`
		}, () => {
			check();
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "admin_dashboard_access",
			filter: `user_id=eq.${user.id}`
		}, () => {
			check();
		}).subscribe();
		window.addEventListener("focus", refresh);
		document.addEventListener("visibilitychange", refresh);
		return () => {
			window.removeEventListener("focus", refresh);
			document.removeEventListener("visibilitychange", refresh);
			supabase.removeChannel(channel);
		};
	}, [user?.id]);
	async function refreshStats() {
		if (!allowed) return;
		const { data, error } = await supabase.rpc("admin_stats");
		if (!error && data) setStats(data);
	}
	useAdminRealtime(allowed && !sectionOnly ? [
		"profiles",
		"wallets",
		"wallet_transactions",
		"rooms",
		"room_members",
		"room_seats",
		"gifts",
		"gift_transactions",
		"vip_tiers",
		"banners",
		"notifications",
		"admin_assets",
		"reports",
		"user_roles",
		"admin_settings",
		"audit_log",
		"store_items",
		"posts"
	] : [], refreshStats);
	async function claim() {
		const { data, error } = await supabase.rpc("claim_first_admin");
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		if (!data) {
			toast.error("يوجد مشرف بالفعل — اطلب منه منحك الصلاحية");
			return;
		}
		toast.success("أصبحت المشرف الأعلى");
		check();
	}
	const tabs = [
		{
			id: "reports",
			label: "البلاغات",
			icon: Flag
		},
		{
			id: "rooms",
			label: "الغرف",
			icon: DoorOpen
		},
		{
			id: "seats",
			label: "المقاعد",
			icon: Armchair
		},
		{
			id: "posts",
			label: "المنشورات",
			icon: FileText
		},
		{
			id: "users",
			label: "المستخدمون",
			icon: Users
		},
		{
			id: "wallet",
			label: "المحافظ",
			icon: Wallet
		},
		{
			id: "gifts",
			label: "الهدايا",
			icon: Gift
		},
		{
			id: "vip",
			label: "مستويات VIP",
			icon: Shield
		},
		{
			id: "store",
			label: "المتجر",
			icon: Store
		},
		{
			id: "assets",
			label: "الأصول ثلاثية الأبعاد",
			icon: Image
		},
		{
			id: "banners",
			label: "البانرات",
			icon: PanelsTopLeft
		},
		{
			id: "notifications",
			label: "الإشعارات",
			icon: Bell
		},
		{
			id: "roles",
			label: "صلاحيات الإدارة",
			icon: ShieldCheck
		},
		{
			id: "settings",
			label: "الإعدادات",
			icon: Settings
		},
		{
			id: "app_builder",
			label: "تطوير التطبيق",
			icon: PanelsTopLeft
		},
		{
			id: "analytics",
			label: "التحليلات",
			icon: ChartColumn
		},
		{
			id: "audit",
			label: "سجل الإجراءات",
			icon: ScrollText
		}
	];
	const sectionKey = {
		reports: "section_reports",
		rooms: "section_rooms",
		seats: "section_seats",
		posts: "section_posts",
		users: "section_users",
		wallet: "section_wallet",
		gifts: "section_gifts",
		vip: "section_vip",
		store: "section_store",
		assets: "section_assets",
		banners: "section_banners",
		notifications: "section_notifications",
		roles: "section_roles",
		settings: "section_settings",
		app_builder: "section_app_builder",
		analytics: "section_analytics",
		audit: "section_audit"
	};
	const effectiveTabs = isSuper ? tabs : tabs.filter((item) => sectionPermissions.includes(sectionKey[item.id]));
	const requestedTab = tabs.find((item) => sectionKey[item.id] === requestedSection)?.id;
	const selectedTab = sectionOnly ? effectiveTabs.some((item) => item.id === tab) ? tab : requestedTab && effectiveTabs.some((item) => item.id === requestedTab) ? requestedTab : effectiveTabs[0]?.id ?? tab : tab;
	(0, import_react.useEffect)(() => {
		if (effectiveTabs.length > 0 && !effectiveTabs.some((item) => item.id === tab)) setTab(effectiveTabs[0].id);
	}, [effectiveTabs.map((item) => item.id).join("|"), tab]);
	if (allowed === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-10 text-center text-muted-foreground",
		children: "جارٍ التحقق…"
	});
	if (!allowed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md p-6 pt-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "mx-auto h-14 w-14 text-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-gold mt-4 text-3xl",
				children: "لوحة التحكم"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: hasAdminRole ? "صلاحية ظهور لوحة التحكم غير مفعّلة لهذا الحساب. اطلب من المشرف الأعلى تفعيلها لك." : "ليست لديك صلاحية إدارة. إذا لم يكن هناك مشرف بعد يمكنك المطالبة بالصلاحية كأول مشرف."
			}),
			!hasAdminRole && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-6 w-full bg-gold",
				onClick: claim,
				children: "المطالبة بصلاحية المشرف الأول"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-4 block text-sm text-muted-foreground",
				children: "العودة للتطبيق"
			})
		]
	});
	if (sectionOnly && effectiveTabs.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md p-6 pt-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "mx-auto h-14 w-14 text-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-gold mt-4 text-3xl",
				children: "لا توجد صلاحية قسم فعالة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-4 block text-sm text-muted-foreground",
				children: "العودة للتطبيق"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-center justify-between gap-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-gold text-3xl",
					children: sectionOnly ? "إدارة القسم" : "لوحة التحكم"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [!sectionOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: externalAdminUrl,
						target: "_blank",
						rel: "noreferrer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "mr-1 h-4 w-4" }), " اللوحة الخارجية"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-sm text-muted-foreground",
						children: "← التطبيق"
					})]
				})]
			}),
			!sectionOnly && stats && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7",
				children: Object.entries({
					users: "المستخدمون",
					rooms: "الغرف",
					seats: "المقاعد",
					vip_users: "مستخدمو VIP",
					wallet_coins: "إجمالي العملات",
					wallet_diamonds: "إجمالي الماسات",
					gifts: "الهدايا",
					reports_open: "البلاغات المفتوحة",
					assets: "الأصول",
					banners: "الإعلانات",
					notifications: "الإشعارات"
				}).map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-3d glass rounded-2xl p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-2xl font-bold text-primary",
						children: Number(stats[k] ?? 0).toLocaleString()
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: l
					})]
				}, k))
			}),
			effectiveTabs.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-2 overflow-x-auto",
				children: effectiveTabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setTab(t.id),
					className: `flex items-center gap-1 whitespace-nowrap rounded-full px-4 py-2 text-sm ${selectedTab === t.id ? "bg-gold" : "glass"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "h-4 w-4" }), t.label]
				}, t.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [
					selectedTab === "reports" && (isSuper || sectionPermissions.includes("section_reports")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reports, {}),
					selectedTab === "rooms" && (isSuper || sectionPermissions.includes("section_rooms")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rooms, {}),
					selectedTab === "seats" && (isSuper || sectionPermissions.includes("section_seats")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeatsTab, {}),
					selectedTab === "posts" && (isSuper || sectionPermissions.includes("section_posts")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Posts, {}),
					selectedTab === "users" && (isSuper || sectionPermissions.includes("section_users")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersTab, { isSuper }),
					selectedTab === "wallet" && (isSuper || sectionPermissions.includes("section_wallet")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletTab, {}),
					selectedTab === "gifts" && (isSuper || sectionPermissions.includes("section_gifts")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GiftsTab, {}),
					selectedTab === "vip" && (isSuper || sectionPermissions.includes("section_vip")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VipTab, {}),
					selectedTab === "store" && (isSuper || sectionPermissions.includes("section_store")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreTab, {}),
					selectedTab === "assets" && (isSuper || sectionPermissions.includes("section_assets")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetsTab, {}),
					selectedTab === "banners" && (isSuper || sectionPermissions.includes("section_banners")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BannersTab, {}),
					selectedTab === "notifications" && (isSuper || sectionPermissions.includes("section_notifications")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationsTab, {}),
					selectedTab === "roles" && (isSuper || sectionPermissions.includes("section_roles")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminRolesTab, { isSuper }),
					selectedTab === "settings" && (isSuper || sectionPermissions.includes("section_settings")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsTab, {}),
					selectedTab === "app_builder" && (isSuper || sectionPermissions.includes("section_app_builder")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBuilderTab, {}),
					selectedTab === "analytics" && (isSuper || sectionPermissions.includes("section_analytics")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalyticsTab, {}),
					selectedTab === "audit" && (isSuper || sectionPermissions.includes("section_audit")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditTab, {})
				]
			})
		]
	});
}
var STATUS = {
	open: "مفتوح",
	reviewing: "قيد المراجعة",
	resolved: "تم الحل",
	rejected: "مرفوض"
};
function Reports() {
	const [status, setStatus] = (0, import_react.useState)("open");
	const [rows, setRows] = (0, import_react.useState)([]);
	const [reply, setReply] = (0, import_react.useState)({});
	async function load() {
		const { data, error } = await supabase.rpc("admin_list_reports", { _status: status });
		if (error) toast.error(errMsg(error));
		setRows(data ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [status]);
	useAdminRealtime(["reports"], load);
	async function act(id, s) {
		const { error } = await supabase.rpc("admin_resolve_report", {
			_report: id,
			_status: s,
			_reply: reply[id] ?? ""
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم التحديث");
		load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: [
					"open",
					"reviewing",
					"resolved",
					"rejected",
					""
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setStatus(s),
					className: `rounded-full px-3 py-1 text-xs ${status === s ? "bg-accent text-accent-foreground" : "bg-secondary"}`,
					children: s ? STATUS[s] : "الكل"
				}, s))
			}),
			rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "glass rounded-2xl p-6 text-center text-muted-foreground",
				children: "لا توجد بلاغات"
			}),
			rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-2 rounded-2xl p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
							r.category,
							" · ",
							r.target_type
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted-foreground",
							children: [
								STATUS[r.status],
								" · ",
								fmt(r.created_at)
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: r.details }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground",
						children: [
							"المبلّغ: ",
							r.reporter_name ?? "—",
							" · الهدف: ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								dir: "ltr",
								children: r.target_id ?? "—"
							})
						]
					}),
					r.admin_reply && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-primary",
						children: ["الرد: ", r.admin_reply]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "رد المشرف (اختياري)",
						value: reply[r.id] ?? "",
						onChange: (e) => setReply({
							...reply,
							[r.id]: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => act(r.id, "reviewing"),
								children: "قيد المراجعة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "bg-gold",
								onClick: () => act(r.id, "resolved"),
								children: "تم الحل"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "destructive",
								onClick: () => act(r.id, "rejected"),
								children: "رفض"
							})
						]
					})
				]
			}, r.id))
		]
	});
}
function Rooms() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [q, setQ] = (0, import_react.useState)("");
	const [frameRef, setFrameRef] = (0, import_react.useState)({});
	const [roomOrder, setRoomOrder] = (0, import_react.useState)({});
	async function load() {
		let query = supabase.from("rooms").select("id,room_no,name,member_count,created_at,is_private,room_frame_asset_key,sort_order").order("created_at", { ascending: false }).limit(100);
		if (q) query = /^\d+$/.test(q) ? query.eq("room_no", Number(q)) : query.ilike("name", `%${q}%`);
		const { data } = await query;
		setRows(data ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime(["rooms", "room_members"], load);
	async function del(id) {
		if (!confirm("حذف الغرفة نهائياً؟")) return;
		const { error } = await supabase.rpc("admin_delete_room", { _room: id });
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم الحذف");
		load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "بحث بالاسم أو الرقم"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: load,
				children: "بحث"
			})]
		}), rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass space-y-2 rounded-2xl p-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/room/$id",
				params: { id: r.id },
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "truncate font-bold",
					children: [
						r.name,
						" ",
						r.is_private && "🔒"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground",
					children: [
						"#",
						r.room_no,
						" · ",
						r.member_count,
						" عضو · ",
						fmt(r.created_at)
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "w-20",
						type: "number",
						min: "0",
						placeholder: "ترتيب",
						value: roomOrder[r.id] ?? String(r.sort_order ?? 0),
						onChange: (e) => setRoomOrder((s) => ({
							...s,
							[r.id]: e.target.value
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: async () => {
							const { error } = await supabase.from("rooms").update({ sort_order: Number(roomOrder[r.id] ?? r.sort_order ?? 0) }).eq("id", r.id);
							if (error) toast.error(errMsg(error));
							else {
								toast.success("تم حفظ ترتيب الغرفة");
								load();
							}
						},
						children: "حفظ الترتيب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "min-w-0 flex-1",
						dir: "ltr",
						placeholder: "asset_key / مسار إطار الغرفة",
						value: frameRef[r.id] ?? r.room_frame_asset_key ?? "",
						onChange: (e) => setFrameRef((s) => ({
							...s,
							[r.id]: e.target.value
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: async () => {
							const { error } = await supabase.rpc("set_room_frame", {
								_room: r.id,
								_asset_key: (frameRef[r.id] ?? "").trim() || null
							});
							if (error) toast.error(errMsg(error));
							else {
								toast.success("تم تخصيص إطار الغرفة");
								load();
							}
						},
						children: "تخصيص الإطار"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "destructive",
						onClick: () => void del(r.id),
						"aria-label": `حذف ${r.name}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "ml-1 h-4 w-4" }), "حذف"]
					})
				]
			})]
		}, r.id))]
	});
}
function Posts() {
	const [rows, setRows] = (0, import_react.useState)([]);
	async function load() {
		const { data } = await supabase.from("posts").select("id,body,like_count,created_at,profiles!posts_user_id_fkey(display_name)").order("created_at", { ascending: false }).limit(100);
		setRows(data ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime(["posts"], load);
	async function del(id) {
		if (!confirm("حذف المنشور؟")) return;
		const { error } = await supabase.rpc("admin_delete_post", { _post: id });
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم الحذف");
		load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "glass rounded-2xl p-6 text-center text-muted-foreground",
			children: "لا توجد منشورات"
		}), rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass flex items-start justify-between gap-2 rounded-2xl p-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground",
					children: [
						p.profiles?.display_name,
						" · ",
						fmt(p.created_at),
						" · ❤ ",
						p.like_count
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "line-clamp-3",
					children: p.body
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon",
				variant: "destructive",
				onClick: () => del(p.id),
				"aria-label": "حذف",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
			})]
		}, p.id))]
	});
}
function UsersTab({ isSuper }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([]);
	const [amt, setAmt] = (0, import_react.useState)({});
	const [catalog, setCatalog] = (0, import_react.useState)([]);
	const [identity, setIdentity] = (0, import_react.useState)({});
	const [userBans, setUserBans] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [deviceBans, setDeviceBans] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [permissions, setPermissions] = (0, import_react.useState)([]);
	const [registeredDevices, setRegisteredDevices] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [selectedItem, setSelectedItem] = (0, import_react.useState)({});
	const [equipItem, setEquipItem] = (0, import_react.useState)({});
	const [directAsset, setDirectAsset] = (0, import_react.useState)({});
	const [assetOptions, setAssetOptions] = (0, import_react.useState)([]);
	async function load() {
		const [{ data, error }, { data: items, error: itemsError }, { data: profiles, error: profilesError }, { data: userBanRows, error: userBanError }, { data: deviceBanRows, error: deviceBanError }, { data: deviceRows, error: deviceError }, { data: myPermissions, error: permissionsError }] = await Promise.all([
			supabase.rpc("admin_list_users", { _q: q }),
			supabase.from("store_items").select("id,name,kind,asset_key").order("name"),
			supabase.from("profiles").select("id,id_color"),
			supabase.from("user_bans").select("user_id,expires_at,revoked_at"),
			supabase.from("device_bans").select("user_id,expires_at,revoked_at"),
			supabase.from("device_accounts").select("user_id"),
			supabase.rpc("my_admin_permissions")
		]);
		const { data: availableAssets, error: assetsError } = await supabase.from("admin_assets").select("id,name,asset_key,category").eq("is_active", true).order("name");
		if (assetsError) toast.error(errMsg(assetsError));
		setAssetOptions(availableAssets ?? []);
		if (error) toast.error(errMsg(error));
		if (itemsError) toast.error(errMsg(itemsError));
		if (profilesError) toast.error(errMsg(profilesError));
		if (userBanError) toast.error(errMsg(userBanError));
		if (deviceBanError) toast.error(errMsg(deviceBanError));
		if (deviceError) toast.error(errMsg(deviceError));
		if (permissionsError) toast.error(errMsg(permissionsError));
		setPermissions(myPermissions ?? []);
		const isActiveBan = (row) => !row.revoked_at && (!row.expires_at || new Date(row.expires_at).getTime() > Date.now());
		setUserBans(new Set((userBanRows ?? []).filter(isActiveBan).map((row) => row.user_id)));
		setDeviceBans(new Set((deviceBanRows ?? []).filter(isActiveBan).map((row) => row.user_id).filter((id) => !!id)));
		setRegisteredDevices(new Set((deviceRows ?? []).map((row) => row.user_id)));
		const users = data ?? [];
		setRows(users);
		setCatalog(items ?? []);
		const colors = Object.fromEntries((profiles ?? []).map((p) => [p.id, p.id_color || "#D4AF37"]));
		setIdentity((current) => {
			const next = { ...current };
			users.forEach((u) => {
				next[u.id] ??= {
					display_no: String(u.display_no),
					level: String(u.level),
					id_color: colors[u.id] || "#D4AF37",
					name_color: colors[u.id] || "#D4AF37",
					name_effect: "none",
					name_effect_speed: "1800"
				};
			});
			return next;
		});
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime([
		"profiles",
		"wallets",
		"user_roles",
		"store_items",
		"user_items",
		"user_bans",
		"device_bans",
		"device_accounts"
	], load);
	async function run(p, msg) {
		const { error } = await p;
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success(msg);
		await load();
	}
	const can = (permission) => isSuper || permissions.includes(permission);
	async function saveIdentity(u) {
		if (!can("edit_user_id")) {
			toast.error("لا تملك صلاحية تعديل ID");
			return;
		}
		const value = identity[u.id] ?? {
			display_no: String(u.display_no),
			level: String(u.level),
			id_color: "#D4AF37",
			name_color: "#D4AF37",
			name_effect: "none",
			name_effect_speed: "1800"
		};
		const displayNo = Number(value.display_no), level = Number(value.level);
		if (!Number.isSafeInteger(displayNo) || displayNo < 1e5 || !Number.isInteger(level) || level < 1 || level > 999) {
			toast.error("تحقق من رقم ID والمستوى");
			return;
		}
		await run(supabase.rpc("admin_update_user_identity", {
			_user: u.id,
			_display_no: displayNo,
			_level: level,
			_id_color: value.id_color
		}), "تم حفظ ID المميز ولونه والمستوى");
		await run(supabase.rpc("admin_set_profile_style", {
			_user: u.id,
			_name_color: value.name_color,
			_name_effect: value.name_effect,
			_speed: Number(value.name_effect_speed)
		}), "تم حفظ لون الاسم وتأثيره");
	}
	async function sendDirectAsset(u) {
		const v = directAsset[u.id] ?? {
			ref: "",
			name: "",
			type: "frame",
			duration: "0",
			unit: "hours"
		};
		const permission = v.type === "frame" ? "send_frame" : v.type === "entry" ? "send_entry" : v.type === "badge" ? "send_badge" : "send_profile_assets";
		if (!can(permission)) {
			toast.error("لا تملك صلاحية إرسال هذا النوع من الأصول");
			return;
		}
		if (!v.ref.trim() || !v.name.trim()) {
			toast.error("أدخل رابط/مفتاح الأصل واسم الأصل");
			return;
		}
		const amount = Number(v.duration);
		if (!Number.isInteger(amount) || amount < 0) {
			toast.error("أدخل مدة صحيحة؛ 0 = بدون انتهاء");
			return;
		}
		const hours = amount === 0 ? 0 : v.unit === "days" ? amount * 24 : amount;
		if (hours > 87600) {
			toast.error("المدة القصوى 87600 ساعة");
			return;
		}
		await run(supabase.rpc("send_asset_to_user", {
			_receiver: u.id,
			_asset_key: v.ref.trim(),
			_asset_type: v.type,
			_asset_name: v.name.trim(),
			_hours: hours
		}), amount === 0 ? "تم إرسال الأصل بدون انتهاء" : `تم إرسال الأصل لمدة ${amount} ${v.unit === "days" ? "يوم" : "ساعة"}`);
	}
	async function updateBan(u, kind, banned) {
		if (!can(kind === "account" ? "ban_account" : "ban_device")) {
			toast.error("لا تملك صلاحية الحظر المطلوبة");
			return;
		}
		let reason = "";
		let hours = null;
		if (banned) {
			const enteredReason = window.prompt(kind === "account" ? "سبب حظر الحساب" : "سبب حظر الجهاز", "مخالفة قواعد التطبيق");
			if (enteredReason === null) return;
			reason = enteredReason.trim();
			const enteredHours = window.prompt("مدة الحظر بالساعات (اكتب 0 للحظر الدائم)", "24");
			if (enteredHours === null) return;
			const parsedHours = Number(enteredHours);
			if (!Number.isInteger(parsedHours) || parsedHours < 0 || parsedHours > 87600) {
				toast.error("مدة الحظر يجب أن تكون 0 أو عدد ساعات حتى 87600");
				return;
			}
			hours = parsedHours === 0 ? null : parsedHours;
		}
		const rpc = kind === "account" ? "admin_set_user_ban" : "admin_set_device_ban";
		const { error } = await supabase.rpc(rpc, {
			_user: u.id,
			_banned: banned,
			_reason: reason,
			_hours: hours
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success(kind === "account" ? banned ? "تم حظر الحساب من التطبيق" : "تم رفع حظر الحساب" : banned ? "تم حظر الجهاز" : "تم رفع حظر الجهاز");
		await load();
	}
	async function grantItem(u) {
		const itemId = selectedItem[u.id];
		if (!itemId) {
			toast.error("اختر عنصراً من المتجر أولاً");
			return;
		}
		const item = catalog.find((entry) => entry.id === itemId);
		const permission = item?.kind === "frame" ? "send_frame" : item?.kind === "entry" ? "send_entry" : item?.kind === "badge" ? "send_badge" : "send_profile_assets";
		if (!can(permission)) {
			toast.error("لا تملك صلاحية إرسال هذا العنصر");
			return;
		}
		if (equipItem[u.id] && item?.kind !== "frame" && item?.kind !== "entry") {
			toast.error("يمكن تجهيز الإطار أو الدخولية فقط؛ الشارات تُضاف للمخزون");
			return;
		}
		await run(supabase.rpc("admin_grant_store_item", {
			_user: u.id,
			_item: itemId,
			_equip: !!equipItem[u.id]
		}), "تم إرسال العنصر إلى مخزون المستخدم");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "بحث بالاسم أو ID"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void load(),
				children: "بحث"
			})]
		}), rows.map((u) => {
			const edit = identity[u.id] ?? {
				display_no: String(u.display_no),
				level: String(u.level),
				id_color: "#D4AF37",
				name_color: "#D4AF37",
				name_effect: "none",
				name_effect_speed: "1800"
			};
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-3 rounded-2xl p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/u/$id",
							params: { id: u.id },
							className: "font-bold",
							children: [
								u.display_name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: ["ID ", u.display_no]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs",
							children: [
								"Lv ",
								u.level,
								" · VIP ",
								u.vip_level,
								" · 🪙 ",
								Number(u.coins).toLocaleString(),
								" ",
								u.roles.length > 0 && `· ${u.roles.join(", ")}`
							]
						})]
					}),
					can("edit_user_id") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted-foreground",
								children: ["ID المميز", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "100000",
									value: edit.display_no,
									onChange: (e) => setIdentity((s) => ({
										...s,
										[u.id]: {
											...edit,
											display_no: e.target.value
										}
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted-foreground",
								children: ["المستوى", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "1",
									max: "999",
									value: edit.level,
									onChange: (e) => setIdentity((s) => ({
										...s,
										[u.id]: {
											...edit,
											level: e.target.value
										}
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted-foreground",
								children: ["لون ID", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									"aria-label": "لون ID المميز",
									type: "color",
									value: edit.id_color,
									onChange: (e) => setIdentity((s) => ({
										...s,
										[u.id]: {
											...edit,
											id_color: e.target.value
										}
									})),
									className: "h-10 w-full rounded-md border border-input bg-input p-1"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted-foreground",
								children: ["لون الاسم", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									"aria-label": "لون الاسم",
									type: "color",
									value: edit.name_color,
									onChange: (e) => setIdentity((s) => ({
										...s,
										[u.id]: {
											...edit,
											name_color: e.target.value
										}
									})),
									className: "h-10 w-full rounded-md border border-input bg-input p-1"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								"aria-label": "تأثير الاسم",
								value: edit.name_effect,
								onChange: (e) => setIdentity((s) => ({
									...s,
									[u.id]: {
										...edit,
										name_effect: e.target.value
									}
								})),
								className: "rounded-md border border-input bg-input px-2 py-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "none",
										children: "اسم ثابت"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "shimmer",
										children: "لمعة متحركة"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "pulse",
										children: "نبض"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "rainbow",
										children: "ألوان متحركة"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "500",
								max: "5000",
								"aria-label": "سرعة تأثير الاسم",
								value: edit.name_effect_speed,
								onChange: (e) => setIdentity((s) => ({
									...s,
									name_effect_speed: e.target.value
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "self-end",
								size: "sm",
								onClick: () => void saveIdentity(u),
								children: "حفظ الهوية المميزة"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [can("manage_wallet") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "w-28",
							type: "number",
							placeholder: "عملات ±",
							value: amt[u.id] ?? "",
							onChange: (e) => setAmt({
								...amt,
								[u.id]: e.target.value
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => void run(supabase.rpc("admin_grant_coins", {
								_user: u.id,
								_amount: Number(amt[u.id] || 0)
							}), "تم تعديل الرصيد"),
							children: "تطبيق الرصيد"
						})] }), can("manage_vip") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							"aria-label": "مستوى VIP",
							className: "rounded-md border border-input bg-input px-2 py-1.5 text-xs",
							value: u.vip_level,
							onChange: (e) => void run(supabase.rpc("admin_set_vip", {
								_user: u.id,
								_vip: Number(e.target.value)
							}), "تم تعديل VIP"),
							children: Array.from({ length: 11 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: i,
								children: ["VIP ", i]
							}, i))
						})]
					}),
					(can("ban_account") || can("ban_device")) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 rounded-xl border border-destructive/20 bg-destructive/5 p-2",
						children: [
							can("ban_account") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: userBans.has(u.id) ? "outline" : "destructive",
								onClick: () => void updateBan(u, "account", !userBans.has(u.id)),
								children: userBans.has(u.id) ? "رفع حظر الحساب" : "حظر الحساب من التطبيق"
							}),
							can("ban_device") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: deviceBans.has(u.id) ? "outline" : "destructive",
								disabled: !registeredDevices.has(u.id) && !deviceBans.has(u.id),
								onClick: () => void updateBan(u, "device", !deviceBans.has(u.id)),
								children: deviceBans.has(u.id) ? "رفع حظر الجهاز" : "حظر الجهاز"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-muted-foreground",
								children: registeredDevices.has(u.id) ? "الجهاز مسجل" : "لم يسجل الجهاز دخوله بعد"
							})
						]
					}),
					(can("send_frame") || can("send_entry") || can("send_badge") || can("send_profile_assets")) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-[1fr_auto_auto]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								"aria-label": "اختر عنصراً لإرساله",
								className: "min-w-0 rounded-md border border-input bg-input px-2 py-2 text-xs",
								value: selectedItem[u.id] ?? "",
								onChange: (e) => setSelectedItem((s) => ({
									...s,
									[u.id]: e.target.value
								})),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "اختر عنصراً لإرساله"
								}), catalog.filter((item) => can(item.kind === "frame" ? "send_frame" : item.kind === "entry" ? "send_entry" : item.kind === "badge" ? "send_badge" : "send_profile_assets")).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: item.id,
									children: [
										item.name,
										" · ",
										item.kind
									]
								}, item.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: !!equipItem[u.id],
									onChange: (e) => setEquipItem((s) => ({
										...s,
										[u.id]: e.target.checked
									}))
								}), " تجهيز فوراً (إطار/دخولية)"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								disabled: !selectedItem[u.id],
								onClick: () => void grantItem(u),
								children: "إرسال للمستخدم"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-primary/15 bg-background/40 p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs font-bold text-primary",
							children: "إرسال أصل مباشر من تخزين Supabase — بدون إدخاله في المتجر"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "rounded-md border border-input bg-input px-2 py-2 text-xs",
									value: directAsset[u.id]?.type ?? (can("send_frame") ? "frame" : can("send_entry") ? "entry" : can("send_badge") ? "badge" : "bubble"),
									onChange: (e) => setDirectAsset((s) => ({
										...s,
										[u.id]: {
											...s[u.id] ?? {
												ref: "",
												name: "",
												type: "frame"
											},
											type: e.target.value
										}
									})),
									children: [
										can("send_frame") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "frame",
											children: "إطار"
										}),
										can("send_entry") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "entry",
											children: "دخولية"
										}),
										can("send_badge") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "badge",
											children: "شارة"
										}),
										can("send_profile_assets") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "bubble",
												children: "فقاعة كتابة"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "sound_wave",
												children: "موجة صوت"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "profile_card",
												children: "بطاقة تعريف"
											})
										] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									"aria-label": "اختيار أصل من مكتبة التخزين",
									className: "col-span-2 rounded-md border border-input bg-input px-2 py-2 text-xs",
									value: directAsset[u.id]?.ref ?? "",
									onChange: (e) => {
										const asset = assetOptions.find((item) => item.asset_key === e.target.value);
										setDirectAsset((s) => ({
											...s,
											[u.id]: {
												...s[u.id] ?? {
													ref: "",
													name: "",
													type: "frame",
													duration: "0",
													unit: "hours"
												},
												ref: asset?.asset_key ?? "",
												name: asset?.name ?? ""
											}
										}));
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "اختر الأصل من مكتبة Supabase Storage"
									}), assetOptions.map((asset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: asset.asset_key,
										children: [
											asset.name,
											" · ",
											asset.category,
											" · ",
											asset.asset_key
										]
									}, asset.id))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "col-span-2 grid grid-cols-[1fr_110px] gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: "0",
										max: "87600",
										step: "1",
										placeholder: "مدة مخصصة (0 = دائم)",
										value: directAsset[u.id]?.duration ?? "0",
										onChange: (e) => setDirectAsset((s) => ({
											...s,
											[u.id]: {
												...s[u.id] ?? {
													ref: "",
													name: "",
													type: "frame",
													duration: "0",
													unit: "hours"
												},
												duration: e.target.value
											}
										}))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										"aria-label": "وحدة مدة الأصل",
										className: "rounded-md border border-input bg-input px-2 py-2 text-xs",
										value: directAsset[u.id]?.unit ?? "hours",
										onChange: (e) => setDirectAsset((s) => ({
											...s,
											[u.id]: {
												...s[u.id] ?? {
													ref: "",
													name: "",
													type: "frame",
													duration: "0",
													unit: "hours"
												},
												unit: e.target.value
											}
										})),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "hours",
											children: "ساعات"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "days",
											children: "أيام"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "col-span-2 flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: "المدة تبدأ من لحظة الإرسال · 0 = بدون انتهاء"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										disabled: !directAsset[u.id]?.ref,
										onClick: () => void sendDirectAsset(u),
										children: "إرسال الأصل"
									})]
								})
							]
						})]
					})] }),
					isSuper && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1",
						children: ["admin", "moderator"].map((r) => {
							const has = u.roles.includes(r);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: has ? "destructive" : "outline",
								onClick: () => void run(supabase.rpc("admin_set_role", {
									_user: u.id,
									_role: r,
									_grant: !has
								}), "تم تحديث الصلاحية"),
								children: has ? `إزالة ${r}` : `منح ${r}`
							}, r);
						})
					})
				]
			}, u.id);
		})]
	});
}
function WalletTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [topups, setTopups] = (0, import_react.useState)([]);
	async function load() {
		const [{ data, error }, { data: requests, error: reqError }] = await Promise.all([supabase.rpc("admin_list_wallet_tx", { _limit: 200 }), supabase.from("wallet_topup_requests").select("id,user_id,coins,payment_method,reference,status,admin_note,created_at").order("created_at", { ascending: false }).limit(100)]);
		if (error) toast.error(errMsg(error));
		if (reqError) toast.error(errMsg(reqError));
		setRows(data ?? []);
		setTopups(requests ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime([
		"wallet_transactions",
		"wallets",
		"wallet_topup_requests"
	], load);
	async function decide(id, status) {
		const note = prompt(status === "approved" ? "ملاحظة الشحن (اختياري)" : "سبب الرفض (اختياري)") ?? "";
		const { error } = await supabase.rpc("admin_decide_wallet_topup", {
			_request: id,
			_status: status,
			_note: note
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success(status === "approved" ? "تم اعتماد الشحن وإضافة العملات" : "تم رفض طلب الشحن");
		load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass rounded-2xl p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-3 font-bold",
				children: "طلبات شحن المحفظة"
			}), topups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "لا توجد طلبات شحن"
			}) : topups.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-background/50 p-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [Number(r.coins).toLocaleString(), " 🪙"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground",
					dir: "ltr",
					children: [
						r.user_id,
						" · ",
						r.payment_method,
						" · ",
						r.reference || "بدون مرجع",
						" · ",
						fmt(r.created_at)
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs",
						children: r.status
					}), r.status === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "bg-gold",
						onClick: () => void decide(r.id, "approved"),
						children: "اعتماد"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "destructive",
						onClick: () => void decide(r.id, "rejected"),
						children: "رفض"
					})] })]
				})]
			}, r.id))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold",
					children: "سجل معاملات المحافظ"
				}),
				rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "glass rounded-2xl p-6 text-center text-muted-foreground",
					children: "لا توجد معاملات"
				}),
				rows.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass flex items-center justify-between gap-2 rounded-2xl p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: t.display_name ?? "مستخدم" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground",
						children: [
							t.kind,
							" · ",
							t.note,
							" · ",
							fmt(t.created_at)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
						className: t.amount >= 0 ? "text-green-400" : "text-red-400",
						children: [
							t.amount >= 0 ? "+" : "",
							Number(t.amount).toLocaleString(),
							" 🪙"
						]
					})]
				}, i))
			]
		})]
	});
}
function GiftsTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [luckyRows, setLuckyRows] = (0, import_react.useState)([]);
	const [luckyForm, setLuckyForm] = (0, import_react.useState)({
		name: "",
		asset_key: "",
		price: "1000",
		win_chance: "10",
		min_reward: "0",
		max_reward: "5000"
	});
	const [catalog, setCatalog] = (0, import_react.useState)([]);
	const [categories, setCategories] = (0, import_react.useState)([]);
	const [categoryName, setCategoryName] = (0, import_react.useState)("");
	const [categoryMode, setCategoryMode] = (0, import_react.useState)("static");
	const [luckyBar, setLuckyBar] = (0, import_react.useState)({
		enabled: true,
		position: "top",
		duration_ms: "3000",
		width_px: "390",
		gift_size_px: "48",
		show_name: true,
		asset_key: "",
		global_min_reward: "10000"
	});
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		emoji: "🎁",
		price_coins: "100",
		asset_url: "",
		category_id: "",
		animation_style: "zoom",
		animation_speed: "1",
		display_duration_ms: "2600"
	});
	async function load() {
		const [{ data, error }, { data: gifts, error: catalogError }, { data: lucky, error: luckyError }, { data: cats, error: categoryError }] = await Promise.all([
			supabase.rpc("admin_list_gift_tx", { _limit: 200 }),
			supabase.from("gifts").select("id,name,emoji,price,active,asset_url,category_id,animation_style,animation_speed,display_duration_ms").order("sort"),
			supabase.from("lucky_gifts").select("id,name,asset_key,price,win_chance,min_reward,max_reward,active").order("sort_order").order("price"),
			supabase.from("gift_categories").select("id,name,display_mode,sort_order,is_active").order("sort_order")
		]);
		const { data: barConfig, error: barError } = await supabase.from("lucky_gift_bar_config").select("*").eq("id", true).maybeSingle();
		if (barError) toast.error(errMsg(barError));
		if (error) toast.error(errMsg(error));
		if (catalogError) toast.error(errMsg(catalogError));
		if (luckyError) toast.error(errMsg(luckyError));
		if (categoryError) toast.error(errMsg(categoryError));
		setRows(data ?? []);
		setCatalog(gifts ?? []);
		setLuckyRows(lucky ?? []);
		setCategories(cats ?? []);
		if (barConfig) setLuckyBar({
			enabled: barConfig.enabled !== false,
			position: barConfig.position ?? "top",
			duration_ms: "3000",
			width_px: String(barConfig.width_px ?? 390),
			gift_size_px: String(barConfig.gift_size_px ?? 48),
			show_name: barConfig.show_name !== false,
			asset_key: String(barConfig.asset_key ?? ""),
			global_min_reward: String(barConfig.global_min_reward ?? 1e4)
		});
	}
	async function saveLuckyBar() {
		const duration_ms = Math.min(15e3, Math.max(1500, Number(luckyBar.duration_ms) || 5200));
		const width_px = Math.min(700, Math.max(220, Number(luckyBar.width_px) || 390));
		const gift_size_px = Math.min(140, Math.max(32, Number(luckyBar.gift_size_px) || 56));
		const payload = {
			id: true,
			enabled: luckyBar.enabled,
			position: luckyBar.position,
			duration_ms,
			width_px,
			gift_size_px,
			show_name: luckyBar.show_name,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		};
		const { error } = await supabase.from("lucky_gift_bar_config").upsert(payload);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم حفظ إعدادات شريط هدايا الحظ");
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime([
		"gifts",
		"gift_transactions",
		"gift_categories",
		"lucky_gifts",
		"lucky_gift_bar_config"
	], load);
	async function saveGift() {
		if (!form.name.trim() || !form.emoji.trim() || !Number.isFinite(Number(form.price_coins)) || Number(form.price_coins) < 0) {
			toast.error("أدخل اسم الهدية ورمزها وسعراً صحيحاً");
			return;
		}
		const { error } = await supabase.from("gifts").insert({
			name: form.name.trim(),
			emoji: form.emoji.trim(),
			price: Number(form.price_coins),
			active: true,
			asset_url: form.asset_url.trim() || null,
			category_id: form.category_id || null,
			animation_style: form.animation_style,
			animation_speed: Number(form.animation_speed),
			display_duration_ms: Number(form.display_duration_ms)
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم حفظ الهدية في الكتالوج");
		setForm({
			name: "",
			emoji: "🎁",
			price_coins: "100",
			asset_url: "",
			category_id: "",
			animation_style: "zoom",
			animation_speed: "1",
			display_duration_ms: "2600"
		});
		load();
	}
	async function toggleGift(g) {
		const { error } = await supabase.from("gifts").update({ active: !g.active }).eq("id", g.id);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		load();
	}
	async function deleteGift(g) {
		if (!confirm("حذف الهدية من الكتالوج؟")) return;
		const { error } = await supabase.from("gifts").delete().eq("id", g.id);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-3 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "إدارة كتالوج الهدايا" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "اسم الهدية",
								value: form.name,
								onChange: (e) => setForm({
									...form,
									name: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "الرمز أو الإيموجي",
								value: form.emoji,
								onChange: (e) => setForm({
									...form,
									emoji: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								placeholder: "السعر بالعملات",
								value: form.price_coins,
								onChange: (e) => setForm({
									...form,
									price_coins: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "rounded-md border border-input bg-input px-3 py-2 text-sm",
								value: form.category_id,
								onChange: (e) => setForm({
									...form,
									category_id: e.target.value
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "بدون قسم"
								}), categories.filter((c) => c.is_active).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: c.id,
									children: [
										c.name,
										" · ",
										c.display_mode === "static" ? "ثابتة" : "متحركة"
									]
								}, c.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "رابط أو مسار أصل الهدية",
								value: form.asset_url,
								onChange: (e) => setForm({
									...form,
									asset_url: e.target.value
								}),
								dir: "ltr",
								className: "col-span-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted-foreground",
								children: ["شكل الحركة", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "mt-1 w-full rounded-md border border-input bg-input p-2",
									value: form.animation_style,
									onChange: (e) => setForm({
										...form,
										animation_style: e.target.value
									}),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "zoom",
											children: "تكبير سينمائي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "slide",
											children: "انزلاق"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "float",
											children: "طفو"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "pulse",
											children: "نبض"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted-foreground",
								children: ["سرعة الحركة", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "mt-1 w-full rounded-md border border-input bg-input p-2",
									value: form.animation_speed,
									onChange: (e) => setForm({
										...form,
										animation_speed: e.target.value
									}),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0.5",
											children: "بطيئة جدًا"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0.75",
											children: "بطيئة"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1",
											children: "طبيعية"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1.5",
											children: "سريعة"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "2",
											children: "سريعة جدًا"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "col-span-2",
								type: "number",
								min: "500",
								max: "20000",
								step: "500",
								placeholder: "مدة العرض بالمللي ثانية",
								value: form.display_duration_ms,
								onChange: (e) => setForm({
									...form,
									display_duration_ms: e.target.value
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "bg-gold",
						onClick: saveGift,
						children: "حفظ الهدية"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "glass space-y-3 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "أقسام شريط الهدايا داخل الغرفة" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "أنشئ تبويبًا يظهر أعلى قائمة الهدايا، ثم اختر نمط عرضه وحدد القسم عند إضافة كل هدية."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "اسم القسم الجديد",
							value: categoryName,
							onChange: (e) => setCategoryName(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "rounded-md border border-input bg-input px-3 py-2 text-sm",
							value: categoryMode,
							onChange: (e) => setCategoryMode(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "static",
								children: "عرض ثابت"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "animated",
								children: "عرض متحرك"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: async () => {
							if (!categoryName.trim()) {
								toast.error("اكتب اسم القسم");
								return;
							}
							const { error } = await supabase.from("gift_categories").insert({
								name: categoryName.trim(),
								display_mode: categoryMode,
								sort_order: categories.length
							});
							if (error) toast.error(errMsg(error));
							else {
								toast.success("تم إنشاء قسم الهدايا");
								setCategoryName("");
								load();
							}
						},
						children: "إنشاء قسم جديد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 rounded-xl border border-border p-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "flex-1",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "rounded-md border border-input bg-input p-2 text-xs",
									value: c.display_mode,
									onChange: async (e) => {
										const { error } = await supabase.from("gift_categories").update({ display_mode: e.target.value }).eq("id", c.id);
										if (error) toast.error(errMsg(error));
										else load();
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "static",
										children: "ثابتة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "animated",
										children: "متحركة"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: async () => {
										const { error } = await supabase.from("gift_categories").update({ is_active: !c.is_active }).eq("id", c.id);
										if (error) toast.error(errMsg(error));
										else load();
									},
									children: c.is_active ? "إخفاء" : "إظهار"
								})
							]
						}, c.id))
					})
				]
			}),
			catalog.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass flex items-center justify-between gap-2 rounded-xl p-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: g.asset_url || "",
						alt: "",
						className: "h-10 w-10 rounded-lg object-contain"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
						g.emoji,
						" ",
						g.name
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground",
						children: [
							categories.find((c) => c.id === g.category_id)?.name ?? "بدون قسم",
							" · ",
							Number(g.price).toLocaleString(),
							" عملة · ",
							g.display_duration_ms ?? 2600,
							"ms"
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "قسم الهدية",
							className: "max-w-28 rounded-md border border-input bg-input p-1 text-xs",
							value: g.category_id ?? "",
							onChange: async (e) => {
								const { error } = await supabase.from("gifts").update({ category_id: e.target.value || null }).eq("id", g.id);
								if (error) toast.error(errMsg(error));
								else load();
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "بدون قسم"
							}), categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.id,
								children: c.name
							}, c.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "حركة الهدية",
							className: "rounded-md border border-input bg-input p-1 text-xs",
							value: g.animation_style || "zoom",
							onChange: async (e) => {
								const { error } = await supabase.from("gifts").update({ animation_style: e.target.value }).eq("id", g.id);
								if (error) toast.error(errMsg(error));
								else load();
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "zoom",
									children: "تكبير"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "slide",
									children: "انزلاق"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "float",
									children: "طفو"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "pulse",
									children: "نبض"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "سرعة الهدية",
							className: "rounded-md border border-input bg-input p-1 text-xs",
							value: String(g.animation_speed ?? 1),
							onChange: async (e) => {
								const { error } = await supabase.from("gifts").update({ animation_speed: Number(e.target.value) }).eq("id", g.id);
								if (error) toast.error(errMsg(error));
								else load();
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "0.5",
									children: "بطيئة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "0.75",
									children: "أقل"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "1",
									children: "طبيعية"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "1.5",
									children: "سريعة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "2",
									children: "سريعة جدًا"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": "مدة العرض بالمللي ثانية",
							className: "w-24",
							type: "number",
							min: "500",
							max: "20000",
							step: "500",
							value: String(g.display_duration_ms ?? 2600),
							onChange: (e) => setCatalog((prev) => prev.map((x) => x.id === g.id ? {
								...x,
								display_duration_ms: Number(e.target.value)
							} : x)),
							onBlur: async (e) => {
								const n = Math.max(500, Math.min(2e4, Number(e.target.value) || 2600));
								const { error } = await supabase.from("gifts").update({ display_duration_ms: n }).eq("id", g.id);
								if (error) toast.error(errMsg(error));
								else load();
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => toggleGift(g),
							children: g.active ? "إيقاف" : "تفعيل"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "destructive",
							onClick: () => deleteGift(g),
							children: "حذف"
						})
					]
				})]
			}, g.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "glass space-y-3 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "تخصيص شريط هدايا الحظ" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "شريط صغير واحترافي داخل الغرفة: صورة الهدية + اسمها + عدد المردود الفعلي عند الفوز. يمكنك التحكم في الموضع والمدة والحجم."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted-foreground",
								children: ["التفعيل", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "mt-1 w-full rounded-md border border-input bg-input p-2",
									value: luckyBar.enabled ? "on" : "off",
									onChange: (e) => setLuckyBar({
										...luckyBar,
										enabled: e.target.value === "on"
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "on",
										children: "مفعل"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "off",
										children: "مخفي"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted-foreground",
								children: ["الموضع", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "mt-1 w-full rounded-md border border-input bg-input p-2",
									value: luckyBar.position,
									onChange: (e) => setLuckyBar({
										...luckyBar,
										position: e.target.value
									}),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "top",
											children: "أعلى الشاشة"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "center",
											children: "منتصف الشاشة"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "bottom",
											children: "أسفل الشاشة"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "1500",
								max: "15000",
								step: "100",
								placeholder: "مدة العرض ms",
								value: luckyBar.duration_ms,
								onChange: (e) => setLuckyBar({
									...luckyBar,
									duration_ms: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "220",
								max: "700",
								placeholder: "عرض الشريط px",
								value: luckyBar.width_px,
								onChange: (e) => setLuckyBar({
									...luckyBar,
									width_px: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "32",
								max: "140",
								placeholder: "حجم الهدية px",
								value: luckyBar.gift_size_px,
								onChange: (e) => setLuckyBar({
									...luckyBar,
									gift_size_px: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 rounded-md border border-input bg-input px-3 py-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: luckyBar.show_name,
									onChange: (e) => setLuckyBar({
										...luckyBar,
										show_name: e.target.checked
									})
								}), " عرض اسم الهدية"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "bg-gold",
						onClick: () => void saveLuckyBar(),
						children: "حفظ تخصيص الشريط"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "glass space-y-3 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "هدايا الحظ — تحكم كامل في نسبة الفوز والمردود" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "اسم الهدية",
								value: luckyForm.name,
								onChange: (e) => setLuckyForm({
									...luckyForm,
									name: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								dir: "ltr",
								placeholder: "asset_key",
								value: luckyForm.asset_key,
								onChange: (e) => setLuckyForm({
									...luckyForm,
									asset_key: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								placeholder: "السعر",
								value: luckyForm.price,
								onChange: (e) => setLuckyForm({
									...luckyForm,
									price: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								max: "100",
								step: "0.01",
								placeholder: "نسبة الحظ %",
								value: luckyForm.win_chance,
								onChange: (e) => setLuckyForm({
									...luckyForm,
									win_chance: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								placeholder: "أقل مردود",
								value: luckyForm.min_reward,
								onChange: (e) => setLuckyForm({
									...luckyForm,
									min_reward: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								placeholder: "أعلى مردود",
								value: luckyForm.max_reward,
								onChange: (e) => setLuckyForm({
									...luckyForm,
									max_reward: e.target.value
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "bg-gold",
						onClick: async () => {
							const { error } = await supabase.from("lucky_gifts").insert({
								name: luckyForm.name.trim(),
								asset_key: luckyForm.asset_key.trim() || null,
								price: Number(luckyForm.price),
								win_chance: Number(luckyForm.win_chance),
								min_reward: Number(luckyForm.min_reward),
								max_reward: Number(luckyForm.max_reward),
								active: true
							});
							if (error) toast.error(errMsg(error));
							else {
								toast.success("تم حفظ هدية الحظ");
								setLuckyForm({
									name: "",
									asset_key: "",
									price: "1000",
									win_chance: "10",
									min_reward: "0",
									max_reward: "5000"
								});
								load();
							}
						},
						children: "إضافة هدية حظ"
					}),
					luckyRows.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-gold/20 p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: g.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-gold",
									children: [g.win_chance, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-xs text-muted-foreground",
								children: [
									"السعر ",
									Number(g.price).toLocaleString(),
									" · المردود ",
									Number(g.min_reward).toLocaleString(),
									"–",
									Number(g.max_reward).toLocaleString()
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: async () => {
										const { error } = await supabase.from("lucky_gifts").update({ active: !g.active }).eq("id", g.id);
										if (error) toast.error(errMsg(error));
										else load();
									},
									children: g.active ? "إيقاف" : "تفعيل"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "destructive",
									onClick: async () => {
										if (!confirm("حذف هدية الحظ؟")) return;
										const { error } = await supabase.from("lucky_gifts").delete().eq("id", g.id);
										if (error) toast.error(errMsg(error));
										else load();
									},
									children: "حذف"
								})]
							})
						]
					}, g.id))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border pt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "سجل إرسال الهدايا" })
			}),
			rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "glass rounded-2xl p-6 text-center text-muted-foreground",
				children: "لا توجد معاملات"
			}),
			rows.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass flex items-center justify-between gap-2 rounded-2xl p-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: g.sender_name ?? "—" }),
					" أرسل ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-primary",
						children: g.gift_name
					}),
					" إلى ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: g.receiver_name ?? "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: fmt(g.created_at)
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["🪙 ", Number(g.cost).toLocaleString()] })]
			}, i))
		]
	});
}
function VipTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [form, setForm] = (0, import_react.useState)({
		level: "1",
		name: "",
		price_coins: "1000",
		duration_days: "30"
	});
	const [perkRows, setPerkRows] = (0, import_react.useState)([]);
	const [perkForm, setPerkForm] = (0, import_react.useState)({
		code: "",
		name: "",
		description: "",
		min_level: "1",
		icon: "sparkles",
		sort_order: "10"
	});
	async function load() {
		const [{ data, error }, { data: perks, error: perkError }] = await Promise.all([supabase.from("vip_tiers").select("level,name,price_coins,duration_days").order("level"), supabase.from("vip_perks").select("code,name,description,min_level,icon,sort_order").order("sort_order")]);
		if (error) toast.error(errMsg(error));
		if (perkError) toast.error(errMsg(perkError));
		setRows(data ?? []);
		setPerkRows(perks ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime(["vip_tiers", "profiles"], load);
	async function save() {
		const level = Number(form.level), price = Number(form.price_coins), days = Number(form.duration_days);
		if (!Number.isInteger(level) || level < 1 || level > 10 || !form.name.trim() || price < 0 || days < 1) {
			toast.error("تحقق من المستوى والاسم والسعر والمدة");
			return;
		}
		const { error } = await supabase.from("vip_tiers").upsert({
			level,
			name: form.name.trim(),
			price_coins: price,
			duration_days: days
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم حفظ مستوى VIP");
		load();
	}
	async function remove(level) {
		if (!confirm("حذف مستوى VIP؟")) return;
		const { error } = await supabase.from("vip_tiers").delete().eq("level", level);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-2 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "إضافة أو تعديل مستوى VIP" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "1",
								max: "10",
								placeholder: "المستوى",
								value: form.level,
								onChange: (e) => setForm({
									...form,
									level: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "اسم المستوى",
								value: form.name,
								onChange: (e) => setForm({
									...form,
									name: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								placeholder: "السعر بالعملات",
								value: form.price_coins,
								onChange: (e) => setForm({
									...form,
									price_coins: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "1",
								placeholder: "المدة بالأيام",
								value: form.duration_days,
								onChange: (e) => setForm({
									...form,
									duration_days: e.target.value
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "bg-gold",
						onClick: save,
						children: "حفظ المستوى"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "glass space-y-3 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "صلاحيات ومميزات VIP الفعلية — من الأقل للأعلى" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "code",
								dir: "ltr",
								value: perkForm.code,
								onChange: (e) => setPerkForm({
									...perkForm,
									code: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "اسم الميزة",
								value: perkForm.name,
								onChange: (e) => setPerkForm({
									...perkForm,
									name: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "الوصف",
								value: perkForm.description,
								onChange: (e) => setPerkForm({
									...perkForm,
									description: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "1",
								max: "10",
								placeholder: "أقل VIP",
								value: perkForm.min_level,
								onChange: (e) => setPerkForm({
									...perkForm,
									min_level: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "الأيقونة",
								value: perkForm.icon,
								onChange: (e) => setPerkForm({
									...perkForm,
									icon: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								placeholder: "الترتيب",
								value: perkForm.sort_order,
								onChange: (e) => setPerkForm({
									...perkForm,
									sort_order: e.target.value
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "bg-gold",
						onClick: async () => {
							if (!perkForm.code || !perkForm.name) {
								toast.error("أدخل كود واسم الميزة");
								return;
							}
							const { error } = await supabase.from("vip_perks").upsert({
								code: perkForm.code.trim(),
								name: perkForm.name.trim(),
								description: perkForm.description.trim(),
								min_level: Number(perkForm.min_level),
								icon: perkForm.icon.trim() || "sparkles",
								sort_order: Number(perkForm.sort_order)
							});
							if (error) toast.error(errMsg(error));
							else {
								toast.success("تم حفظ ميزة VIP");
								setPerkForm({
									code: "",
									name: "",
									description: "",
									min_level: "1",
									icon: "sparkles",
									sort_order: "10"
								});
								load();
							}
						},
						children: "حفظ ميزة VIP"
					}),
					perkRows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 rounded-xl border border-primary/10 p-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: p.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground",
							children: [
								"VIP ",
								p.min_level,
								"+ · ",
								p.description
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "destructive",
							onClick: async () => {
								const { error } = await supabase.from("vip_perks").delete().eq("code", p.code);
								if (error) toast.error(errMsg(error));
								else load();
							},
							children: "حذف"
						})]
					}, p.code))
				]
			}),
			rows.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass flex items-center justify-between gap-2 rounded-xl p-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
					"VIP ",
					v.level,
					" · ",
					v.name
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground",
					children: [
						"🪙 ",
						v.price_coins.toLocaleString(),
						" · ",
						v.duration_days,
						" يوم"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "destructive",
					onClick: () => remove(v.level),
					children: "حذف"
				})]
			}, v.level))
		]
	});
}
var KINDS = {
	frame: "إطار",
	entry: "دخولية",
	bubble: "فقاعة كتابة",
	sound_wave: "موجة صوت",
	profile_card: "بطاقة تعريف",
	name_effect: "تأثير اسم",
	theme: "خلفية",
	lucky_gift: "هدية حظ"
};
function StoreTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [form, setForm] = (0, import_react.useState)({
		kind: "frame",
		name: "",
		description: "",
		price: "100",
		asset_key: "",
		sort_order: "0",
		duration: "0",
		unit: "hours"
	});
	async function load() {
		const { data, error } = await supabase.from("store_items").select("*").order("kind").order("sort_order");
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		setRows(data ?? []);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	useAdminRealtime(["store_items"], load);
	async function save() {
		const { error } = await supabase.rpc("admin_save_store_item", {
			_id: null,
			_kind: form.kind,
			_name: form.name,
			_description: form.description,
			_price: Number(form.price || 0),
			_asset_key: form.asset_key,
			_sort_order: Number(form.sort_order || 0),
			_hours: (() => {
				const amount = Number(form.duration || 0);
				return amount === 0 ? 0 : form.unit === "days" ? amount * 24 : amount;
			})()
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success(form.duration === "0" ? "تم نشر العنصر بدون انتهاء" : "تم نشر العنصر بصلاحية محددة");
		setForm({
			kind: "frame",
			name: "",
			description: "",
			price: "100",
			asset_key: "",
			sort_order: "0",
			duration: "0",
			unit: "hours"
		});
		load();
	}
	async function del(id) {
		if (!confirm("حذف العنصر من المتجر؟")) return;
		const { data, error } = await supabase.rpc("admin_delete_store_item", { _id: id });
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		if (data !== true) {
			toast.error("لم يتم العثور على العنصر أو لم يتم حذفه");
			await load();
			return;
		}
		toast.success("تم حذف العنصر من المتجر");
		await load();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass space-y-2 rounded-2xl p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					className: "text-sm",
					children: "إضافة عنصر جديد"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "rounded-md border border-input bg-input px-2 py-1.5 text-xs",
							value: form.kind,
							onChange: (e) => setForm({
								...form,
								kind: e.target.value
							}),
							children: Object.entries(KINDS).map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: k,
								children: l
							}, k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "الاسم",
							value: form.name,
							onChange: (e) => setForm({
								...form,
								name: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "الوصف",
							value: form.description,
							onChange: (e) => setForm({
								...form,
								description: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							placeholder: "السعر بالعملات",
							value: form.price,
							onChange: (e) => setForm({
								...form,
								price: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "مفتاح الأصل (مثل frame-1)",
							value: form.asset_key,
							onChange: (e) => setForm({
								...form,
								asset_key: e.target.value
							}),
							dir: "ltr"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							placeholder: "الترتيب",
							value: form.sort_order,
							onChange: (e) => setForm({
								...form,
								sort_order: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: "0",
							placeholder: "مدة الاستخدام بعد الشراء (0 = دائم)",
							value: form.duration,
							onChange: (e) => setForm({
								...form,
								duration: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "rounded-md border border-input bg-input px-2 py-1.5 text-xs",
							value: form.unit,
							onChange: (e) => setForm({
								...form,
								unit: e.target.value
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "hours",
								children: "ساعات"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "days",
								children: "أيام"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					className: "bg-gold",
					onClick: save,
					disabled: !form.name || !form.asset_key,
					children: "إضافة"
				})
			]
		}), rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass flex items-center justify-between gap-2 rounded-2xl p-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: r.name }),
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [
						"(",
						KINDS[r.kind] ?? r.kind,
						")"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					dir: "ltr",
					children: r.asset_key
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[10px] text-muted-foreground",
					children: [
						r.duration_hours ? `مدة الاستخدام: ${r.duration_hours >= 24 && r.duration_hours % 24 === 0 ? `${r.duration_hours / 24} يوم` : `${r.duration_hours} ساعة`}` : "مدة الاستخدام: دائمة",
						r.expires_at ? " · ينتهي نشره: " + fmt(r.expires_at) : "",
						r.is_direct_grant ? " · خاص" : ""
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["🪙 ", r.price.toLocaleString()] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "destructive",
					onClick: () => del(r.id),
					"aria-label": "حذف",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
				})]
			})]
		}, r.id))]
	});
}
function AuditTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		(async () => {
			const { data, error } = await supabase.rpc("admin_list_audit", { _limit: 200 });
			if (error) toast.error(errMsg(error));
			setRows(data ?? []);
		})();
	}, []);
	useAdminRealtime(["audit_log"], () => {
		supabase.rpc("admin_list_audit", { _limit: 200 }).then(({ data, error }) => {
			if (error) toast.error(errMsg(error));
			setRows(data ?? []);
		});
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "glass rounded-2xl p-6 text-center text-muted-foreground",
			children: "لا توجد إجراءات مسجلة بعد"
		}), rows.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass rounded-2xl p-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
					a.admin_name ?? "مشرف",
					" · ",
					a.action
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: fmt(a.created_at)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-xs text-muted-foreground",
				children: [
					a.target_type,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						dir: "ltr",
						children: a.target_id
					}),
					" ",
					a.details
				]
			})]
		}, a.id))]
	});
}
var ASSET_CATEGORIES = {
	general: "عام",
	ui: "عناصر الواجهة",
	room: "الغرف والخلفيات",
	gift: "الهدايا",
	frame: "إطارات الصور",
	entry: "الدخوليات",
	vip: "شارات VIP",
	badge: "الشارات المميزة",
	level: "المستويات",
	banner: "البانرات",
	bubble: "فقاعات الكتابة",
	sound_wave: "موجات الصوت",
	profile_card: "بطاقات التعريف",
	lucky_gift: "هدايا الحظ",
	room_frame: "إطارات الغرف",
	avatar: "الصور الشخصية",
	"3d": "مجسمات ثلاثية الأبعاد",
	mic: "الميكات وتصميماتها"
};
var ASSET_BUCKET = "admin-assets";
var MAX_ASSET_SIZE = 52428800;
function AssetsTab() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [storeItems, setStoreItems] = (0, import_react.useState)([]);
	const [editingAsset, setEditingAsset] = (0, import_react.useState)(null);
	const [editName, setEditName] = (0, import_react.useState)("");
	const [editCategory, setEditCategory] = (0, import_react.useState)("general");
	const [editDisplayWidth, setEditDisplayWidth] = (0, import_react.useState)("240");
	const [editDisplayHeight, setEditDisplayHeight] = (0, import_react.useState)("240");
	const [editPlaybackSpeed, setEditPlaybackSpeed] = (0, import_react.useState)("1");
	const [editAnimationStyle, setEditAnimationStyle] = (0, import_react.useState)("zoom");
	const [editDisplayDuration, setEditDisplayDuration] = (0, import_react.useState)("2600");
	const [editAudioEnabled, setEditAudioEnabled] = (0, import_react.useState)(true);
	const [grantUserId, setGrantUserId] = (0, import_react.useState)("");
	const [grantUserNo, setGrantUserNo] = (0, import_react.useState)("");
	const [grantItemId, setGrantItemId] = (0, import_react.useState)("");
	const grantEquip = true;
	const [grantBusy, setGrantBusy] = (0, import_react.useState)(false);
	const [category, setCategory] = (0, import_react.useState)("general");
	const [name, setName] = (0, import_react.useState)("");
	const [displayWidth, setDisplayWidth] = (0, import_react.useState)("240");
	const [displayHeight, setDisplayHeight] = (0, import_react.useState)("240");
	const [playbackSpeed, setPlaybackSpeed] = (0, import_react.useState)("1");
	const [animationStyle, setAnimationStyle] = (0, import_react.useState)("zoom");
	const [displayDuration, setDisplayDuration] = (0, import_react.useState)("2600");
	const [audioEnabled, setAudioEnabled] = (0, import_react.useState)(true);
	const [files, setFiles] = (0, import_react.useState)([]);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const [previews, setPreviews] = (0, import_react.useState)({});
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [voiceConfig, setVoiceConfig] = (0, import_react.useState)({
		mic_asset_key: "",
		muted_asset_key: "",
		locked_asset_key: "",
		effect_asset_key: "",
		show_mic_effect: true,
		seat_gap_px: "20",
		avatar_size_px: "72",
		mic_icon_size_px: "28"
	});
	const [voiceSaving, setVoiceSaving] = (0, import_react.useState)(false);
	async function loadVoiceControls() {
		const { data, error } = await supabase.from("admin_settings").select("value").eq("key", "voice_controls").maybeSingle();
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		const cfg = data?.value ?? {};
		setVoiceConfig({
			mic_asset_key: String(cfg.mic_asset_key ?? ""),
			muted_asset_key: String(cfg.muted_asset_key ?? ""),
			locked_asset_key: String(cfg.locked_asset_key ?? ""),
			effect_asset_key: String(cfg.effect_asset_key ?? ""),
			show_mic_effect: cfg.show_mic_effect !== false,
			seat_gap_px: String(Math.max(0, Math.min(80, Number(cfg.seat_gap_px ?? 20)))),
			avatar_size_px: String(Math.max(40, Math.min(120, Number(cfg.avatar_size_px ?? 72)))),
			mic_icon_size_px: String(Math.max(16, Math.min(48, Number(cfg.mic_icon_size_px ?? 28))))
		});
	}
	async function saveVoiceControls() {
		const gap = Number(voiceConfig.seat_gap_px);
		const avatarSize = Number(voiceConfig.avatar_size_px);
		const micIconSize = Number(voiceConfig.mic_icon_size_px);
		if (!Number.isFinite(gap) || gap < 0 || gap > 80) {
			toast.error("المسافة بين الميكات يجب أن تكون من 0 إلى 80 بكسل");
			return;
		}
		if (!Number.isInteger(avatarSize) || avatarSize < 40 || avatarSize > 120) {
			toast.error("حجم صورة المستخدم يجب أن يكون من 40 إلى 120 بكسل");
			return;
		}
		if (!Number.isInteger(micIconSize) || micIconSize < 16 || micIconSize > 48) {
			toast.error("حجم علامة الميك يجب أن يكون من 16 إلى 48 بكسل");
			return;
		}
		setVoiceSaving(true);
		const { data: auth } = await supabase.auth.getUser();
		const { error } = await supabase.from("admin_settings").upsert({
			key: "voice_controls",
			value: {
				...voiceConfig,
				seat_gap_px: gap,
				avatar_size_px: avatarSize,
				mic_icon_size_px: micIconSize
			},
			updated_at: (/* @__PURE__ */ new Date()).toISOString(),
			updated_by: auth.user?.id ?? null
		});
		setVoiceSaving(false);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم حفظ تصميم الميكات والمسافات");
	}
	async function load() {
		setLoading(true);
		const [{ data, error }, { data: linkedItems, error: linkedItemsError }] = await Promise.all([supabase.from("admin_assets").select("*").order("created_at", { ascending: false }).range(0, 9999), supabase.from("store_items").select("id,name,kind,price,asset_key").order("name")]);
		if (linkedItemsError) toast.error(`تعذر تحميل روابط المتجر: ${errMsg(linkedItemsError)}`);
		setStoreItems(linkedItems ?? []);
		if (error) {
			toast.error(errMsg(error));
			setLoading(false);
			return;
		}
		const assets = data ?? [];
		setRows(assets);
		const resolved = {};
		await Promise.all(assets.map(async (asset) => {
			const url = await getAdminAssetUrl(asset.asset_key);
			if (url) resolved[asset.id] = url;
		}));
		setPreviews(resolved);
		setLoading(false);
	}
	(0, import_react.useEffect)(() => {
		load();
		loadVoiceControls();
	}, []);
	useAdminRealtime(["admin_assets", "admin_settings"], () => {
		load();
		loadVoiceControls();
	});
	async function uploadAssets() {
		if (!files.length) {
			toast.error("اختر ملفاً واحداً على الأقل");
			return;
		}
		const hasVideo = files.some((file) => file.type.startsWith("video/") || /\.(mp4|webm|mov|m4v)$/i.test(file.name));
		const needsDisplaySize = [
			"gift",
			"frame",
			"entry"
		].includes(category) || hasVideo;
		const width = Number(displayWidth), height = Number(displayHeight);
		const speed = Number(playbackSpeed), duration = Number(displayDuration);
		if (needsDisplaySize && (!Number.isInteger(width) || width < 24 || width > 2048 || !Number.isInteger(height) || height < 24 || height > 2048)) {
			toast.error("حدد عرض وطول الأصل بين 24 و2048 بكسل");
			return;
		}
		if (!Number.isFinite(speed) || speed < .25 || speed > 3 || !Number.isInteger(duration) || duration < 500 || duration > 12e4) {
			toast.error("تحقق من سرعة التشغيل ومدة العرض");
			return;
		}
		const invalid = files.find((file) => file.size > MAX_ASSET_SIZE);
		if (invalid) {
			toast.error(`حجم ${invalid.name} أكبر من الحد المسموح (50 ميجابايت)`);
			return;
		}
		setUploading(true);
		let uploaded = 0;
		for (const file of files) {
			const cleanName = file.name.normalize("NFKD").replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(-100) || "asset";
			const path = `${category}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${cleanName}`;
			const { error: storageError } = await supabase.storage.from(ASSET_BUCKET).upload(path, file, {
				contentType: file.type || "application/octet-stream",
				upsert: false
			});
			if (storageError) {
				toast.error(`فشل رفع ${file.name}: ${storageError.message}`);
				continue;
			}
			const assetKey = `${category}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
			const { error: rowError } = await supabase.from("admin_assets").insert({
				asset_key: assetKey,
				name: name.trim() || file.name.replace(/\.[^.]+$/, ""),
				category,
				url: path,
				metadata: {
					storage_path: path,
					content_type: file.type || "application/octet-stream",
					size: file.size,
					original_name: file.name,
					display_width: needsDisplaySize ? width : void 0,
					display_height: needsDisplaySize ? height : void 0,
					playback_speed: speed,
					animation_style: animationStyle,
					display_duration_ms: duration,
					audio_enabled: audioEnabled
				},
				is_active: true
			});
			if (rowError) {
				await supabase.storage.from(ASSET_BUCKET).remove([path]);
				toast.error(`تم رفع الملف لكن تعذرت إضافته للمكتبة: ${rowError.message}`);
				continue;
			}
			uploaded += 1;
		}
		setUploading(false);
		setFiles([]);
		setName("");
		setDisplayWidth("240");
		setDisplayHeight("240");
		setPlaybackSpeed("1");
		setAnimationStyle("zoom");
		setDisplayDuration("2600");
		setAudioEnabled(true);
		const picker = document.getElementById("admin-asset-files");
		if (picker) picker.value = "";
		if (uploaded) toast.success(`تم رفع وإضافة ${uploaded} أصل بنجاح`);
		await load();
	}
	async function toggleAsset(asset) {
		const { error } = await supabase.from("admin_assets").update({
			is_active: !asset.is_active,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", asset.id);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success(asset.is_active ? "تم إيقاف الأصل عن الظهور في التطبيق" : "تم تفعيل الأصل");
		await load();
	}
	async function grantBadgeToUser() {
		const userNo = Number(grantUserNo.trim());
		if (!Number.isSafeInteger(userNo) || userNo < 1) {
			toast.error("أدخل ID المستخدم الصحيح");
			return;
		}
		const asset = rows.find((a) => a.id === grantItemId);
		if (!asset || asset.category !== "badge") {
			toast.error("اختر شارة من مكتبة الأصول أولاً");
			return;
		}
		setGrantBusy(true);
		try {
			const { data: users, error: userError } = await supabase.rpc("admin_list_users", { _q: grantUserNo.trim() });
			if (userError) throw userError;
			const user = (users ?? []).find((u) => Number(u.display_no) === userNo);
			if (!user) throw new Error("لم يتم العثور على مستخدم بهذا ID");
			setGrantUserId(user.id);
			const { error: grantError } = await supabase.rpc("admin_grant_badge_asset", {
				_user: user.id,
				_asset_id: asset.id,
				_equip: grantEquip
			});
			if (grantError) throw grantError;
			toast.success(`تم إرسال الشارة «${asset.name}» إلى ID ${userNo} وتجهيزها`);
			setGrantUserId(user.id);
		} catch (error) {
			toast.error(errMsg(error));
		} finally {
			setGrantBusy(false);
		}
	}
	function beginEditAsset(asset) {
		const metadata = asset.metadata ?? {};
		setEditingAsset(asset);
		setEditName(asset.name);
		setEditCategory(asset.category);
		setEditDisplayWidth(String(metadata.display_width ?? 240));
		setEditDisplayHeight(String(metadata.display_height ?? 240));
		setEditPlaybackSpeed(String(metadata.playback_speed ?? 1));
		setEditAnimationStyle(String(metadata.animation_style ?? "zoom"));
		setEditDisplayDuration(String(metadata.display_duration_ms ?? 2600));
		setEditAudioEnabled(metadata.audio_enabled !== false);
	}
	async function saveAssetEdit() {
		if (!editingAsset || !editName.trim()) {
			toast.error("اكتب اسم الأصل");
			return;
		}
		const metadata = editingAsset.metadata ?? {};
		const displayWidthValue = Number(editDisplayWidth), displayHeightValue = Number(editDisplayHeight);
		const playbackSpeedValue = Number(editPlaybackSpeed), durationValue = Number(editDisplayDuration);
		if (!Number.isInteger(displayWidthValue) || displayWidthValue < 24 || displayWidthValue > 2048 || !Number.isInteger(displayHeightValue) || displayHeightValue < 24 || displayHeightValue > 2048 || !Number.isFinite(playbackSpeedValue) || playbackSpeedValue < .25 || playbackSpeedValue > 3 || !Number.isInteger(durationValue) || durationValue < 500 || durationValue > 12e4) {
			toast.error("تحقق من أبعاد الأصل وسرعته ومدته");
			return;
		}
		const { error } = await supabase.from("admin_assets").update({
			name: editName.trim(),
			category: editCategory,
			metadata: {
				...metadata,
				display_width: displayWidthValue,
				display_height: displayHeightValue,
				playback_speed: playbackSpeedValue,
				animation_style: editAnimationStyle,
				display_duration_ms: durationValue,
				audio_enabled: editAudioEnabled
			},
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", editingAsset.id);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم تعديل بيانات الأصل");
		setEditingAsset(null);
		await load();
	}
	async function deleteAsset(asset) {
		const linked = storeItems.filter((item) => item.asset_key === asset.asset_key);
		const warning = linked.length ? `\
سيتم حذف ${linked.length} عنصر متجر مرتبط بهذا الأصل أيضاً.` : "";
		if (!confirm(`حذف الأصل «${asset.name}» نهائياً؟${warning}`)) return;
		for (const item of linked) {
			const { error } = await supabase.rpc("admin_delete_store_item", { _id: item.id });
			if (error) {
				toast.error(`تعذر حذف عنصر المتجر «${item.name}»: ${errMsg(error)}`);
				return;
			}
		}
		const { error: rowError } = await supabase.from("admin_assets").delete().eq("id", asset.id);
		if (rowError) {
			toast.error(errMsg(rowError));
			return;
		}
		const path = asset.metadata?.storage_path ?? asset.url;
		if (path) {
			const { error: storageError } = await supabase.storage.from(ASSET_BUCKET).remove([path]);
			if (storageError) {
				toast.warning(`تم حذف سجل الأصل والمتجر، لكن تعذر حذف ملف التخزين: ${storageError.message}`);
				await load();
				return;
			}
		}
		toast.success("تم حذف الأصل والملف وكل عناصر المتجر المرتبطة به");
		await load();
	}
	const visible = rows.filter((asset) => (filter === "all" || asset.category === filter) && (asset.name.toLowerCase().includes(search.toLowerCase()) || asset.asset_key.toLowerCase().includes(search.toLowerCase())));
	const isImage = (asset) => (asset.metadata?.content_type ?? "").startsWith("image/");
	const isVideo = (asset) => (asset.metadata?.content_type ?? "").toLowerCase().startsWith("video/") || /\.(mp4|webm|mov|m4v)$/i.test(asset.metadata?.original_name ?? asset.url ?? "");
	const isModel = (asset) => /model\/gltf|octet-stream/i.test(asset.metadata?.content_type ?? "") || /\.(glb|gltf)$/i.test(asset.name);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-3 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-bold",
							children: "مكتبة أصول التطبيق"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "ارفع الصور أو MP4 أو مجسمات GLB/GLTF واربطها مباشرة بمحتوى التطبيق."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-secondary px-3 py-1 text-xs",
							children: [rows.length, " أصل"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "تصنيف الأصل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "w-full rounded-md border border-input bg-input px-3 py-2",
								value: category,
								onChange: (e) => setCategory(e.target.value),
								children: Object.entries(ASSET_CATEGORIES).map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: key,
									children: label
								}, key))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "اسم الأصل (اختياري)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: "مثال: تاج VIP ذهبي"
							})]
						})]
					}),
					([
						"gift",
						"frame",
						"entry"
					].includes(category) || files.some((file) => file.type.startsWith("video/") || /\.(mp4|webm|mov|m4v)$/i.test(file.name))) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 rounded-xl border border-primary/20 bg-primary/5 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "عرض الأصل على الشاشة (px)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "24",
									max: "2048",
									value: displayWidth,
									onChange: (e) => setDisplayWidth(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "طول الأصل على الشاشة (px)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "24",
									max: "2048",
									value: displayHeight,
									onChange: (e) => setDisplayHeight(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "سرعة تشغيل الفيديو"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "mt-1 w-full rounded-md border border-input bg-input p-2",
									value: playbackSpeed,
									onChange: (e) => setPlaybackSpeed(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0.5",
											children: "0.5×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0.75",
											children: "0.75×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1",
											children: "1× طبيعي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1.25",
											children: "1.25×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1.5",
											children: "1.5×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "2",
											children: "2×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "3",
											children: "3×"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "حركة الظهور"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "mt-1 w-full rounded-md border border-input bg-input p-2",
									value: animationStyle,
									onChange: (e) => setAnimationStyle(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "zoom",
											children: "تكبير"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "slide",
											children: "انزلاق"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "float",
											children: "طفو"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "pulse",
											children: "نبض"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "بدون حركة"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "col-span-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "مدة عرض الصور الثابتة (مللي ثانية) — الفيديو يستمر حتى نهايته"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "500",
									max: "120000",
									step: "500",
									value: displayDuration,
									onChange: (e) => setDisplayDuration(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "col-span-2 flex items-center gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: audioEnabled,
									onChange: (e) => setAudioEnabled(e.target.checked)
								}), " تشغيل صوت الفيديو الأصلي"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-span-2 text-[10px] text-muted-foreground",
								children: "تُحفظ الإعدادات مع الأصل في Supabase، ويُعرض الفيديو بكامل مدته دون ضغطه أو قصّه."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-primary/40 bg-secondary/40 p-5 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-7 w-7 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold",
								children: "اختر صوراً أو ملفات ثلاثية الأبعاد"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: "PNG · JPG · WEBP · GIF · MP4 · SVG · GLB · GLTF — حتى 50 MB للملف"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "admin-asset-files",
								className: "max-w-full text-xs",
								type: "file",
								multiple: true,
								accept: "image/png,image/jpeg,image/webp,image/gif,image/svg+xml,video/mp4,.mp4,.glb,.gltf,model/gltf-binary,model/gltf+json,application/octet-stream",
								onChange: (e) => setFiles(Array.from(e.target.files ?? []))
							})
						]
					}),
					files.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							files.length,
							" ملف محدد · ",
							files.map((f) => f.name).join("، ")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full bg-gold",
						onClick: uploadAssets,
						disabled: uploading || files.length === 0,
						children: uploading ? "جارٍ رفع الأصول…" : `رفع وإضافة ${files.length || ""} أصل`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-3 rounded-2xl border border-primary/20 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-bold",
						children: "تصميم الميكات والتحكم في توزيعها"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "ارفع أصولك بتصنيف «الميكات وتصميماتها» ثم اختر الشكل العادي والمكتوم وتأثير التحدث. الإعدادات تُحدّث الغرف مباشرة."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "شكل الميك الأساسي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "w-full rounded-md border border-input bg-input px-3 py-2",
									value: voiceConfig.mic_asset_key,
									onChange: (e) => setVoiceConfig((v) => ({
										...v,
										mic_asset_key: e.target.value
									})),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "الشكل الافتراضي"
									}), rows.filter((a) => a.category === "mic" && a.is_active).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: a.asset_key,
										children: [
											a.name,
											" · ",
											a.asset_key
										]
									}, a.asset_key))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "شكل الميك عند الكتم" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "w-full rounded-md border border-input bg-input px-3 py-2",
									value: voiceConfig.muted_asset_key,
									onChange: (e) => setVoiceConfig((v) => ({
										...v,
										muted_asset_key: e.target.value
									})),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "الشكل الافتراضي للمكتوم"
									}), rows.filter((a) => a.category === "mic" && a.is_active).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: a.asset_key,
										children: [
											a.name,
											" · ",
											a.asset_key
										]
									}, a.asset_key))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "شكل الميك المقفول" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "w-full rounded-md border border-input bg-input px-3 py-2",
									value: voiceConfig.locked_asset_key,
									onChange: (e) => setVoiceConfig((v) => ({
										...v,
										locked_asset_key: e.target.value
									})),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "الشكل الافتراضي للمقعد المقفول"
									}), rows.filter((a) => a.category === "mic" && a.is_active).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: a.asset_key,
										children: [
											a.name,
											" · ",
											a.asset_key
										]
									}, a.asset_key))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تأثير الميك أثناء التحدث" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "w-full rounded-md border border-input bg-input px-3 py-2",
									value: voiceConfig.effect_asset_key,
									onChange: (e) => setVoiceConfig((v) => ({
										...v,
										effect_asset_key: e.target.value
									})),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "بدون تأثير إضافي"
									}), rows.filter((a) => a.category === "mic" && a.is_active).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: a.asset_key,
										children: [
											a.name,
											" · ",
											a.asset_key
										]
									}, a.asset_key))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المسافة بين الميكات (بكسل)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "0",
									max: "80",
									value: voiceConfig.seat_gap_px,
									onChange: (e) => setVoiceConfig((v) => ({
										...v,
										seat_gap_px: e.target.value
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "حجم صورة المستخدم مع الإطار (40–120 px)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "40",
									max: "120",
									value: voiceConfig.avatar_size_px,
									onChange: (e) => setVoiceConfig((v) => ({
										...v,
										avatar_size_px: e.target.value
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "حجم علامة الميك (16–48 px)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "16",
									max: "48",
									value: voiceConfig.mic_icon_size_px,
									onChange: (e) => setVoiceConfig((v) => ({
										...v,
										mic_icon_size_px: e.target.value
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 self-end pb-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: voiceConfig.show_mic_effect,
									onChange: (e) => setVoiceConfig((v) => ({
										...v,
										show_mic_effect: e.target.checked
									}))
								}), " إظهار تأثير التحدث"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full bg-gold",
						disabled: voiceSaving,
						onClick: () => void saveVoiceControls(),
						children: voiceSaving ? "جارٍ الحفظ…" : "حفظ إعدادات الميكات"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-3 rounded-2xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-bold",
						children: "إرسال شارة لمستخدم"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "اختر شارة من مكتبة الأصول وأرسلها مباشرة إلى المستخدم بالـ ID. ستظهر تحت الـ ID في الملف العام بعد الاستلام."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-[1fr_1fr_auto]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: grantUserNo,
								onChange: (e) => setGrantUserNo(e.target.value.replace(/\D/g, "")),
								placeholder: "ID المستخدم",
								inputMode: "numeric",
								dir: "ltr"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "rounded-md border border-input bg-input px-3 py-2 text-xs",
								value: grantItemId,
								onChange: (e) => setGrantItemId(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "اختر شارة"
								}), rows.filter((a) => a.category === "badge" && a.is_active).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: a.id,
									children: [
										a.name,
										" · ",
										a.asset_key
									]
								}, a.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "bg-gold",
								onClick: () => void grantBadgeToUser(),
								disabled: grantBusy || !grantUserNo || !grantItemId,
								children: grantBusy ? "جارٍ الإرسال…" : "إرسال الشارة"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-emerald-500",
						children: "سيتم تجهيز الشارة تلقائياً وإظهارها أسفل ID المستخدم فور الإرسال."
					}),
					grantUserId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] text-muted-foreground",
						dir: "ltr",
						children: ["user_id: ", grantUserId]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-40 flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: search,
							onChange: (e) => setSearch(e.target.value),
							placeholder: "ابحث باسم الأصل أو مفتاحه"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "rounded-md border border-input bg-input px-3 text-xs",
						value: filter,
						onChange: (e) => setFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "كل التصنيفات"
						}), Object.entries(ASSET_CATEGORIES).map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: key,
							children: label
						}, key))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "outline",
						onClick: load,
						disabled: loading,
						"aria-label": "تحديث",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-4 w-4 ${loading ? "animate-spin" : ""}` })
					})
				]
			}),
			editingAsset && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass space-y-3 rounded-2xl border border-primary/30 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["تعديل الأصل: ", editingAsset.name] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => setEditingAsset(null),
							children: "إلغاء"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: editName,
						onChange: (e) => setEditName(e.target.value),
						placeholder: "اسم الأصل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "w-full rounded-md border border-input bg-input px-3 py-2 text-sm",
						value: editCategory,
						onChange: (e) => setEditCategory(e.target.value),
						children: Object.entries(ASSET_CATEGORIES).map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: key,
							children: label
						}, key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs",
								children: ["العرض px", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "24",
									max: "2048",
									value: editDisplayWidth,
									onChange: (e) => setEditDisplayWidth(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs",
								children: ["الارتفاع px", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "24",
									max: "2048",
									value: editDisplayHeight,
									onChange: (e) => setEditDisplayHeight(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs",
								children: ["سرعة الفيديو", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "mt-1 w-full rounded-md border border-input bg-input p-2",
									value: editPlaybackSpeed,
									onChange: (e) => setEditPlaybackSpeed(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0.5",
											children: "0.5×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0.75",
											children: "0.75×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1",
											children: "1×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1.25",
											children: "1.25×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1.5",
											children: "1.5×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "2",
											children: "2×"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "3",
											children: "3×"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs",
								children: ["حركة الظهور", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "mt-1 w-full rounded-md border border-input bg-input p-2",
									value: editAnimationStyle,
									onChange: (e) => setEditAnimationStyle(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "zoom",
											children: "تكبير"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "slide",
											children: "انزلاق"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "float",
											children: "طفو"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "pulse",
											children: "نبض"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "بدون"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "col-span-2 text-xs",
								children: ["مدة الصور الثابتة (ms)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: "500",
									max: "120000",
									value: editDisplayDuration,
									onChange: (e) => setEditDisplayDuration(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "col-span-2 flex items-center gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: editAudioEnabled,
									onChange: (e) => setEditAudioEnabled(e.target.checked)
								}), " صوت الفيديو الأصلي"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full bg-gold",
						onClick: () => void saveAssetEdit(),
						children: "حفظ التعديلات"
					})
				]
			}),
			visible.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "glass rounded-2xl p-8 text-center text-sm text-muted-foreground",
				children: loading ? "جارٍ تحميل المكتبة…" : "لا توجد أصول مطابقة. ارفع أول أصل من النموذج أعلاه."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
				children: visible.map((asset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass min-w-0 overflow-hidden rounded-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex aspect-square items-center justify-center bg-secondary/60 p-2",
						children: previews[asset.id] && isImage(asset) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: previews[asset.id],
							alt: asset.name,
							className: "h-full w-full object-contain"
						}) : previews[asset.id] && isVideo(asset) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
							src: previews[asset.id],
							controls: true,
							playsInline: true,
							preload: "metadata",
							onLoadedMetadata: (e) => {
								e.currentTarget.playbackRate = Number(asset.metadata?.playback_speed ?? 1);
							},
							className: "h-full w-full object-contain"
						}) : isModel(asset) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, { className: "mx-auto h-12 w-12 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-2 block text-xs",
								children: "مجسم ثلاثي الأبعاد"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(File, { className: "mx-auto h-10 w-10 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-2 block text-xs",
								children: "ملف أصل"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-semibold",
								title: asset.name,
								children: asset.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-1 text-[10px] text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ASSET_CATEGORIES[asset.category] ?? asset.category }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: asset.metadata?.size ? `${(asset.metadata.size / 1024 / 1024).toFixed(1)} MB` : "" })]
							}),
							storeItems.filter((item) => item.asset_key === asset.asset_key).length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1 rounded-lg bg-primary/5 p-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-semibold text-primary",
									children: "المتجر المرتبط"
								}), storeItems.filter((item) => item.asset_key === asset.asset_key).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-1 text-[10px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "truncate",
										children: [
											item.name,
											" · ",
											KINDS[item.kind] ?? item.kind
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "shrink-0",
										children: ["🪙 ", Number(item.price).toLocaleString()]
									})]
								}, item.id))]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-muted-foreground",
								children: "المتجر: غير مرتبط بأي عنصر"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-2 py-1 text-[10px] ${asset.is_active ? "bg-green-500/15 text-green-500" : "bg-muted text-muted-foreground"}`,
									children: asset.is_active ? "نشط" : "متوقف"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-1",
									children: [
										previews[asset.id] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: previews[asset.id],
											target: "_blank",
											rel: "noreferrer",
											className: "rounded-md p-1.5 hover:bg-secondary",
											title: "فتح الملف",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => beginEditAsset(asset),
											className: "rounded-md p-1.5 hover:bg-secondary",
											title: "تعديل الأصل",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-4 w-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => toggleAsset(asset),
											className: "rounded-md p-1.5 hover:bg-secondary",
											title: asset.is_active ? "إيقاف" : "تفعيل",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, { className: "h-4 w-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => void deleteAsset(asset),
											className: "rounded-md p-1.5 text-destructive hover:bg-secondary",
											title: "حذف الأصل",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-[10px] text-muted-foreground",
								dir: "ltr",
								children: asset.asset_key
							})
						]
					})]
				}, asset.id))
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FullAdminPanel, {}) });
//#endregion
export { SplitComponent as component };
