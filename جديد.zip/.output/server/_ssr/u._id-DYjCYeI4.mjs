import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { n as getAdminAssetUrl } from "./media-BXNEENvw.mjs";
import { a as errMsg, o as flagOf } from "./vox-CkkqXMfh.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as MessageCircle, Tt as Ban, c as UserPlus, g as Sparkles, l as UserCheck, lt as DoorOpen, rt as Flag } from "../_libs/lucide-react.mjs";
import { n as PageHeader, t as AppShell } from "./AppShell-CNN_t4M1.mjs";
import { t as AdminAssetMedia } from "./AdminAssetMedia-CBSs12zp.mjs";
import { n as UserAvatar } from "./UserAvatar-DvFPapaA.mjs";
import { t as IdentityBadges } from "./IdentityBadges-CjJBvqnl.mjs";
import { t as Route } from "./u._id-bt2kJDLV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/u._id-DYjCYeI4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UserPage() {
	const { id } = Route.useParams();
	const { user } = useAuth();
	const uid = user.id;
	const nav = useNavigate();
	const [p, setP] = (0, import_react.useState)(null);
	const [stats, setStats] = (0, import_react.useState)({
		followers: 0,
		friends: 0,
		posts: 0,
		likes: 0,
		support: 0
	});
	const [isFollowing, setIsFollowing] = (0, import_react.useState)(false);
	const [blocked, setBlocked] = (0, import_react.useState)(false);
	const [badges, setBadges] = (0, import_react.useState)([]);
	const [currentRoom, setCurrentRoom] = (0, import_react.useState)(null);
	const [profileCardUrl, setProfileCardUrl] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (id === uid) {
			nav({ to: "/profile" });
			return;
		}
		const live = supabase.channel(`public-profile-${id}`).on("postgres_changes", {
			event: "UPDATE",
			schema: "public",
			table: "profiles",
			filter: `id=eq.${id}`
		}, (payload) => {
			setP((current) => current ? {
				...current,
				...payload.new
			} : payload.new);
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "user_badges",
			filter: `user_id=eq.${id}`
		}, async () => {
			const { data: rows } = await supabase.from("user_badges").select("badge_key,badge_name,badge_asset_key,badge_color,is_equipped").eq("user_id", id).eq("is_equipped", true);
			setBadges(rows ?? []);
		}).subscribe();
		(async () => {
			const { data } = await supabase.from("profiles").select("id,display_no,display_name,avatar_url,bio,country,level,vip_level,support_xp,total_gifts_received,total_gifts_value,profile_card_asset_key,chat_bubble_asset_key,sound_wave_asset_key,id_color,name_color,name_effect,name_effect_speed,equipped_frame,equipped_entry").eq("id", id).maybeSingle();
			setP(data);
			if (data?.profile_card_asset_key) setProfileCardUrl(await getAdminAssetUrl(data.profile_card_asset_key));
			const [a, b, c, f, bl, badgeRows, graph, userPosts, roomResult] = await Promise.all([
				supabase.from("follows").select("*", {
					count: "exact",
					head: true
				}).eq("following_id", id),
				supabase.from("follows").select("*", {
					count: "exact",
					head: true
				}).eq("follower_id", id),
				supabase.from("posts").select("id", { count: "exact" }).eq("user_id", id),
				supabase.from("follows").select("follower_id").eq("follower_id", uid).eq("following_id", id),
				supabase.from("user_blocks").select("blocked_id").eq("blocker_id", uid).eq("blocked_id", id),
				supabase.from("user_badges").select("badge_key,badge_name,badge_asset_key,badge_color,is_equipped").eq("user_id", id).eq("is_equipped", true),
				supabase.from("follows").select("follower_id,following_id").or(`follower_id.eq.${id},following_id.eq.${id}`),
				supabase.from("posts").select("id").eq("user_id", id),
				supabase.from("room_members").select("room_id,rooms(id,name,room_no)").eq("user_id", id).maybeSingle()
			]);
			const followerIds = new Set((graph.data ?? []).filter((r) => r.following_id === id).map((r) => r.follower_id));
			const followingIds = new Set((graph.data ?? []).filter((r) => r.follower_id === id).map((r) => r.following_id));
			const friendCount = [...followerIds].filter((userId) => followingIds.has(userId)).length;
			let likeCount = 0;
			const postIds = (userPosts.data ?? []).map((r) => r.id);
			if (postIds.length) {
				const { count } = await supabase.from("post_likes").select("post_id", {
					count: "exact",
					head: true
				}).in("post_id", postIds);
				likeCount = count ?? 0;
			}
			setStats({
				followers: a.count ?? 0,
				friends: friendCount,
				posts: c.count ?? 0,
				likes: likeCount,
				support: Number(data?.support_xp ?? 0)
			});
			setIsFollowing(!!f.data?.length);
			setBlocked(!!bl.data?.length);
			setBadges(badgeRows.data ?? []);
			const rr = roomResult.data;
			setCurrentRoom(rr?.rooms ?? null);
			supabase.rpc("visit_profile", { _profile: id });
		})();
		return () => {
			supabase.removeChannel(live);
		};
	}, [
		id,
		uid,
		nav
	]);
	async function toggleFollow() {
		const { error } = isFollowing ? await supabase.from("follows").delete().eq("follower_id", uid).eq("following_id", id) : await supabase.from("follows").upsert({
			follower_id: uid,
			following_id: id
		}, {
			onConflict: "follower_id,following_id",
			ignoreDuplicates: true
		});
		if (error) {
			toast.error(error.message);
			return;
		}
		setIsFollowing(!isFollowing);
		setStats((s) => ({
			...s,
			followers: s.followers + (isFollowing ? -1 : 1)
		}));
	}
	async function message() {
		const { data, error } = await supabase.rpc("get_or_create_conversation", { _other: id });
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		nav({
			to: "/chat/$id",
			params: { id: data }
		});
	}
	async function toggleBlock() {
		const { error } = blocked ? await supabase.from("user_blocks").delete().eq("blocker_id", uid).eq("blocked_id", id) : await supabase.from("user_blocks").insert({
			blocker_id: uid,
			blocked_id: id
		});
		if (error) {
			toast.error(error.message);
			return;
		}
		setBlocked(!blocked);
		toast.success(blocked ? "تم إلغاء الحظر" : "تم حظر المستخدم من مراسلتك");
	}
	async function report() {
		const reason = prompt("سبب البلاغ (إساءة، احتيال، انتحال شخصية...)");
		if (!reason) return;
		const { error } = await supabase.rpc("submit_report", {
			_type: "user",
			_target: id,
			_category: "مستخدم",
			_details: reason
		});
		if (error) toast.error(errMsg(error));
		else toast.success("تم إرسال البلاغ للإدارة");
	}
	if (!p) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "…",
		back: true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "الملف الشخصي الكامل",
			back: true
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-4 overflow-hidden rounded-[30px] border border-amber-300/35 bg-gradient-to-br from-slate-950 via-slate-900 to-violet-950 p-5 text-center text-white shadow-[0_20px_60px_rgba(0,0,0,.4)] ring-1 ring-amber-200/10",
			children: [profileCardUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
				src: profileCardUrl,
				className: "pointer-events-none absolute inset-0 h-full w-full object-cover opacity-30"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto w-fit",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
							src: p.avatar_url,
							name: p.display_name,
							size: 112,
							ring: true,
							vip: p.vip_level,
							frameKey: p.equipped_frame
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: `mt-3 text-2xl font-bold ${p.name_effect && p.name_effect !== "none" ? `name-effect-${p.name_effect}` : ""}`,
						style: {
							color: p.name_color || void 0,
							animationDuration: `${p.name_effect_speed || 1800}ms`
						},
						children: [
							flagOf(p.country),
							" ",
							p.display_name
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-bold",
						style: { color: p.id_color || "#D4AF37" },
						children: ["ID: ", p.display_no]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center justify-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-primary/15 px-3 py-1 text-xs font-black",
							children: ["Lv.", p.level]
						}), p.vip_level > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-gold/15 px-3 py-1 text-xs font-black text-gold",
							children: ["VIP ", p.vip_level]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityBadges, {
							level: p.level,
							vip: p.vip_level,
							badges: badges.filter((b) => b.is_equipped)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: p.bio || "لا توجد نبذة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-4 gap-2 rounded-2xl border border-white/10 bg-black/25 p-3 text-center backdrop-blur",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-black tabular-nums",
								children: stats.followers
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-white/65",
								children: "المتابِعون"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-black tabular-nums",
								children: stats.friends
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-white/65",
								children: "الأصدقاء"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-black tabular-nums",
								children: stats.posts
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-white/65",
								children: "المنشورات"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-black tabular-nums",
								children: stats.likes
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-white/65",
								children: "الإعجابات"
							})] })
						]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-4 mt-4 rounded-2xl border border-primary/15 bg-background/60 p-3 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "mx-auto h-5 w-5 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					className: "mt-1 block",
					children: stats.support.toLocaleString()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] text-muted-foreground",
					children: "دعم / XP"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-4 mt-4 grid grid-cols-2 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: toggleFollow,
					className: isFollowing ? "" : "bg-gold font-bold",
					variant: isFollowing ? "outline" : "default",
					children: isFollowing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "h-4 w-4" }), " متابَع"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4" }), " متابعة"] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: message,
					variant: "outline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), " مراسلة"]
				}),
				currentRoom && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => nav({
						to: "/room/$id",
						params: { id: currentRoom.id }
					}),
					variant: "outline",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoorOpen, { className: "h-4 w-4" }),
						" دخول الغرفة #",
						currentRoom.room_no
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: toggleBlock,
					variant: "outline",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "h-4 w-4" }),
						" ",
						blocked ? "إلغاء الحظر" : "حظر"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: report,
					variant: "outline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "h-4 w-4" }), " إبلاغ"]
				})
			]
		})
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPage, {}) });
//#endregion
export { SplitComponent as component };
