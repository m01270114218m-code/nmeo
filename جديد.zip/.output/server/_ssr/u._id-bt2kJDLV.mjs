import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/u._id-bt2kJDLV.js
var $$splitComponentImporter = () => import("./u._id-DYjCYeI4.mjs");
var Route = createFileRoute("/u/$id")({
	head: () => ({ meta: [
		{ title: "ملف مستخدم — صدى شات" },
		{
			name: "description",
			content: "الملف الشخصي للمستخدم في صدى شات."
		},
		{
			property: "og:title",
			content: "ملف مستخدم — صدى شات"
		},
		{
			property: "og:description",
			content: "الملف الشخصي للمستخدم."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
