import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as roomThemes, i as roomBackground, n as icons3d, o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn, t as Button } from "./button-DRsC1qZi.mjs";
import { i as uploadImage, n as getAdminAssetUrl, o as useMedia, r as isVideoAsset, t as deleteMedia } from "./media-BXNEENvw.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { a as errMsg, i as catName, o as flagOf, t as CATEGORIES } from "./vox-CkkqXMfh.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { $ as Gift, B as MessageCircle, Ct as Bell, E as Send, G as LockOpen, I as Music2, L as Minimize2, M as Play, Ot as ArrowDownToLine, P as Pause, Q as Heart, R as Mic, S as Shield, T as Settings, U as LogOut, W as Lock, _ as Sofa, a as Users, b as SkipBack, c as UserPlus, ft as Crown, g as Sparkles, i as Volume2, lt as DoorOpen, n as Wallet, r as VolumeX, t as X, tt as Gamepad2, ut as Dices, v as Smile, w as Share2, wt as BellOff, y as SkipForward, z as MicOff } from "../_libs/lucide-react.mjs";
import { r as RequireAuth, t as AppShell } from "./AppShell-CNN_t4M1.mjs";
import { t as AdminAssetMedia } from "./AdminAssetMedia-CBSs12zp.mjs";
import { n as UserAvatar, t as MediaImage } from "./UserAvatar-DvFPapaA.mjs";
import { t as IdentityBadges } from "./IdentityBadges-CjJBvqnl.mjs";
import { o as HomeScreen } from "./routes-BUCliJ9d.mjs";
import { t as Route } from "./room._id-GuSW03Ny.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/room._id-CSTJIogE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, overlayClassName, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, { className: overlayClassName }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
function RoomSettings({ room, uid, open, onOpenChange, onSaved }) {
	const [name, setName] = (0, import_react.useState)(room.name);
	const [desc, setDesc] = (0, import_react.useState)(room.description ?? "");
	const [cat, setCat] = (0, import_react.useState)(room.category);
	const [priv, setPriv] = (0, import_react.useState)(!!room.is_private);
	const [cover, setCover] = (0, import_react.useState)(room.cover_url ?? null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const coverUrl = useMedia(cover);
	async function pick(f) {
		if (!f) return;
		try {
			setBusy(true);
			setCover(await uploadImage(f, uid, `room/${room.id}`));
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "فشل الرفع");
		} finally {
			setBusy(false);
		}
	}
	async function save() {
		setBusy(true);
		const { error } = await supabase.rpc("update_room", {
			_room: room.id,
			_name: name,
			_description: desc,
			_category: cat,
			_is_private: priv,
			_cover_url: cover ?? ""
		});
		setBusy(false);
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		toast.success("تم حفظ إعدادات الغرفة");
		onSaved({
			...room,
			name: name.trim(),
			description: desc,
			category: cat,
			is_private: priv,
			cover_url: cover
		});
		onOpenChange(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "bottom",
			className: "max-h-[90vh] overflow-y-auto rounded-t-3xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "إعدادات الغرفة" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "card-3d relative flex h-32 cursor-pointer items-center justify-center overflow-hidden rounded-2xl bg-secondary",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: coverUrl || roomBackground(cat),
								alt: "غلاف الغرفة",
								className: "h-full w-full object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute bottom-2 rounded-full bg-background/70 px-3 py-1 text-xs",
								children: "تغيير صورة الغرفة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*",
								className: "hidden",
								onChange: (e) => pick(e.target.files?.[0])
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-2",
						children: roomThemes.map((theme) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							title: theme.name,
							"aria-label": theme.name,
							"aria-pressed": cover === theme.image,
							onClick: () => setCover(theme.image),
							className: `h-auto flex-col gap-1 p-1 ${cover === theme.image ? "ring-2 ring-primary" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: theme.image,
								alt: "",
								className: "aspect-square w-full rounded-md object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px]",
								children: theme.name
							})]
						}, theme.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						maxLength: 40,
						onChange: (e) => setName(e.target.value),
						placeholder: "اسم الغرفة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: desc,
						maxLength: 200,
						onChange: (e) => setDesc(e.target.value),
						placeholder: "وصف / إعلان الغرفة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => setCat(c.id),
							className: `rounded-full ${cat === c.id ? "bg-gold" : "bg-secondary"}`,
							children: c.name
						}, c.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center justify-between rounded-2xl bg-secondary/50 p-3 text-sm",
						children: ["غرفة خاصة (لا تظهر في القائمة)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: priv,
							onChange: (e) => setPriv(e.target.checked),
							className: "h-5 w-5 accent-[var(--primary)]"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							disabled: busy || !cover,
							onClick: async () => {
								if (!cover) return;
								const previous = cover;
								setCover(null);
								try {
									const { error } = await supabase.rpc("update_room", {
										_room: room.id,
										_name: name,
										_description: desc,
										_category: cat,
										_is_private: priv,
										_cover_url: ""
									});
									if (error) throw error;
									await deleteMedia(previous).catch(() => void 0);
									toast.success("تم حذف صورة الغرفة");
								} catch (e) {
									setCover(previous);
									toast.error(errMsg(e));
								}
							},
							children: "حذف الصورة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							disabled: busy || name.trim().length < 2,
							onClick: save,
							children: "حفظ"
						})]
					})
				]
			})]
		})
	});
}
var pendingRoomLeaves = /* @__PURE__ */ new Map();
function isRestoringMinimizedRoom(roomId) {
	if (localStorage.getItem("vox_minimized_room_id") === roomId) return true;
	try {
		return JSON.parse(localStorage.getItem("vox_minimized_room") || "null")?.id === roomId;
	} catch {
		return false;
	}
}
function formatMusicTime(value) {
	const seconds = Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0;
	return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
}
function normalizeSeats(rows) {
	const seenUsers = /* @__PURE__ */ new Set();
	return [...rows].sort((a, b) => a.seat_index - b.seat_index).filter((seat) => {
		if (!seat.user_id) return true;
		if (seenUsers.has(seat.user_id)) return false;
		seenUsers.add(seat.user_id);
		return true;
	});
}
function RoomPage() {
	const { id } = Route.useParams();
	const { user } = useAuth();
	const nav = useNavigate();
	const [room, setRoom] = (0, import_react.useState)(null);
	const [seats, setSeats] = (0, import_react.useState)([]);
	const [members, setMembers] = (0, import_react.useState)([]);
	const [msgs, setMsgs] = (0, import_react.useState)([]);
	const [profiles, setProfiles] = (0, import_react.useState)({});
	const [badges, setBadges] = (0, import_react.useState)({});
	const badgesLoadedRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const [cosmeticUrls, setCosmeticUrls] = (0, import_react.useState)({});
	const [isMod, setIsMod] = (0, import_react.useState)(false);
	const [text, setText] = (0, import_react.useState)("");
	const [seatMenu, setSeatMenu] = (0, import_react.useState)(null);
	const [showMembers, setShowMembers] = (0, import_react.useState)(false);
	const [gifts, setGifts] = (0, import_react.useState)([]);
	const [giftCategoriesList, setGiftCategoriesList] = (0, import_react.useState)([]);
	const [giftOpen, setGiftOpen] = (0, import_react.useState)(false);
	const [giftTab, setGiftTab] = (0, import_react.useState)("normal");
	const [giftCategory, setGiftCategory] = (0, import_react.useState)("all");
	const [giftTo, setGiftTo] = (0, import_react.useState)(null);
	const [giftSel, setGiftSel] = (0, import_react.useState)(null);
	const [luckyGifts, setLuckyGifts] = (0, import_react.useState)([]);
	const [luckySel, setLuckySel] = (0, import_react.useState)(null);
	const [qty, setQty] = (0, import_react.useState)(1);
	const [repeatGift, setRepeatGift] = (0, import_react.useState)(null);
	const repeatGiftTimer = (0, import_react.useRef)(null);
	const showRoomMessage = (0, import_react.useCallback)((message) => {
		setMsgs((current) => current.some((item) => item.id === message.id) ? current : [...current.slice(-99), message]);
	}, []);
	const [luckyRewardBanner, setLuckyRewardBanner] = (0, import_react.useState)(null);
	const [gift99Banner, setGift99Banner] = (0, import_react.useState)(null);
	const [luckyBarConfig, setLuckyBarConfig] = (0, import_react.useState)({
		enabled: true,
		position: "top",
		duration_ms: 3e3,
		width_px: 390,
		gift_size_px: 48,
		show_name: true,
		asset_key: null,
		global_min_reward: 1e4
	});
	const [coins, setCoins] = (0, import_react.useState)(0);
	const [anim, setAnim] = (0, import_react.useState)(null);
	const [entryAnim, setEntryAnim] = (0, import_react.useState)(null);
	const [voiceControls, setVoiceControls] = (0, import_react.useState)({});
	const [micPermissionGranted, setMicPermissionGranted] = (0, import_react.useState)(() => localStorage.getItem("vox_mic_permission_granted") === "1");
	const [musicFile, setMusicFileState] = (0, import_react.useState)(null);
	const setMusicFile = (0, import_react.useCallback)((file) => {
		setMusicFileState(file);
		window.dispatchEvent(new CustomEvent("vox-room-music-file", { detail: { file } }));
	}, []);
	const [musicQueue, setMusicQueue] = (0, import_react.useState)([]);
	const [musicQueueIndex, setMusicQueueIndex] = (0, import_react.useState)(0);
	const [musicOpen, setMusicOpen] = (0, import_react.useState)(false);
	const [musicProgress, setMusicProgress] = (0, import_react.useState)({
		currentTime: 0,
		duration: 0,
		playing: false
	});
	const [musicVolume, setMusicVolume] = (0, import_react.useState)(100);
	const [musicCommand, setMusicCommand] = (0, import_react.useState)(null);
	const musicCommandId = (0, import_react.useRef)(0);
	const sendMusicCommand = (0, import_react.useCallback)((action, value) => {
		setMusicCommand({
			id: ++musicCommandId.current,
			action,
			value
		});
	}, []);
	const [speakingUsers, setSpeakingUsers] = (0, import_react.useState)([]);
	const [micRequests, setMicRequests] = (0, import_react.useState)([]);
	const [myMicRequest, setMyMicRequest] = (0, import_react.useState)(null);
	const [chatMutedUser, setChatMutedUser] = (0, import_react.useState)(false);
	const [targetIsModerator, setTargetIsModerator] = (0, import_react.useState)(false);
	const [inviteOpen, setInviteOpen] = (0, import_react.useState)(false);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [exitPrompt, setExitPrompt] = (0, import_react.useState)(false);
	const [roomMinimized, setRoomMinimized] = (0, import_react.useState)(false);
	const [gamesOpen, setGamesOpen] = (0, import_react.useState)(false);
	const [micControlsOpen, setMicControlsOpen] = (0, import_react.useState)(false);
	const [chatInputVisible, setChatInputVisible] = (0, import_react.useState)(false);
	const [emojiOpen, setEmojiOpen] = (0, import_react.useState)(false);
	const [activeGame, setActiveGame] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (repeatGiftTimer.current !== null) window.clearTimeout(repeatGiftTimer.current);
		repeatGiftTimer.current = null;
		if (!repeatGift || giftOpen) return;
		repeatGiftTimer.current = window.setTimeout(() => {
			setRepeatGift(null);
			repeatGiftTimer.current = null;
		}, 5e3);
		return () => {
			if (repeatGiftTimer.current !== null) window.clearTimeout(repeatGiftTimer.current);
			repeatGiftTimer.current = null;
		};
	}, [repeatGift, giftOpen]);
	(0, import_react.useEffect)(() => {
		const restore = () => {
			localStorage.removeItem("vox_minimized_room");
			localStorage.removeItem("vox_minimized_room_id");
			setRoomMinimized(false);
		};
		const onProgress = (event) => {
			const progress = event.detail;
			if (progress) setMusicProgress(progress);
		};
		const onSpeaking = (event) => {
			const users = event.detail;
			if (Array.isArray(users)) setSpeakingUsers(users);
		};
		window.addEventListener("vox-room-restored", restore);
		window.addEventListener("vox-room-music-progress", onProgress);
		window.addEventListener("vox-room-speaking-users", onSpeaking);
		return () => {
			window.removeEventListener("vox-room-restored", restore);
			window.removeEventListener("vox-room-music-progress", onProgress);
			window.removeEventListener("vox-room-speaking-users", onSpeaking);
		};
	}, []);
	const [isLeavingRoom, setIsLeavingRoom] = (0, import_react.useState)(false);
	const [following, setFollowing] = (0, import_react.useState)(false);
	const [cardStats, setCardStats] = (0, import_react.useState)({
		followers: 0,
		friends: 0,
		posts: 0,
		likes: 0
	});
	const [cardRoom, setCardRoom] = (0, import_react.useState)(null);
	const roomCoverUrl = useMedia(room?.cover_url);
	async function getAssetPlaybackSettings(assetRef) {
		if (!assetRef) return {};
		const { data: byKey } = await supabase.from("admin_assets").select("metadata").eq("asset_key", assetRef).eq("is_active", true).maybeSingle();
		if (byKey?.metadata) return byKey.metadata;
		let storagePath = assetRef;
		if (/^https?:\/\//i.test(assetRef)) {
			const markerIndex = assetRef.indexOf("/storage/v1/object/");
			if (markerIndex >= 0) {
				const parts = assetRef.slice(markerIndex + 19).split("?")[0].split("/");
				const access = parts.shift();
				if (parts.shift() !== "admin-assets" || !access) return {};
				try {
					storagePath = decodeURIComponent(parts.join("/").replace(/^\/+/, ""));
				} catch {
					storagePath = parts.join("/").replace(/^\/+/, "");
				}
			}
		}
		if (!storagePath || storagePath === assetRef && !storagePath.includes("/")) return {};
		const { data: byPath } = await supabase.from("admin_assets").select("metadata").filter("metadata->>storage_path", "eq", storagePath).eq("is_active", true).maybeSingle();
		return byPath?.metadata ?? {};
	}
	function showGiftAnimation(image, config) {
		const token = Date.now() + Math.floor(Math.random() * 1e3);
		const duration = Math.max(500, Math.min(12e4, Number(config?.duration ?? 2600)));
		const speed = Math.max(.25, Math.min(3, Number(config?.speed ?? 1)));
		const playbackSpeed = Math.max(.25, Math.min(3, Number(config?.playbackSpeed ?? 1)));
		setAnim({
			key: token,
			emoji: image,
			name: "",
			style: config?.style || "zoom",
			speed,
			duration,
			mode: config?.mode || "animated",
			width: config?.width,
			height: config?.height,
			audioEnabled: config?.audioEnabled !== false,
			playbackSpeed
		});
		if (!isVideoAsset(image)) window.setTimeout(() => setAnim((current) => current?.key === token ? null : current), duration);
	}
	(0, import_react.useEffect)(() => {
		let active = true;
		const loadLuckyBar = async () => {
			const { data } = await supabase.from("lucky_gift_bar_config").select("*").eq("id", true).maybeSingle();
			if (!active || !data) return;
			setLuckyBarConfig({
				enabled: data.enabled !== false,
				position: data.position ?? "top",
				duration_ms: 3e3,
				width_px: Number(data.width_px ?? 390),
				gift_size_px: Number(data.gift_size_px ?? 48),
				show_name: data.show_name !== false,
				asset_key: data.asset_key ?? null,
				global_min_reward: Number(data.global_min_reward ?? 1e4)
			});
		};
		loadLuckyBar();
		return () => {
			active = false;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		let active = true;
		const refreshGiftCatalog = async () => {
			const [{ data: rows }, { data: cats }] = await Promise.all([supabase.from("gifts").select("id,name,emoji,price,tier,category_id,animation_style,animation_speed,display_duration_ms,asset_key,asset_url").eq("active", true).order("sort"), supabase.from("gift_categories").select("id,name,display_mode,sort_order").eq("is_active", true).order("sort_order")]);
			const resolved = await Promise.all((rows || []).map(async (gift) => ({
				...gift,
				asset_url: (gift.asset_key ? await getAdminAssetUrl(gift.asset_key) : null) || (gift.asset_url ? await getAdminAssetUrl(gift.asset_url) : null)
			})));
			if (active) {
				setGifts(resolved);
				setGiftCategoriesList(cats ?? []);
			}
		};
		const globalLuckyChannel = supabase.channel("vox-global-lucky-gifts").on("broadcast", { event: "lucky_global" }, async ({ payload }) => {
			const event = payload;
			const reward = Number(event.reward ?? 0);
			if (reward <= 0 || reward < Number(luckyBarConfig.global_min_reward ?? 1e4)) return;
			const bannerId = Date.now();
			setLuckyRewardBanner({
				id: bannerId,
				reward,
				percent: Number(event.rewardPercent ?? (event.spentCoins ? reward / event.spentCoins * 100 : 0))
			});
			window.setTimeout(() => setLuckyRewardBanner((current) => current?.id === bannerId ? null : current), 3e3);
		}).subscribe();
		const channel = supabase.channel(`room-gift-catalog-${id}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "gifts"
		}, () => {
			refreshGiftCatalog();
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "gift_categories"
		}, () => {
			refreshGiftCatalog();
		}).subscribe();
		return () => {
			active = false;
			supabase.removeChannel(channel);
			supabase.removeChannel(globalLuckyChannel);
		};
	}, [id]);
	(0, import_react.useEffect)(() => {
		if (!room) return;
		const onBack = () => {
			if (roomMinimized) window.dispatchEvent(new Event("vox-room-restored"));
			else setExitPrompt(true);
			window.history.pushState({ roomExitGuard: true }, "");
		};
		window.history.pushState({ roomExitGuard: true }, "");
		window.addEventListener("popstate", onBack);
		return () => window.removeEventListener("popstate", onBack);
	}, [room?.id, roomMinimized]);
	const chatEnd = (0, import_react.useRef)(null);
	const uid = user?.id ?? "";
	const isOwner = room?.owner_id === uid;
	const isStaff = isOwner || isMod;
	const publicName = (userId, fallback = "…") => {
		const p = profiles[userId];
		if (!p) return fallback;
		const effect = p.name_effect && p.name_effect !== "none" ? `name-effect-${p.name_effect}` : "";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: effect,
			style: {
				color: p.name_color || void 0,
				animationDuration: `${p.name_effect_speed || 1800}ms`
			},
			children: p.display_name
		});
	};
	const ensureProfiles = (0, import_react.useCallback)(async (ids) => {
		const uniqueIds = [...new Set(ids.filter(Boolean))];
		const missingProfiles = uniqueIds.filter((x) => !profiles[x]);
		const missingBadges = uniqueIds.filter((x) => !badgesLoadedRef.current.has(x));
		if (!missingProfiles.length && !missingBadges.length) return;
		const [{ data }, { data: badgeRows }] = await Promise.all([missingProfiles.length ? supabase.from("profiles").select("id,display_name,display_no,id_color,avatar_url,level,vip_level,equipped_frame,name_color,name_effect,name_effect_speed,chat_bubble_color,chat_bubble_asset_key,sound_wave_asset_key,profile_card_asset_key").in("id", missingProfiles) : Promise.resolve({ data: [] }), missingBadges.length ? supabase.from("user_badges").select("user_id,badge_name,badge_asset_key,badge_color,is_equipped").in("user_id", missingBadges).eq("is_equipped", true) : Promise.resolve({ data: [] })]);
		if (data?.length) setProfiles((p) => ({
			...p,
			...Object.fromEntries(data.map((d) => [d.id, d]))
		}));
		if (missingBadges.length) {
			const grouped = Object.fromEntries(missingBadges.map((userId) => [userId, []]));
			(badgeRows ?? []).forEach((row) => {
				const badge = row;
				(grouped[badge.user_id] ??= []).push(badge);
			});
			setBadges((current) => ({
				...current,
				...grouped
			}));
			missingBadges.forEach((userId) => badgesLoadedRef.current.add(userId));
		}
		const cosmeticEntries = await Promise.all((data ?? []).map(async (d) => [d.id, {
			bubble: d.chat_bubble_asset_key ? await getAdminAssetUrl(d.chat_bubble_asset_key) : void 0,
			wave: d.sound_wave_asset_key ? await getAdminAssetUrl(d.sound_wave_asset_key) : void 0,
			card: d.profile_card_asset_key ? await getAdminAssetUrl(d.profile_card_asset_key) : void 0
		}]));
		if (cosmeticEntries.length) setCosmeticUrls((v) => ({
			...v,
			...Object.fromEntries(cosmeticEntries)
		}));
	}, [profiles]);
	const loadSeats = (0, import_react.useCallback)(async () => {
		const { data } = await supabase.from("room_seats").select("seat_index,user_id,is_locked,is_muted").eq("room_id", id).order("seat_index");
		if (data) setSeats(normalizeSeats(data));
	}, [id]);
	async function playEntryFor(userId) {
		const { data: profile } = await supabase.from("profiles").select("display_name,avatar_url,level,vip_level,equipped_entry").eq("id", userId).maybeSingle();
		const equippedKey = profile?.equipped_entry;
		if (!equippedKey) return;
		const { data: directActive } = await supabase.rpc("get_active_direct_asset", {
			_user: userId,
			_asset_type: "entry",
			_asset_key: equippedKey
		});
		let assetKey = equippedKey;
		if (directActive !== true) {
			const { data: storeItem } = await supabase.from("store_items").select("*").eq("asset_key", equippedKey).eq("kind", "entry").maybeSingle();
			const storeExpiry = storeItem?.expires_at;
			if (!storeItem?.id || storeItem.asset_key !== equippedKey || storeExpiry && new Date(storeExpiry).getTime() <= Date.now()) return;
			assetKey = storeItem.asset_key;
		}
		const src = await getAdminAssetUrl(assetKey);
		if (!src) return;
		const settings = await getAssetPlaybackSettings(assetKey);
		const token = Date.now() + Math.floor(Math.random() * 1e3);
		setEntryAnim({
			key: token,
			src,
			name: profile?.display_name || "عضو",
			avatar: profile?.avatar_url || "",
			level: Number(profile?.level || 1),
			vip: Number(profile?.vip_level || 0),
			width: Number(settings.display_width) || void 0,
			height: Number(settings.display_height) || void 0,
			audioEnabled: settings.audio_enabled !== false,
			playbackSpeed: Math.max(.25, Math.min(3, Number(settings.playback_speed ?? 1))),
			animationStyle: settings.animation_style || "zoom",
			animationSpeed: Math.max(.25, Math.min(3, Number(settings.playback_speed ?? 1)))
		});
		if (!isVideoAsset(src)) {
			const displayDuration = Math.max(500, Math.min(12e4, Number(settings.display_duration_ms ?? 5200)));
			window.setTimeout(() => setEntryAnim((current) => current?.key === token ? null : current), displayDuration);
		}
	}
	const loadMembers = (0, import_react.useCallback)(async () => {
		const { data } = await supabase.from("room_members").select("user_id").eq("room_id", id);
		if (data) setMembers(data.map((d) => d.user_id));
	}, [id]);
	const loadMicRequests = (0, import_react.useCallback)(async () => {
		const { data } = await supabase.from("room_mic_requests").select("id,user_id,created_at").eq("room_id", id).eq("status", "pending").order("created_at");
		if (data) {
			setMicRequests(data);
			setMyMicRequest(data.find((r) => r.user_id === uid) ?? null);
		}
	}, [id, uid]);
	(0, import_react.useEffect)(() => {
		let alive = true;
		const pendingLeave = pendingRoomLeaves.get(id);
		let joinCompleted = false;
		let channelReady = false;
		let entryAnnounced = false;
		let restoringMiniRoom = false;
		let ch;
		const announceRoomEntry = async () => {
			if (restoringMiniRoom || !joinCompleted || !channelReady || entryAnnounced || !ch) return;
			entryAnnounced = true;
			await ch.send({
				type: "broadcast",
				event: "member_entered",
				payload: {
					roomId: id,
					userId: uid,
					entryId: crypto.randomUUID()
				}
			});
			playEntryFor(uid);
		};
		if (pendingLeave) {
			clearTimeout(pendingLeave);
			pendingRoomLeaves.delete(id);
		}
		(async () => {
			const { data: r, error } = await supabase.from("rooms").select("*").eq("id", id).maybeSingle();
			if (error || !r) {
				toast.error("الغرفة غير موجودة");
				return nav({ to: "/" });
			}
			restoringMiniRoom = isRestoringMinimizedRoom(id);
			const j = await supabase.rpc("join_room", { _room: id });
			if (j.error) {
				toast.error(errMsg(j.error));
				return nav({ to: "/" });
			}
			if (!alive) return;
			if (restoringMiniRoom || isRestoringMinimizedRoom(id)) {
				localStorage.removeItem("vox_minimized_room");
				localStorage.removeItem("vox_minimized_room_id");
				setRoomMinimized(false);
				window.dispatchEvent(new Event("vox-room-restored"));
			}
			setRoom(r);
			joinCompleted = true;
			announceRoomEntry();
			const { data: m } = await supabase.from("room_moderators").select("user_id").eq("room_id", id).eq("user_id", uid);
			setIsMod(!!m?.length);
			loadSeats();
			loadMembers();
			loadMicRequests();
		})();
		ch = supabase.channel(`room-${id}`).on("broadcast", { event: "chat_message" }, (payload) => {
			const message = payload.payload;
			if (message.roomId !== id || !message.id) return;
			showRoomMessage(message);
		}).on("broadcast", { event: "gift_sent" }, async (payload) => {
			const event = payload.payload;
			if (event.roomId !== id || !event.giftId) return;
			if (!event.lucky && Number(event.quantity || 0) >= 99) {
				const [{ data: sender }, { data: receiver }, { data: normalGift }] = await Promise.all([
					event.senderId ? supabase.from("profiles").select("display_name").eq("id", event.senderId).maybeSingle() : Promise.resolve({ data: null }),
					event.receiverId ? supabase.from("profiles").select("display_name").eq("id", event.receiverId).maybeSingle() : Promise.resolve({ data: null }),
					event.giftId ? supabase.from("gifts").select("name,asset_key,asset_url").eq("id", event.giftId).maybeSingle() : Promise.resolve({ data: null })
				]);
				const giftAsset = normalGift?.asset_key ? await getAdminAssetUrl(normalGift.asset_key) : normalGift?.asset_url ? await getAdminAssetUrl(normalGift.asset_url) : null;
				const bannerId = Date.now();
				setGift99Banner({
					id: bannerId,
					senderName: sender?.display_name || "مرسل",
					receiverName: receiver?.display_name || "مستلم",
					assetUrl: giftAsset,
					giftName: normalGift?.name || "هدية",
					quantity: Number(event.quantity || 99)
				});
				window.setTimeout(() => setGift99Banner((current) => current?.id === bannerId ? null : current), 3e3);
				return;
			}
			if (event.lucky) {
				const { data: lucky } = await supabase.from("lucky_gifts").select("name,asset_key").eq("id", event.giftId).maybeSingle();
				const image = lucky?.asset_key ? await getAdminAssetUrl(lucky.asset_key) : null;
				const settings = await getAssetPlaybackSettings(lucky?.asset_key);
				if (image) showGiftAnimation(image, {
					style: settings.animation_style,
					speed: settings.playback_speed,
					playbackSpeed: settings.playback_speed,
					duration: settings.display_duration_ms,
					width: settings.display_width,
					height: settings.display_height,
					audioEnabled: settings.audio_enabled
				});
				if (event.won && Number(event.reward) > 0 && Number(event.reward) < Number(luckyBarConfig.global_min_reward ?? 1e4)) {
					const reward = Number(event.reward);
					const spentCoins = Number(event.spentCoins ?? 0);
					const bannerId = Date.now();
					const delay = Math.max(500, Math.min(12e4, Number(settings.display_duration_ms ?? 2600)));
					window.setTimeout(() => {
						setLuckyRewardBanner({
							id: bannerId,
							reward,
							percent: Number(event.rewardPercent ?? (spentCoins > 0 ? reward / spentCoins * 100 : 0))
						});
						window.setTimeout(() => setLuckyRewardBanner((current) => current?.id === bannerId ? null : current), 3e3);
					}, delay);
				}
				return;
			}
			const { data: g } = await supabase.from("gifts").select("name,emoji,asset_key,asset_url,category_id,animation_style,animation_speed,display_duration_ms").eq("id", event.giftId).maybeSingle();
			if (!g) return;
			const assetRef = g.asset_key || g.asset_url;
			const image = (g.asset_key ? await getAdminAssetUrl(g.asset_key) : null) || (g.asset_url ? await getAdminAssetUrl(g.asset_url) : null);
			const settings = await getAssetPlaybackSettings(assetRef);
			const { data: category } = g.category_id ? await supabase.from("gift_categories").select("display_mode").eq("id", g.category_id).maybeSingle() : { data: null };
			if (image) showGiftAnimation(image, {
				style: g.animation_style || settings.animation_style,
				speed: g.animation_speed || settings.playback_speed,
				playbackSpeed: settings.playback_speed,
				duration: settings.display_duration_ms || g.display_duration_ms,
				mode: category?.display_mode || "animated",
				width: settings.display_width,
				height: settings.display_height,
				audioEnabled: settings.audio_enabled
			});
		}).on("broadcast", { event: "member_entered" }, async (payload) => {
			const event = payload.payload;
			if (event.roomId !== id || !event.userId || event.userId === uid) return;
			await ensureProfiles([event.userId]);
			playEntryFor(event.userId);
		}).on("broadcast", { event: "mic_request_changed" }, () => {
			loadMicRequests();
		}).on("broadcast", { event: "member_changed" }, () => {
			loadMembers();
			loadSeats();
		}).on("broadcast", { event: "seat_state" }, (payload) => {
			const data = payload.payload;
			if (data.roomId !== id) return;
			if (data.seat) setSeats((current) => normalizeSeats(current.some((s) => s.seat_index === data.seat.seat_index) ? current.map((s) => s.seat_index === data.seat.seat_index ? data.seat : s) : [...current, data.seat]));
			else if (data.userId) setSeats((current) => current.map((s) => s.user_id === data.userId ? {
				...s,
				user_id: null,
				is_muted: false
			} : s));
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "room_seats",
			filter: `room_id=eq.${id}`
		}, (payload) => {
			const next = payload.new;
			const prev = payload.old;
			const seatIndex = Number(next.seat_index ?? prev.seat_index);
			if (!Number.isInteger(seatIndex)) return;
			setSeats((current) => {
				if (payload.eventType === "DELETE") return current.filter((s) => s.seat_index !== seatIndex);
				const row = {
					seat_index: seatIndex,
					user_id: next.user_id ?? null,
					is_locked: !!next.is_locked,
					is_muted: !!next.is_muted
				};
				return normalizeSeats(current.some((s) => s.seat_index === seatIndex) ? current.map((s) => s.seat_index === seatIndex ? row : s) : [...current, row]);
			});
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "room_moderators",
			filter: `room_id=eq.${id}`
		}, (payload) => {
			if ((payload.eventType === "DELETE" ? payload.old : payload.new).user_id === uid) setIsMod(payload.eventType !== "DELETE");
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "user_badges"
		}, async (payload) => {
			const row = payload.eventType === "DELETE" ? payload.old : payload.new;
			if (!row.user_id) return;
			const { data: badgeRows } = await supabase.from("user_badges").select("user_id,badge_name,badge_asset_key,badge_color,is_equipped").eq("user_id", row.user_id).eq("is_equipped", true);
			setBadges((current) => ({
				...current,
				[row.user_id]: badgeRows ?? []
			}));
			badgesLoadedRef.current.add(row.user_id);
		}).on("postgres_changes", {
			event: "INSERT",
			schema: "public",
			table: "room_members",
			filter: `room_id=eq.${id}`
		}, async (payload) => {
			const userId = payload.new.user_id;
			setMembers((current) => current.includes(userId) ? current : [...current, userId]);
			await ensureProfiles([userId]);
		}).on("postgres_changes", {
			event: "DELETE",
			schema: "public",
			table: "room_members",
			filter: `room_id=eq.${id}`
		}, (payload) => {
			const userId = payload.old.user_id;
			setMembers((current) => current.filter((x) => x !== userId));
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "room_mic_requests",
			filter: `room_id=eq.${id}`
		}, (payload) => {
			const row = payload.new;
			if (payload.eventType === "DELETE" || row.status && row.status !== "pending") {
				const idToRemove = row.id || payload.old.id;
				if (idToRemove) setMicRequests((current) => current.filter((x) => x.id !== idToRemove));
				if (idToRemove === myMicRequest?.id) setMyMicRequest(null);
				return;
			}
			if (row.id && row.user_id && row.created_at) {
				setMicRequests((current) => current.some((x) => x.id === row.id) ? current : [...current, {
					id: row.id,
					user_id: row.user_id,
					created_at: row.created_at
				}]);
				if (row.user_id === uid) setMyMicRequest({ id: row.id });
			}
		}).on("postgres_changes", {
			event: "INSERT",
			schema: "public",
			table: "room_messages",
			filter: `room_id=eq.${id}`
		}, (p) => {
			const message = p.new;
			showRoomMessage(message);
		}).on("postgres_changes", {
			event: "UPDATE",
			schema: "public",
			table: "rooms",
			filter: `id=eq.${id}`
		}, (payload) => {
			setRoom((current) => current ? {
				...current,
				...payload.new
			} : current);
		}).subscribe((status) => {
			if (status === "SUBSCRIBED") {
				channelReady = true;
				announceRoomEntry();
				Promise.all([
					loadSeats(),
					loadMembers(),
					loadMicRequests()
				]);
				setMsgs([]);
			}
		});
		roomLive.current = ch;
		const loadCatalog = async () => {
			const [{ data: rows }, { data: lucky }, { data: cats }, { data: luckyBar }] = await Promise.all([
				supabase.from("gifts").select("id,name,emoji,price,tier,category_id,animation_style,animation_speed,display_duration_ms,asset_key,asset_url").eq("active", true).order("sort"),
				supabase.from("lucky_gifts").select("id,name,asset_key,price,win_chance,min_reward,max_reward").eq("active", true).order("sort_order"),
				supabase.from("gift_categories").select("id,name,display_mode,sort_order").eq("is_active", true).order("sort_order"),
				supabase.from("lucky_gift_bar_config").select("enabled,position,duration_ms,width_px,gift_size_px,show_name").eq("id", true).maybeSingle()
			]);
			const resolved = await Promise.all((rows || []).map(async (g) => ({
				...g,
				asset_url: (g.asset_key ? await getAdminAssetUrl(g.asset_key) : null) || (g.asset_url ? await getAdminAssetUrl(g.asset_url) : null)
			})));
			const resolvedLucky = await Promise.all((lucky || []).map(async (g) => ({
				...g,
				asset_url: g.asset_key ? await getAdminAssetUrl(g.asset_key) : null
			})));
			setGifts(resolved);
			setLuckyGifts(resolvedLucky);
			setGiftCategoriesList(cats ?? []);
			if (luckyBar) setLuckyBarConfig({
				enabled: luckyBar.enabled !== false,
				position: luckyBar.position ?? "top",
				duration_ms: Number(luckyBar.duration_ms ?? 5200),
				width_px: Number(luckyBar.width_px ?? 390),
				gift_size_px: Number(luckyBar.gift_size_px ?? 56),
				show_name: luckyBar.show_name !== false
			});
		};
		loadCatalog();
		const loadVoiceControls = async () => {
			const { data } = await supabase.from("admin_settings").select("value").eq("key", "voice_controls").maybeSingle();
			const cfg = data?.value || {};
			const getUrl = async (key) => {
				if (!key) return void 0;
				const { data: asset } = await supabase.from("admin_assets").select("url,metadata").eq("asset_key", key).eq("is_active", true).maybeSingle();
				const path = asset?.metadata?.storage_path || asset?.url;
				if (!path) return void 0;
				const { data: signed } = await supabase.storage.from("admin-assets").createSignedUrl(path, 3600);
				return signed?.signedUrl;
			};
			const [mic_asset_url, muted_asset_url, locked_asset_url, effect_asset_url] = await Promise.all([
				getUrl(cfg.mic_asset_key),
				getUrl(cfg.muted_asset_key),
				getUrl(cfg.locked_asset_key),
				getUrl(cfg.effect_asset_key)
			]);
			setVoiceControls({
				mic_style: cfg.mic_style,
				show_mic_effect: cfg.show_mic_effect,
				mic_asset_url,
				muted_asset_url,
				locked_asset_url,
				effect_asset_url,
				seat_gap_px: Math.max(0, Math.min(80, Number(cfg.seat_gap_px ?? 20))),
				avatar_size_px: Math.max(40, Math.min(120, Number(cfg.avatar_size_px ?? 72))),
				mic_icon_size_px: Math.max(16, Math.min(48, Number(cfg.mic_icon_size_px ?? 28)))
			});
		};
		loadVoiceControls();
		const voiceSettingsChannel = supabase.channel(`room-voice-settings-${id}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "admin_settings",
			filter: "key=eq.voice_controls"
		}, () => {
			loadVoiceControls();
		}).subscribe();
		return () => {
			alive = false;
			roomLive.current = null;
			supabase.removeChannel(ch);
			supabase.removeChannel(voiceSettingsChannel);
			if (!isRestoringMinimizedRoom(id)) {
				localStorage.removeItem("vox_active_room");
				localStorage.removeItem("vox_minimized_room_id");
				window.dispatchEvent(new Event("vox-room-closed"));
				const timer = setTimeout(() => {
					pendingRoomLeaves.delete(id);
					supabase.rpc("leave_room", { _room: id });
				}, 1e3);
				pendingRoomLeaves.set(id, timer);
			}
		};
	}, [id]);
	(0, import_react.useEffect)(() => {
		ensureProfiles([
			...members,
			...seats.map((s) => s.user_id ?? ""),
			...msgs.map((m) => m.user_id)
		]);
	}, [
		members,
		seats,
		msgs
	]);
	(0, import_react.useEffect)(() => {
		chatEnd.current?.scrollIntoView({ behavior: "smooth" });
	}, [msgs]);
	(0, import_react.useEffect)(() => {
		if (!room || !members.length || members.includes(uid)) return;
		let active = true;
		const timer = window.setTimeout(() => {
			supabase.from("room_members").select("user_id").eq("room_id", id).eq("user_id", uid).maybeSingle().then(({ data, error }) => {
				if (active && !error && !data) nav({ to: "/" });
			});
		}, 700);
		return () => {
			active = false;
			window.clearTimeout(timer);
		};
	}, [
		members,
		room,
		uid,
		nav
	]);
	const mySeat = seats.find((s) => s.user_id === uid);
	const myMicEnabled = !!mySeat && !mySeat.is_muted && !isLeavingRoom;
	(0, import_react.useEffect)(() => {
		if (!room?.id || !uid) return;
		const snapshot = {
			id: room.id,
			name: room.name,
			cover: room.cover_url ?? null,
			micEnabled: myMicEnabled && micPermissionGranted
		};
		localStorage.setItem("vox_active_room", JSON.stringify(snapshot));
		window.dispatchEvent(new CustomEvent("vox-room-session", { detail: {
			...snapshot,
			members,
			musicCommand
		} }));
	}, [
		room?.id,
		room?.name,
		room?.cover_url,
		uid,
		myMicEnabled,
		micPermissionGranted,
		members,
		musicCommand
	]);
	const roomLive = (0, import_react.useRef)(null);
	async function syncRoomSeats() {
		const { data, error } = await supabase.from("room_seats").select("seat_index,user_id,is_locked,is_muted").eq("room_id", id).order("seat_index");
		if (error || !data) return;
		const nextSeats = normalizeSeats(data);
		setSeats(nextSeats);
		await Promise.all(nextSeats.map((seat) => roomLive.current?.send({
			type: "broadcast",
			event: "seat_state",
			payload: {
				roomId: id,
				seat
			}
		})));
	}
	(0, import_react.useCallback)(async (seatIndex) => {
		const seat = seats.find((s) => s.seat_index === seatIndex);
		if (!seat) return;
		await roomLive.current?.send({
			type: "broadcast",
			event: "seat_state",
			payload: {
				roomId: id,
				seat
			}
		});
	}, [id, seats]);
	async function call(fn, args) {
		const { error } = await supabase.rpc(fn, args);
		if (error) {
			const message = error.message === "vip_protected" ? "هذا المستخدم محمي بمستوى VIP" : errMsg(error);
			toast.error(message);
			return;
		}
		const seatAction = fn === "staff_room_member_seat_action";
		if ((typeof args._seat === "number" ? args._seat : void 0) !== void 0 || seatAction || fn === "leave_seat" || fn === "toggle_my_mute" || fn === "take_seat" || fn === "staff_invite_to_mic" || fn === "staff_invite_to_seat") {
			await syncRoomSeats();
			await loadSeats();
		}
		if ([
			"staff_kick_room_user",
			"staff_kick_user_24h",
			"ban_user"
		].includes(fn)) {
			await Promise.all([
				loadMembers(),
				syncRoomSeats(),
				loadSeats()
			]);
			toast.success("تم طرد المستخدم من الغرفة");
			setSeatMenu(null);
			return;
		}
		if (fn === "staff_seat_action") {
			const action = String(args._action);
			setSeatMenu((current) => current ? {
				...current,
				is_locked: action === "lock" ? true : action === "unlock" ? false : current.is_locked,
				is_muted: action === "mute" ? true : action === "unmute" ? false : current.is_muted
			} : current);
			toast.success(action === "lock" ? "تم قفل الميك" : action === "unlock" ? "تم فتح الميك" : action === "mute" ? "تم كتم الميك" : "تم إلغاء كتم الميك");
			return;
		}
		if (seatAction) {
			const action = String(args._action);
			if (action === "mute" || action === "unmute") {
				setSeatMenu((current) => current ? {
					...current,
					is_muted: action === "mute"
				} : current);
				toast.success(action === "mute" ? "تم كتم صوت المستخدم" : "تم السماح للمستخدم بالتحدث");
				return;
			}
			if (action === "lower") {
				toast.success("تم إنزال المستخدم من الميك");
				setSeatMenu(null);
				return;
			}
		}
		if (fn === "staff_set_chat_mute") {
			setChatMutedUser(!!args._muted);
			toast.success(args._muted ? "تم منع المستخدم من الكتابة" : "تم السماح للمستخدم بالكتابة");
			return;
		}
		if (fn === "staff_set_room_moderator") {
			setTargetIsModerator(!!args._enabled);
			toast.success(args._enabled ? "تم تعيين المستخدم أدمن للغرفة" : "تمت إزالة صلاحية الأدمن");
			return;
		}
		setSeatMenu(null);
	}
	async function openUserCard(target) {
		setSeatMenu(seats.find((s) => s.user_id === target) ?? {
			seat_index: -1,
			user_id: target,
			is_locked: false,
			is_muted: false
		});
		ensureProfiles([target]);
		const [followers, graph, posts, roomResult, moderatorResult, badgeResult] = await Promise.all([
			supabase.from("follows").select("follower_id", {
				count: "exact",
				head: true
			}).eq("following_id", target),
			supabase.from("follows").select("follower_id,following_id").or(`follower_id.eq.${target},following_id.eq.${target}`),
			supabase.from("posts").select("id", {
				count: "exact",
				head: true
			}).eq("user_id", target),
			supabase.from("room_members").select("room_id,rooms(id,name,room_no)").eq("user_id", target).maybeSingle(),
			isStaff && target !== uid ? supabase.from("room_moderators").select("user_id").eq("room_id", id).eq("user_id", target).maybeSingle() : Promise.resolve({
				data: null,
				error: null
			}),
			supabase.from("user_badges").select("user_id,badge_name,badge_asset_key,badge_color,is_equipped").eq("user_id", target).eq("is_equipped", true)
		]);
		if (!moderatorResult.error) setTargetIsModerator(!!moderatorResult.data);
		if (!badgeResult.error) {
			setBadges((current) => ({
				...current,
				[target]: badgeResult.data ?? []
			}));
			badgesLoadedRef.current.add(target);
		}
		const followerIds = new Set((graph.data ?? []).filter((r) => r.following_id === target).map((r) => r.follower_id));
		const followingIds = new Set((graph.data ?? []).filter((r) => r.follower_id === target).map((r) => r.following_id));
		const friendCount = [...followerIds].filter((x) => followingIds.has(x)).length;
		let likes = 0;
		const { data: postRows } = await supabase.from("posts").select("id").eq("user_id", target);
		const postIds = (postRows ?? []).map((x) => x.id);
		if (postIds.length) {
			const { count } = await supabase.from("post_likes").select("id", {
				count: "exact",
				head: true
			}).in("post_id", postIds);
			likes = count ?? 0;
		}
		setCardStats({
			followers: followers.count ?? 0,
			friends: friendCount,
			posts: posts.count ?? 0,
			likes
		});
		const rr = roomResult.data;
		setCardRoom(rr?.rooms ?? null);
	}
	async function onSeat(s) {
		if (!s.user_id && !s.is_locked && !isStaff) {
			setSeatMenu(s);
			return;
		}
		if (s.is_locked && !isStaff) {
			toast.error("هذا الميك مقفول من صاحب الغرفة");
			return;
		}
		setSeatMenu(s);
		setChatMutedUser(false);
		setTargetIsModerator(false);
		if (s.user_id) openUserCard(s.user_id);
		if (isStaff && s.user_id && s.user_id !== uid) {
			const [muteResult, modResult] = await Promise.all([supabase.rpc("staff_is_chat_muted", {
				_room: id,
				_user: s.user_id
			}), supabase.from("room_moderators").select("user_id").eq("room_id", id).eq("user_id", s.user_id).maybeSingle()]);
			if (!muteResult.error) setChatMutedUser(!!muteResult.data);
			setTargetIsModerator(!!modResult.data);
		}
	}
	async function decideMicRequest(requestId, accept) {
		const { error } = await supabase.rpc("decide_mic_request", {
			_request: requestId,
			_accept: accept
		});
		if (error) toast.error(errMsg(error));
		else {
			await Promise.all([loadMicRequests(), syncRoomSeats()]);
			await roomLive.current?.send({
				type: "broadcast",
				event: "mic_request_changed",
				payload: { roomId: id }
			});
			await roomLive.current?.send({
				type: "broadcast",
				event: "member_changed",
				payload: { roomId: id }
			});
			toast.success(accept ? "تمت الموافقة على طلب الميك" : "تم رفض الطلب");
		}
	}
	async function toggleFollow(target) {
		if (!target || target === uid) return;
		const { data: existing } = await supabase.from("follows").select("follower_id,following_id").eq("follower_id", uid).eq("following_id", target).maybeSingle();
		if (existing) {
			const { error } = await supabase.from("follows").delete().eq("follower_id", uid).eq("following_id", target);
			if (error) toast.error(errMsg(error));
			else {
				setFollowing(false);
				toast.success("تم إلغاء المتابعة");
			}
		} else {
			const { error } = await supabase.from("follows").upsert({
				follower_id: uid,
				following_id: target
			}, {
				onConflict: "follower_id,following_id",
				ignoreDuplicates: true
			});
			if (error) toast.error(errMsg(error));
			else {
				setFollowing(true);
				toast.success("تمت المتابعة");
			}
		}
	}
	async function openGifts(target) {
		const { data } = await supabase.from("wallets").select("coins").eq("user_id", uid).maybeSingle();
		setCoins(Number(data?.coins ?? 0));
		const others = members.filter((m) => m !== uid);
		setGiftTo(target ?? seats.find((s) => s.user_id && s.user_id !== uid)?.user_id ?? others[0] ?? null);
		setGiftSel(null);
		setLuckySel(null);
		setGiftTab("normal");
		setGiftCategory("all");
		setQty(1);
		setSeatMenu(null);
		setGiftOpen(true);
	}
	async function sendGift() {
		if (!giftSel || !giftTo) return;
		const { error } = await supabase.rpc("send_gift", {
			_room: id,
			_receiver: giftTo,
			_gift: giftSel.id,
			_qty: qty
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		setCoins((c) => c - giftSel.price * qty);
		const giftAssetRef = giftSel.asset_key || giftSel.asset_url;
		const giftAssetUrl = giftAssetRef ? await getAdminAssetUrl(giftAssetRef) : null;
		const giftAssetSettings = await getAssetPlaybackSettings(giftAssetRef);
		if (giftAssetUrl) showGiftAnimation(giftAssetUrl, {
			style: giftSel.animation_style || giftAssetSettings.animation_style,
			speed: giftSel.animation_speed || giftAssetSettings.playback_speed,
			playbackSpeed: giftAssetSettings.playback_speed,
			duration: giftAssetSettings.display_duration_ms || giftSel.display_duration_ms,
			mode: giftCategoriesList.find((x) => x.id === giftSel.category_id)?.display_mode || "animated",
			width: giftAssetSettings.display_width,
			height: giftAssetSettings.display_height,
			audioEnabled: giftAssetSettings.audio_enabled
		});
		const senderName = profiles[uid]?.display_name || "مرسل";
		const receiverName = profiles[giftTo]?.display_name || (await supabase.from("profiles").select("display_name").eq("id", giftTo).maybeSingle()).data?.display_name || "مستلم";
		if (qty >= 99) {
			const bannerId = Date.now();
			setGift99Banner({
				id: bannerId,
				senderName,
				receiverName,
				assetUrl: giftAssetUrl,
				giftName: giftSel.name,
				quantity: qty
			});
			window.setTimeout(() => setGift99Banner((current) => current?.id === bannerId ? null : current), 3500);
		}
		await roomLive.current?.send({
			type: "broadcast",
			event: "gift_sent",
			payload: {
				roomId: id,
				giftId: giftSel.id,
				eventId: crypto.randomUUID(),
				senderId: uid,
				receiverId: giftTo,
				quantity: qty
			}
		});
		setRepeatGift({
			kind: "normal",
			gift: giftSel,
			receiverId: giftTo,
			qty
		});
		setGiftOpen(false);
	}
	async function sendLuckyGift() {
		if (!luckySel || !giftTo) return;
		const { data, error } = await supabase.rpc("send_lucky_gift", {
			_gift: luckySel.id,
			_receiver: giftTo,
			_room: id,
			_qty: qty
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		setCoins((c) => c - luckySel.price * qty);
		const luckyAsset = luckySel.asset_url || (luckySel.asset_key ? await getAdminAssetUrl(luckySel.asset_key) : null);
		const luckySettings = await getAssetPlaybackSettings(luckySel.asset_key);
		if (luckyAsset) showGiftAnimation(luckyAsset, {
			style: luckySettings.animation_style,
			speed: luckySettings.playback_speed,
			playbackSpeed: luckySettings.playback_speed,
			duration: luckySettings.display_duration_ms,
			width: luckySettings.display_width,
			height: luckySettings.display_height,
			audioEnabled: luckySettings.audio_enabled
		});
		const spentCoins = luckySel.price * qty;
		const reward = Number(data?.reward ?? 0);
		const rewardPercent = spentCoins > 0 ? reward / spentCoins * 100 : 0;
		if (data?.won && reward > 0) {
			const bannerId = Date.now();
			const delay = Math.max(500, Math.min(12e4, Number(luckySettings.display_duration_ms ?? 2600)));
			window.setTimeout(() => {
				setLuckyRewardBanner({
					id: bannerId,
					reward,
					percent: rewardPercent
				});
				window.setTimeout(() => setLuckyRewardBanner((current) => current?.id === bannerId ? null : current), 3e3);
			}, delay);
		}
		await roomLive.current?.send({
			type: "broadcast",
			event: "gift_sent",
			payload: {
				roomId: id,
				giftId: luckySel.id,
				eventId: crypto.randomUUID(),
				senderId: uid,
				receiverId: giftTo,
				quantity: qty,
				lucky: true,
				won: !!data?.won,
				reward,
				spentCoins,
				rewardPercent
			}
		});
		if (Number(data?.reward ?? 0) >= Number(luckyBarConfig.global_min_reward ?? 1e4)) await supabase.channel("vox-global-lucky-gifts").send({
			type: "broadcast",
			event: "lucky_global",
			payload: {
				reward,
				spentCoins,
				rewardPercent
			}
		});
		setRepeatGift({
			kind: "lucky",
			gift: luckySel,
			receiverId: giftTo,
			qty
		});
		setGiftOpen(false);
	}
	async function sendAgain() {
		if (!repeatGift) return;
		setRepeatGift((current) => current ? { ...current } : current);
		const target = repeatGift.receiverId;
		const amount = repeatGift.qty;
		if (repeatGift.kind === "normal") {
			const gift = repeatGift.gift;
			const { error } = await supabase.rpc("send_gift", {
				_room: id,
				_receiver: target,
				_gift: gift.id,
				_qty: amount
			});
			if (error) {
				toast.error(errMsg(error));
				return;
			}
			setCoins((current) => current - gift.price * amount);
			const assetRef = gift.asset_key || gift.asset_url;
			const image = assetRef ? await getAdminAssetUrl(assetRef) : null;
			const settings = await getAssetPlaybackSettings(assetRef);
			if (image) showGiftAnimation(image, {
				style: gift.animation_style || settings.animation_style,
				speed: gift.animation_speed || settings.playback_speed,
				playbackSpeed: settings.playback_speed,
				duration: settings.display_duration_ms || gift.display_duration_ms,
				mode: giftCategoriesList.find((item) => item.id === gift.category_id)?.display_mode || "animated",
				width: settings.display_width,
				height: settings.display_height,
				audioEnabled: settings.audio_enabled
			});
			if (amount >= 99) {
				const [{ data: sender }, { data: receiver }] = await Promise.all([supabase.from("profiles").select("display_name").eq("id", uid).maybeSingle(), supabase.from("profiles").select("display_name").eq("id", target).maybeSingle()]);
				const bannerId = Date.now();
				setGift99Banner({
					id: bannerId,
					senderName: sender?.display_name || "مرسل",
					receiverName: receiver?.display_name || "مستلم",
					assetUrl: image,
					giftName: gift.name,
					quantity: amount
				});
				window.setTimeout(() => setGift99Banner((current) => current?.id === bannerId ? null : current), 3500);
			}
			await roomLive.current?.send({
				type: "broadcast",
				event: "gift_sent",
				payload: {
					roomId: id,
					giftId: gift.id,
					eventId: crypto.randomUUID(),
					senderId: uid,
					receiverId: target,
					quantity: amount
				}
			});
		} else {
			const gift = repeatGift.gift;
			const { data, error } = await supabase.rpc("send_lucky_gift", {
				_gift: gift.id,
				_receiver: target,
				_room: id,
				_qty: amount
			});
			if (error) {
				toast.error(errMsg(error));
				return;
			}
			setCoins((current) => current - gift.price * amount);
			const image = gift.asset_key ? await getAdminAssetUrl(gift.asset_key) : null;
			const settings = await getAssetPlaybackSettings(gift.asset_key);
			if (image) showGiftAnimation(image, {
				style: settings.animation_style,
				speed: settings.playback_speed,
				playbackSpeed: settings.playback_speed,
				duration: settings.display_duration_ms,
				width: settings.display_width,
				height: settings.display_height,
				audioEnabled: settings.audio_enabled
			});
			const reward = Number(data?.reward ?? 0);
			const spentCoins = gift.price * amount;
			const rewardPercent = spentCoins > 0 ? reward / spentCoins * 100 : 0;
			if (data?.won && reward > 0) {
				const bannerId = Date.now();
				const delay = Math.max(500, Math.min(12e4, Number(settings.display_duration_ms ?? 2600)));
				window.setTimeout(() => {
					setLuckyRewardBanner({
						id: bannerId,
						reward,
						percent: rewardPercent
					});
					window.setTimeout(() => setLuckyRewardBanner((current) => current?.id === bannerId ? null : current), 3e3);
				}, delay);
			}
			await roomLive.current?.send({
				type: "broadcast",
				event: "gift_sent",
				payload: {
					roomId: id,
					giftId: gift.id,
					eventId: crypto.randomUUID(),
					senderId: uid,
					receiverId: target,
					quantity: amount,
					lucky: true,
					won: !!data?.won,
					reward,
					spentCoins,
					rewardPercent
				}
			});
		}
	}
	async function send(e) {
		e.preventDefault();
		if (!text.trim()) return;
		const body = text;
		setText("");
		const { error } = await supabase.rpc("send_room_message", {
			_room: id,
			_body: body
		});
		if (error) {
			toast.error(errMsg(error));
			setText(body);
			return;
		}
		const { data: saved } = await supabase.from("room_messages").select("id,user_id,body,created_at,kind").eq("room_id", id).eq("user_id", uid).eq("body", body).order("created_at", { ascending: false }).limit(1).maybeSingle();
		if (saved) {
			const message = saved;
			showRoomMessage(message);
			await roomLive.current?.send({
				type: "broadcast",
				event: "chat_message",
				payload: {
					roomId: id,
					...message
				}
			});
		}
	}
	async function share() {
		const url = window.location.href;
		if (navigator.share) await navigator.share({
			title: room?.name ?? "صدى شات",
			url
		}).catch(() => {});
		else {
			await navigator.clipboard.writeText(url);
			toast.success("تم نسخ رابط الغرفة");
		}
	}
	if (!room) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: icons3d.micHost,
			alt: "صدى شات",
			className: "h-16 w-16 animate-pulse object-contain"
		})
	});
	const giftCategories = giftCategoriesList;
	const visibleGifts = giftCategory === "all" ? gifts : gifts.filter((gift) => gift.category_id === giftCategory);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: "room-music-file",
			type: "file",
			accept: "audio/*,.mp3,.m4a,.aac,.wav,.ogg,.oga,.opus,.weba,.flac,.aiff,.aif,.3gp,.amr,.mid,.midi",
			multiple: true,
			className: "hidden",
			onChange: (e) => {
				const files = Array.from(e.target.files ?? []);
				e.currentTarget.value = "";
				if (!files.length) return;
				if (!myMicEnabled || !micPermissionGranted) {
					toast.error("يجب أن تكون على الميك أولاً حتى يسمع الجميع الأغاني");
					return;
				}
				const playable = files.filter((file) => file.type.startsWith("audio/") || /\.(mp3|m4a|aac|wav|ogg|oga|opus|weba|flac|aiff|aif|3gp|amr|mid|midi)$/i.test(file.name));
				if (!playable.length) {
					toast.error("لم يتم العثور على ملفات صوتية مدعومة");
					return;
				}
				setMusicQueue(playable);
				setMusicQueueIndex(0);
				setMusicProgress({
					currentTime: 0,
					duration: 0,
					playing: true
				});
				setMusicFile(playable[0]);
				setMusicOpen(false);
			}
		}),
		myMicEnabled && micPermissionGranted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			onClick: () => setMusicOpen(true),
			className: "fixed bottom-24 left-4 z-[95] h-14 w-14 rounded-full border border-gold/50 bg-gold text-black shadow-2xl",
			"aria-label": "مشغل الموسيقى",
			title: "مشغل الموسيقى",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "h-6 w-6" }), musicFile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -right-1 -top-1 h-3 w-3 rounded-full bg-green-500 ring-2 ring-background" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			open: musicOpen,
			onOpenChange: setMusicOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
				side: "bottom",
				dir: "rtl",
				className: "max-h-[88dvh] overflow-y-auto rounded-t-3xl border-gold/20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "h-5 w-5 text-gold" }), " مشغل موسيقى الغرفة"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					size: "sm",
					className: "w-full",
					onClick: () => setMusicOpen(false),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, { className: "ml-2 h-4 w-4" }), " تصغير المشغل والعودة للغرفة"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-primary/20 bg-secondary/40 p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-bold",
									children: musicFile?.name ?? "لم يتم اختيار أغنية بعد"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 text-xs text-muted-foreground",
									children: musicFile ? "صوت الأغنية يُبث للموجودين في الغرفة عبر Agora" : "استورد أغانيك من ملفات الجهاز لتشغيلها للجميع"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									htmlFor: "room-music-file",
									className: "mt-3 flex cursor-pointer items-center justify-center rounded-xl bg-gold px-4 py-3 text-sm font-bold text-black",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "ml-2 h-4 w-4" }), " استيراد أغاني من الجهاز"]
								})
							]
						}),
						musicQueue.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold",
									children: "قائمة التشغيل"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [musicQueue.length, " أغنية"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "max-h-44 space-y-1 overflow-y-auto",
								children: musicQueue.map((file, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setMusicQueueIndex(index);
										setMusicFile(file);
										setMusicProgress({
											currentTime: 0,
											duration: 0,
											playing: true
										});
									},
									className: musicQueueIndex === index ? "flex w-full items-center gap-3 rounded-xl border border-gold/50 bg-gold/10 px-3 py-2 text-right" : "flex w-full items-center gap-3 rounded-xl border border-white/10 bg-black/10 px-3 py-2 text-right",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-gold/15 text-gold",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, { className: "h-4 w-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "min-w-0 flex-1 truncate text-xs font-semibold",
											children: file.name
										}),
										musicQueueIndex === index && musicProgress.playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-emerald-400",
											children: "يعمل الآن"
										})
									]
								}, index + file.name))
							})]
						}),
						musicFile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										size: "icon",
										disabled: musicQueueIndex <= 0,
										onClick: () => {
											const index = Math.max(0, musicQueueIndex - 1);
											setMusicQueueIndex(index);
											setMusicFile(musicQueue[index]);
											setMusicProgress({
												currentTime: 0,
												duration: 0,
												playing: true
											});
										},
										"aria-label": "الأغنية السابقة",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, { className: "h-5 w-5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										className: "h-12 w-12 rounded-full bg-gold text-black",
										onClick: () => sendMusicCommand(musicProgress.playing ? "pause" : "resume"),
										"aria-label": musicProgress.playing ? "إيقاف مؤقت" : "استكمال التشغيل",
										children: musicProgress.playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-6 w-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-6 w-6" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										size: "icon",
										disabled: musicQueueIndex >= musicQueue.length - 1,
										onClick: () => {
											const index = Math.min(musicQueue.length - 1, musicQueueIndex + 1);
											setMusicQueueIndex(index);
											setMusicFile(musicQueue[index]);
											setMusicProgress({
												currentTime: 0,
												duration: 0,
												playing: true
											});
										},
										"aria-label": "الأغنية التالية",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "h-5 w-5" })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									"aria-label": "تقديم أو إرجاع الأغنية",
									type: "range",
									min: "0",
									max: Math.max(1, musicProgress.duration),
									step: "0.5",
									value: Math.min(musicProgress.currentTime, musicProgress.duration || 0),
									onChange: (e) => sendMusicCommand("seek", Number(e.target.value)),
									className: "w-full accent-[hsl(var(--primary))]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-[11px] tabular-nums text-muted-foreground",
									dir: "ltr",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatMusicTime(musicProgress.currentTime) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatMusicTime(musicProgress.duration) })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "h-5 w-5 shrink-0 text-gold" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										"aria-label": "مستوى صوت بث الأغنية",
										type: "range",
										min: "0",
										max: "100",
										value: musicVolume,
										onChange: (e) => {
											const next = Number(e.target.value);
											setMusicVolume(next);
											sendMusicCommand("volume", next);
										},
										className: "w-full accent-[hsl(var(--primary))]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "w-10 text-left text-xs tabular-nums",
										children: [musicVolume, "%"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "destructive",
								className: "w-full",
								onClick: () => {
									setMusicFile(null);
									setMusicQueue([]);
									setMusicQueueIndex(0);
									setMusicProgress({
										currentTime: 0,
										duration: 0,
										playing: false
									});
								},
								children: "إيقاف الأغاني وإزالة القائمة"
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center text-[11px] text-muted-foreground",
							children: "البث الجماعي متاح أثناء وجودك على الميكروفون. اختيار الملفات يتم من نافذة ملفات الجهاز."
						})
					]
				})]
			})
		}),
		roomMinimized ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {}) }) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "room-reference room-scene mx-auto flex h-dvh max-w-2xl flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaImage, {
					src: roomBackground(room.category),
					className: "room-scenery"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "glass m-3 flex items-center gap-3 rounded-2xl p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: () => setExitPrompt(true),
							"aria-label": "رجوع",
							title: "رجوع",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: icons3d.back,
								alt: "",
								className: "h-7 w-7 rotate-180 object-contain"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
								src: roomCoverUrl || roomBackground(room.category),
								alt: `صورة ${room.name}`,
								className: "h-11 w-11 shrink-0 rounded-xl object-cover ring-1 ring-primary/40"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "truncate font-bold",
									children: [
										flagOf(room.country),
										" ",
										room.name
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [
										"#",
										room.room_no,
										" · ",
										catName(room.category)
									]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => setShowMembers(true),
							className: "gap-1 rounded-full px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: icons3d.friends,
								alt: "",
								className: "h-5 w-5 object-contain"
							}), members.length]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: share,
							"aria-label": "مشاركة",
							title: "مشاركة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: icons3d.share,
								alt: "",
								className: "h-6 w-6 object-contain"
							})
						}),
						isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "إعدادات الغرفة",
							title: "إعدادات الغرفة",
							onClick: () => setSettingsOpen(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: icons3d.gear,
								alt: "",
								className: "h-6 w-6 object-contain"
							})
						}),
						isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "حذف الغرفة",
							title: "حذف الغرفة",
							onClick: async () => {
								if (confirm("حذف الغرفة نهائياً؟")) {
									const { error } = await supabase.rpc("delete_room", { _room: id });
									if (error) toast.error(errMsg(error));
									else nav({ to: "/" });
								}
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: icons3d.trash,
								alt: "",
								className: "h-6 w-6 object-contain"
							})
						})
					]
				}),
				isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomSettings, {
					room,
					uid,
					open: settingsOpen,
					onOpenChange: setSettingsOpen,
					onSaved: (r) => setRoom({
						...room,
						...r
					})
				}),
				isStaff && micRequests.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-3 mb-2 rounded-2xl border border-primary/30 bg-secondary/80 p-3",
					dir: "rtl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2 flex items-center justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-bold",
							children: [
								"طلبات الصعود للميك (",
								micRequests.length,
								")"
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: micRequests.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 rounded-xl bg-background/60 p-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
									src: profiles[r.user_id]?.avatar_url,
									name: publicName(r.user_id, "مستخدم"),
									vip: profiles[r.user_id]?.vip_level,
									size: 38
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate",
									children: publicName(r.user_id, "مستخدم")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => void decideMicRequest(r.id, true),
									className: "bg-gold",
									children: "موافقة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => void decideMicRequest(r.id, false),
									children: "رفض"
								})
							]
						}, r.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-3 py-3",
					children: (() => {
						const hostSeat = seats.find((s) => s.user_id === room.owner_id);
						const otherSeats = seats.filter((s) => s.user_id !== room.owner_id);
						const renderSeat = (s, large = false) => {
							const p = s.user_id ? profiles[s.user_id] : null;
							const host = s.user_id === room.owner_id;
							const size = large ? Math.min(96, Number(voiceControls.avatar_size_px ?? 72) + 24) : Number(voiceControls.avatar_size_px ?? 72);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								"aria-label": `المقعد ${s.seat_index + 1}${s.is_locked ? " مقفل" : ""}`,
								onClick: () => onSeat(s),
								className: "h-auto min-w-0 flex-col gap-1 p-0 hover:bg-transparent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `relative flex items-center justify-center ${large ? "rounded-full p-1" : ""}`,
									style: {
										width: size,
										height: size
									},
									children: [
										large && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 rounded-full bg-gradient-to-br from-amber-400 via-yellow-500 to-orange-500 opacity-80 blur-sm" }),
										large && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -inset-1 rounded-full bg-gradient-to-br from-amber-300/60 via-transparent to-yellow-500/60" }),
										p && speakingUsers.includes(s.user_id) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "speaker-ring speaker-ring-one" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "speaker-ring speaker-ring-two" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "speaker-glow" })
										] }),
										p ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
											src: p.avatar_url,
											name: p.display_name,
											vip: p.vip_level,
											size,
											frameKey: p.equipped_frame
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
											src: s.is_locked ? voiceControls.locked_asset_url || icons3d.micLocked : voiceControls.mic_asset_url || (s.seat_index === 0 ? icons3d.micHost : icons3d.mic),
											className: "h-full w-full object-contain"
										}),
										p && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute -bottom-1 -left-1 block",
											style: {
												width: Number(voiceControls.mic_icon_size_px ?? 28),
												height: Number(voiceControls.mic_icon_size_px ?? 28)
											},
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
												src: s.is_muted ? voiceControls.muted_asset_url || icons3d.micMuted : voiceControls.mic_asset_url || (host ? icons3d.micHost : icons3d.mic),
												alt: s.is_muted ? "مكتوم" : "على المقعد",
												className: `h-full w-full object-contain ${!s.is_muted && speakingUsers.includes(s.user_id) ? "speaker-mic-pulse" : ""}`,
												videoClassName: `h-full w-full object-contain ${!s.is_muted && speakingUsers.includes(s.user_id) ? "speaker-mic-pulse" : ""}`
											})
										}),
										p && cosmeticUrls[p.id]?.wave && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
											src: cosmeticUrls[p.id].wave,
											className: "pointer-events-none absolute -inset-2 h-[calc(100%+16px)] w-[calc(100%+16px)] object-contain opacity-90"
										}),
										p && voiceControls.show_mic_effect && voiceControls.effect_asset_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
											src: voiceControls.effect_asset_url,
											className: "pointer-events-none absolute inset-0 h-full w-full object-contain"
										}),
										large && host && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 px-2 py-0.5 text-[9px] font-black text-black shadow-lg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "inline h-3 w-3" }), " صاحب الغرفة"]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `max-w-24 truncate text-xs font-bold ${p?.name_effect && p.name_effect !== "none" ? `name-effect-${p.name_effect}` : ""} ${large ? "text-sm" : ""}`,
									style: {
										color: p?.name_color || void 0,
										animationDuration: `${p?.name_effect_speed || 1800}ms`
									},
									children: p ? p.display_name : `No.${s.seat_index + 1}`
								})]
							}, s.seat_index);
						};
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [hostSeat && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 flex justify-center",
							children: renderSeat(hostSeat, true)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-5 gap-x-2 gap-y-3",
							style: {
								columnGap: `${Math.max(0, Math.min(80, Number(voiceControls.seat_gap_px ?? 12)))}px`,
								rowGap: `${Math.max(8, Math.min(80, Number(voiceControls.seat_gap_px ?? 16)))}px`
							},
							children: otherSeats.map((s) => renderSeat(s, false))
						})] });
					})()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 space-y-2 overflow-y-auto px-3 pb-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-black/30 p-2 text-xs text-emerald-200 backdrop-blur",
							children: [
								"📢 مرحباً بك في ",
								room.name,
								". ",
								room.description
							]
						}),
						msgs.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `relative isolate w-fit max-w-[85%] overflow-hidden rounded-2xl px-3 py-1.5 text-sm ${m.kind === "gift" ? "bg-gold font-bold" : "bg-[#7c3aed]/90 text-white shadow-lg backdrop-blur"}`,
							style: { backgroundColor: m.kind === "gift" ? void 0 : profiles[m.user_id]?.chat_bubble_color || void 0 },
							children: [m.kind !== "gift" && cosmeticUrls[m.user_id]?.bubble && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
								src: cosmeticUrls[m.user_id].bubble,
								className: "pointer-events-none absolute inset-0 z-0 h-full w-full object-fill opacity-90"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "relative z-10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "font-bold text-amber-200",
									style: { color: profiles[m.user_id]?.name_color || void 0 },
									onClick: () => void openUserCard(m.user_id),
									children: [publicName(m.user_id), ": "]
								}), m.body]
							})]
						}, m.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: chatEnd })
					]
				}),
				chatInputVisible && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: send,
					className: "room-chat-composer glass mx-2 mb-1 flex shrink-0 items-center gap-1.5 rounded-full p-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: text,
						onChange: (e) => setText(e.target.value),
						maxLength: 500,
						placeholder: "اكتب رسالة…",
						className: "h-9 min-h-0 border-0 bg-transparent px-2 text-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "icon",
						"aria-label": "إرسال",
						title: "إرسال",
						className: "h-9 w-9 shrink-0 rounded-full bg-emerald-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-5 w-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 items-center justify-around gap-1 px-3 py-2",
					dir: "rtl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => openGifts(),
							className: "flex flex-col items-center gap-0.5 rounded-xl p-1.5 text-white/90 hover:bg-white/10",
							"aria-label": "هدايا",
							title: "هدايا",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-rose-500 to-pink-600 shadow-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-bold",
								children: "هدايا"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setShowMembers(true),
							className: "flex flex-col items-center gap-0.5 rounded-xl p-1.5 text-white/90 hover:bg-white/10",
							"aria-label": "القائمة",
							title: "القائمة",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-slate-500 to-slate-700 shadow-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-bold",
								children: "القائمة"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMicControlsOpen(true),
							className: "flex flex-col items-center gap-0.5 rounded-xl p-1.5",
							"aria-label": "الميك",
							title: "الميك",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `grid h-12 w-12 place-items-center rounded-full shadow-lg ${mySeat && !mySeat.is_muted && micPermissionGranted ? "bg-gradient-to-br from-emerald-500 to-green-600" : "bg-gradient-to-br from-rose-500 to-red-600"}`,
								children: mySeat && !mySeat.is_muted && micPermissionGranted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "h-6 w-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, { className: "h-6 w-6" })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setChatInputVisible((v) => !v),
							className: `flex flex-col items-center gap-0.5 rounded-xl p-1.5 hover:bg-white/10 ${chatInputVisible ? "text-emerald-300" : "text-white/90"}`,
							"aria-label": "الدردشة",
							title: "الدردشة",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-purple-600 shadow-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-bold",
								children: "دردشة"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setGamesOpen(true),
							className: "flex flex-col items-center gap-0.5 rounded-xl p-1.5 text-white/90 hover:bg-white/10",
							"aria-label": "الألعاب",
							title: "الألعاب",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-amber-500 to-orange-600 shadow-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gamepad2, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-bold",
								children: "ألعاب"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setEmojiOpen((v) => !v),
							className: "flex flex-col items-center gap-0.5 rounded-xl p-1.5 text-white/90 hover:bg-white/10",
							"aria-label": "إيموجي",
							title: "إيموجي",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 shadow-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smile, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-bold",
								children: "إيموجي"
							})]
						})
					]
				}),
				emojiOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-2 mb-2 rounded-2xl bg-black/60 p-3 backdrop-blur-xl",
					dir: "rtl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-8 gap-2",
						children: [
							"😀",
							"😂",
							"🥰",
							"😎",
							"🤔",
							"😴",
							"😭",
							"😡",
							"👍",
							"👎",
							"❤️",
							"🔥",
							"🎉",
							"✨",
							"🌹",
							"🍺",
							"🎵",
							"🎮",
							"💎",
							"🪙",
							"👑",
							"⭐",
							"💯",
							"🚀",
							"🎁",
							"🙏",
							"👏",
							"💪"
						].map((em) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setText((t) => t + em);
								setEmojiOpen(false);
								setChatInputVisible(true);
							},
							className: "grid h-9 w-9 place-items-center rounded-lg bg-white/5 text-xl hover:bg-white/15",
							children: em
						}, em))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
					open: !!seatMenu,
					onOpenChange: (o) => !o && setSeatMenu(null),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
						side: "bottom",
						dir: "rtl",
						overlayClassName: "!bg-transparent",
						className: seatMenu?.user_id ? "!fixed !left-1/2 !top-1/2 !right-auto !bottom-auto !h-auto !max-h-[84dvh] !w-[min(92vw,380px)] !max-w-[380px] !-translate-x-1/2 !-translate-y-1/2 !rounded-2xl !border-0 !bg-transparent !p-0 !shadow-none" : "!fixed !inset-x-0 !bottom-4 !top-auto !mx-auto !h-auto !w-[min(92vw,420px)] !max-w-[420px] !translate-y-0 !rounded-2xl !border border-white/20 !bg-slate-950/45 !p-3 !shadow-2xl !backdrop-blur-2xl",
						children: [!seatMenu?.user_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: seatMenu && seatMenu.seat_index >= 0 ? `المقعد ${seatMenu.seat_index + 1}` : "إدارة المستخدم" }) }), seatMenu && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: seatMenu.user_id ? "flex w-full flex-col items-center justify-center gap-2 p-0" : "grid gap-2 p-4",
							children: [
								!seatMenu.user_id && seatMenu.seat_index >= 0 && !seatMenu.is_locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: async () => {
										const { error } = await supabase.rpc("take_seat", {
											_room: id,
											_seat: seatMenu.seat_index
										});
										if (error) toast.error(errMsg(error));
										else {
											await syncRoomSeats();
											setSeatMenu(null);
											toast.success("تم الصعود للميك مباشرة");
										}
									},
									className: "w-full bg-emerald-500/20 text-emerald-100 hover:bg-emerald-500/30",
									children: "أخذ الميك"
								}),
								isStaff && seatMenu.seat_index >= 0 && !seatMenu.user_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => setInviteOpen(true),
									className: "w-full border-violet-200/25 bg-white/5 text-white",
									children: "دعوة مستخدم للميك"
								}),
								isStaff && seatMenu.seat_index >= 0 && !seatMenu.user_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									onClick: () => void call("staff_seat_action", {
										_room: id,
										_seat: seatMenu.seat_index,
										_action: seatMenu.is_locked ? "unlock" : "lock"
									}),
									className: "w-full border-amber-300/30 bg-white/5 text-amber-100",
									children: seatMenu.is_locked ? "فتح الميك" : "قفل الميك"
								}),
								seatMenu.user_id && profiles[seatMenu.user_id] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mx-auto max-h-[78dvh] w-[min(92vw,380px)] max-w-[380px] overflow-y-auto overflow-x-hidden rounded-2xl border border-white/15 bg-black/45 p-4 text-right text-white shadow-2xl backdrop-blur-xl",
									dir: "rtl",
									children: [seatMenu.user_id && cosmeticUrls[seatMenu.user_id]?.card && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
										src: cosmeticUrls[seatMenu.user_id].card,
										className: "pointer-events-none absolute inset-0 h-full w-full object-cover opacity-25"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => nav({
														to: "/u/$id",
														params: { id: seatMenu.user_id }
													}),
													className: "shrink-0 rounded-full",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
														src: profiles[seatMenu.user_id]?.avatar_url,
														name: profiles[seatMenu.user_id]?.display_name || "مستخدم",
														vip: profiles[seatMenu.user_id]?.vip_level,
														size: 68,
														frameKey: profiles[seatMenu.user_id]?.equipped_frame
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0 flex-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => nav({
																to: "/u/$id",
																params: { id: seatMenu.user_id }
															}),
															className: "max-w-full truncate text-right text-base font-bold",
															style: { color: profiles[seatMenu.user_id]?.name_color || void 0 },
															children: profiles[seatMenu.user_id]?.display_name
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "mt-1 flex flex-wrap items-center gap-1 text-[11px] font-black",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "rounded-full border border-amber-200/25 bg-black/25 px-2 py-0.5 text-amber-100",
																children: ["ID ", profiles[seatMenu.user_id]?.display_no]
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "mt-1",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityBadges, {
																level: profiles[seatMenu.user_id]?.level ?? 1,
																vip: profiles[seatMenu.user_id]?.vip_level ?? 0,
																badges: badges[seatMenu.user_id] ?? []
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "mt-1 flex flex-wrap items-center gap-1 text-[10px] font-bold",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: `rounded-full px-2 py-0.5 ${seatMenu.user_id === room.owner_id ? "bg-amber-300/20 text-amber-200" : seatMenu.user_id === uid ? isOwner ? "bg-amber-300/20 text-amber-200" : isMod ? "bg-violet-300/20 text-violet-100" : "bg-white/10 text-white/80" : targetIsModerator ? "bg-violet-300/20 text-violet-100" : "bg-white/10 text-white/75"}`,
																children: seatMenu.user_id === room.owner_id || seatMenu.user_id === uid && isOwner ? "صاحب الغرفة" : seatMenu.user_id === uid ? isMod ? "أدمن الغرفة" : "عضو" : targetIsModerator ? "أدمن الغرفة" : "عضو"
															})
														})
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 grid grid-cols-4 gap-1 rounded-2xl bg-black/15 p-2 text-center text-[10px]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
														className: "block text-sm",
														children: cardStats.followers
													}), "متابعون"] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
														className: "block text-sm",
														children: cardStats.friends
													}), "أصدقاء"] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
														className: "block text-sm",
														children: cardStats.posts
													}), "منشورات"] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
														className: "block text-sm",
														children: cardStats.likes
													}), "معجبون"] })
												]
											}),
											cardRoom && cardRoom.id !== id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "outline",
												className: "mt-2 w-full text-xs",
												onClick: () => nav({
													to: "/room/$id",
													params: { id: cardRoom.id }
												}),
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoorOpen, { className: "h-4 w-4" }),
													" دخول غرفة المستخدم · #",
													cardRoom.room_no
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 grid grid-cols-3 gap-1",
												children: [
													seatMenu.user_id !== uid && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														variant: "outline",
														onClick: () => void toggleFollow(seatMenu.user_id),
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4" }), following ? "متابَع" : "متابعة"]
													}),
													seatMenu.user_id !== uid && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														variant: "outline",
														onClick: () => void openGifts(seatMenu.user_id),
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-4 w-4" }), "هدية"]
													}),
													seatMenu.user_id !== uid && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														variant: "outline",
														onClick: async () => {
															const { data, error } = await supabase.rpc("get_or_create_conversation", { _other: seatMenu.user_id });
															if (error) toast.error(errMsg(error));
															else nav({
																to: "/chat/$id",
																params: { id: data }
															});
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), "رسالة"]
													})
												]
											}),
											isStaff && seatMenu.user_id !== uid && seatMenu.user_id !== room.owner_id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 flex flex-wrap items-center justify-center gap-2 border-t border-white/15 pt-3",
												children: [
													seatMenu.seat_index >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														title: seatMenu.is_muted ? "إلغاء كتم صوت المستخدم" : "كتم صوت المستخدم",
														"aria-label": seatMenu.is_muted ? "إلغاء كتم صوت المستخدم" : "كتم صوت المستخدم",
														className: `grid h-10 w-10 place-items-center rounded-full ${seatMenu.is_muted ? "bg-emerald-500/20 text-emerald-200" : "bg-white/10"}`,
														onClick: () => call("staff_room_member_seat_action", {
															_room: id,
															_user: seatMenu.user_id,
															_action: seatMenu.is_muted ? "unmute" : "mute"
														}),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "h-5 w-5" })
													}),
													seatMenu.seat_index >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														title: "إنزال المستخدم من الميك",
														"aria-label": "إنزال المستخدم من الميك",
														className: "grid h-10 w-10 place-items-center rounded-full bg-white/10 text-orange-200",
														onClick: () => call("staff_room_member_seat_action", {
															_room: id,
															_user: seatMenu.user_id,
															_action: "lower"
														}),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: "h-5 w-5" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														title: "طرد من الغرفة",
														"aria-label": "طرد من الغرفة",
														className: "grid h-10 w-10 place-items-center rounded-full bg-white/10 text-red-300",
														onClick: () => call("staff_kick_room_user", {
															_room: id,
															_user: seatMenu.user_id
														}),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-5 w-5" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														title: chatMutedUser ? "السماح بالكتابة" : "منع الكتابة",
														"aria-label": chatMutedUser ? "السماح بالكتابة" : "منع الكتابة",
														className: `grid h-10 w-10 place-items-center rounded-full ${chatMutedUser ? "bg-emerald-500/20 text-emerald-200" : "bg-white/10"}`,
														onClick: () => call("staff_set_chat_mute", {
															_room: id,
															_user: seatMenu.user_id,
															_muted: !chatMutedUser
														}),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-5 w-5" })
													}),
													isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														title: targetIsModerator ? "إزالة الأدمن" : "تعيين أدمن",
														"aria-label": targetIsModerator ? "إزالة الأدمن" : "تعيين أدمن",
														className: "grid h-10 w-10 place-items-center rounded-full bg-white/10 text-amber-200",
														onClick: () => call("staff_set_room_moderator", {
															_room: id,
															_user: seatMenu.user_id,
															_enabled: !targetIsModerator
														}),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-5 w-5" })
													})
												]
											})
										]
									})]
								}),
								seatMenu.user_id === uid && seatMenu.seat_index >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "outline",
									onClick: () => void call("leave_seat", { _room: id }),
									className: "w-[min(92vw,380px)] border-rose-300/40 bg-black/60 text-rose-100 shadow-xl backdrop-blur-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "ml-2 h-4 w-4" }), "نزول من الميك"]
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
					open: inviteOpen,
					onOpenChange: setInviteOpen,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
						side: "bottom",
						dir: "rtl",
						className: "max-h-[60vh] rounded-t-3xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "دعوة مشاهد للمايك" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-h-[45vh] space-y-2 overflow-y-auto p-3",
							children: [members.filter((memberId) => memberId !== uid && memberId !== room?.owner_id && !seats.some((seat) => seat.user_id === memberId)).map((memberId) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 rounded-xl bg-secondary/60 p-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
										src: profiles[memberId]?.avatar_url,
										name: profiles[memberId]?.display_name || "مستخدم",
										vip: profiles[memberId]?.vip_level,
										size: 42,
										frameKey: profiles[memberId]?.equipped_frame
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 flex-1 truncate text-sm font-semibold",
										children: profiles[memberId]?.display_name || "مستخدم"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: async () => {
											if (seatMenu?.seat_index != null && seatMenu.seat_index >= 0) await call("staff_invite_to_seat", {
												_room: id,
												_seat: seatMenu.seat_index,
												_user: memberId
											});
											else await call("staff_invite_to_mic", {
												_room: id,
												_user: memberId
											});
											setInviteOpen(false);
										},
										children: "دعوة"
									})
								]
							}, memberId)), members.filter((memberId) => memberId !== uid && memberId !== room?.owner_id && !seats.some((seat) => seat.user_id === memberId)).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "py-6 text-center text-sm text-muted-foreground",
								children: "لا يوجد مشاهدون متاحون للدعوة حاليًا"
							})]
						})]
					})
				}),
				exitPrompt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 z-[120] flex items-center justify-center bg-black/60 p-5",
					dir: "rtl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full max-w-sm space-y-3 rounded-2xl border border-primary/30 bg-background p-5 shadow-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-center text-lg font-bold",
								children: "ماذا تريد أن تفعل؟"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full",
								onClick: () => {
									localStorage.setItem("vox_minimized_room", JSON.stringify({
										id,
										name: room.name,
										category: room.category,
										cover_url: room.cover_url
									}));
									localStorage.setItem("vox_active_room", JSON.stringify({
										id,
										name: room.name,
										cover: room.cover_url,
										micEnabled: myMicEnabled && micPermissionGranted
									}));
									localStorage.setItem("vox_minimized_room_id", id);
									window.dispatchEvent(new Event("vox-room-minimized"));
									setExitPrompt(false);
									setRoomMinimized(true);
								},
								children: "تصغير الغرفة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "destructive",
								className: "w-full",
								disabled: isLeavingRoom,
								onClick: async () => {
									setIsLeavingRoom(true);
									localStorage.removeItem("vox_minimized_room");
									localStorage.removeItem("vox_active_room");
									localStorage.removeItem("vox_minimized_room_id");
									window.dispatchEvent(new Event("vox-room-closed"));
									setExitPrompt(false);
									const { error: seatError } = await supabase.rpc("leave_seat", { _room: id });
									if (seatError) console.warn("[room exit] leave_seat:", seatError.message);
									const { error } = await supabase.rpc("leave_room", { _room: id });
									if (error) {
										setIsLeavingRoom(false);
										toast.error(errMsg(error));
										return;
									}
									nav({ to: "/" });
								},
								children: "إغلاق الغرفة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								className: "w-full",
								onClick: () => setExitPrompt(false),
								children: "إلغاء"
							})
						]
					})
				}),
				entryAnim && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `@keyframes entry-zoom{0%{opacity:0;transform:scale(.35)}70%{opacity:1;transform:scale(1.04)}100%{transform:scale(1)}}@keyframes entry-slide{0%{opacity:0;transform:translateX(80vw)}100%{opacity:1;transform:translateX(0)}}@keyframes entry-float{0%{opacity:0;transform:translateY(45px)}100%{opacity:1;transform:translateY(0)}}@keyframes entry-pulse{0%{opacity:0;transform:scale(.7)}60%{opacity:1;transform:scale(1.08)}100%{transform:scale(1)}}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "status",
					"aria-live": "polite",
					className: "pointer-events-auto fixed inset-0 z-[75] flex items-center justify-center overflow-hidden bg-black/95",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setEntryAnim(null),
						className: "absolute right-4 top-4 z-[90] rounded-full border border-white/30 bg-black/75 px-4 py-2 text-xs font-bold text-white",
						children: "إغلاق"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-full w-full items-center justify-center overflow-hidden",
						children: isVideoAsset(entryAnim.src) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
							src: entryAnim.src,
							autoPlay: true,
							controls: false,
							disablePictureInPicture: true,
							disableRemotePlayback: true,
							controlsList: "nodownload noplaybackrate noremoteplayback",
							muted: !entryAnim.audioEnabled,
							playsInline: true,
							preload: "auto",
							onLoadedMetadata: (e) => {
								e.currentTarget.playbackRate = entryAnim.playbackSpeed;
								e.currentTarget.volume = entryAnim.audioEnabled ? 1 : 0;
								e.currentTarget.play().catch(() => {});
							},
							onCanPlay: (e) => {
								if (entryAnim.audioEnabled) e.currentTarget.play().catch(() => {});
							},
							onEnded: () => setEntryAnim((current) => current?.key === entryAnim.key ? null : current),
							onError: () => setEntryAnim((current) => current?.key === entryAnim.key ? null : current),
							style: { animation: entryAnim.animationStyle === "none" ? "none" : `entry-${[
								"slide",
								"float",
								"pulse"
							].includes(entryAnim.animationStyle) ? entryAnim.animationStyle : "zoom"} ${Math.max(250, 900 / entryAnim.animationSpeed)}ms ease-out both` },
							className: "admin-asset-video block h-auto w-auto max-h-[100dvh] max-w-[100vw] object-contain"
						}, entryAnim.key) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: entryAnim.src,
							alt: "دخولية المستخدم",
							onError: () => setEntryAnim((current) => current?.key === entryAnim.key ? null : current),
							style: { animation: entryAnim.animationStyle === "none" ? "none" : `entry-${[
								"slide",
								"float",
								"pulse"
							].includes(entryAnim.animationStyle) ? entryAnim.animationStyle : "zoom"} ${Math.max(250, 900 / entryAnim.animationSpeed)}ms ease-out both` },
							className: "block h-auto w-auto max-h-[100dvh] max-w-[100vw] object-contain"
						})
					})]
				}, entryAnim.key)] }),
				anim && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `.admin-asset-video::-webkit-media-controls,.admin-asset-video::-webkit-media-controls-panel,.admin-asset-video::-webkit-media-controls-start-playback-button{display:none!important;opacity:0!important}@keyframes gift-zoom{0%{opacity:0;transform:scale(.35)}70%{opacity:1;transform:scale(1.06)}100%{transform:scale(1)}}@keyframes gift-slide{0%{opacity:0;transform:translateX(90vw) scale(.8)}100%{opacity:1;transform:translateX(0) scale(1)}}@keyframes gift-float{0%{opacity:0;transform:translateY(55px) scale(.8)}55%{opacity:1;transform:translateY(-12px) scale(1.04)}100%{transform:translateY(0) scale(1)}}@keyframes gift-pulse{0%{opacity:0;transform:scale(.65)}55%{opacity:1;transform:scale(1.12)}100%{transform:scale(1)}}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "presentation",
					className: `pointer-events-auto fixed inset-0 z-[80] flex items-center justify-center px-5 ${anim.mode === "animated" ? "bg-black/35" : "bg-black/15"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setAnim(null),
						className: "absolute right-4 top-4 z-[90] rounded-full border border-white/25 bg-black/70 px-4 py-2 text-xs font-bold text-white",
						children: "إغلاق الهدية"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative flex max-h-[82vh] max-w-[92vw] items-center justify-center rounded-none border-0 bg-transparent p-0 shadow-none",
						style: {
							animation: anim.mode === "static" || anim.style === "none" ? "none" : `${anim.style === "slide" ? "gift-slide" : anim.style === "float" ? "gift-float" : anim.style === "pulse" ? "gift-pulse" : "gift-zoom"} ${Math.max(250, 900 / anim.speed)}ms ease-out both`,
							width: anim.width ? `${anim.width}px` : void 0,
							height: anim.height ? `${anim.height}px` : void 0
						},
						children: isVideoAsset(anim.emoji) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
							src: anim.emoji,
							autoPlay: true,
							controls: false,
							disablePictureInPicture: true,
							disableRemotePlayback: true,
							controlsList: "nodownload noplaybackrate noremoteplayback",
							muted: !anim.audioEnabled,
							playsInline: true,
							preload: "auto",
							volume: anim.audioEnabled ? 1 : 0,
							onLoadedMetadata: (e) => {
								e.currentTarget.playbackRate = anim.playbackSpeed;
								e.currentTarget.volume = anim.audioEnabled ? 1 : 0;
								e.currentTarget.play().catch(() => {});
							},
							onCanPlay: (e) => {
								if (anim.audioEnabled) e.currentTarget.play().catch(() => {});
							},
							onEnded: () => setAnim((current) => current?.key === anim.key ? null : current),
							onError: () => setAnim((current) => current?.key === anim.key ? null : current),
							className: "admin-asset-video max-h-[72vh] max-w-[88vw] object-contain drop-shadow-2xl"
						}, anim.key) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: anim.emoji,
							alt: "",
							"aria-hidden": "true",
							className: "max-h-[72vh] max-w-[88vw] object-contain drop-shadow-2xl"
						})
					})]
				}, anim.key)] }),
				gift99Banner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none fixed left-1/2 top-20 z-[141] -translate-x-1/2 rounded-full border border-white/20 bg-black/75 px-4 py-2 text-white shadow-[0_10px_35px_rgba(0,0,0,.55)] backdrop-blur-xl animate-in slide-in-from-top-4",
					style: { width: "min(94vw, 460px)" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-center gap-3 text-xs font-bold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "max-w-[100px] truncate text-right",
								children: gift99Banner.senderName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-white/50",
								children: "أرسل"
							}),
							gift99Banner.assetUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
								src: gift99Banner.assetUrl,
								alt: gift99Banner.giftName,
								muted: true,
								className: "shrink-0 object-contain drop-shadow-lg",
								style: {
									width: 48,
									height: 48
								}
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-2xl",
								children: "🎁"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "max-w-[90px] truncate text-amber-200",
								children: gift99Banner.giftName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full border border-amber-300/40 bg-amber-300/15 px-2 py-1 text-[10px] font-black text-amber-100",
								children: ["×", gift99Banner.quantity]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-white/50",
								children: "إلى"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "max-w-[100px] truncate",
								children: gift99Banner.receiverName
							})
						]
					})
				}, gift99Banner.id),
				luckyRewardBanner && luckyBarConfig.enabled && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `pointer-events-none fixed left-1/2 z-[140] -translate-x-1/2 flex items-center justify-center rounded-full border border-amber-300/70 bg-gradient-to-r from-[#101827] via-[#27334c] to-[#6b4a12] px-4 py-2 text-white shadow-[0_10px_28px_rgba(0,0,0,.55)] ring-1 ring-amber-200/30 animate-in slide-in-from-top-4 ${luckyBarConfig.position === "bottom" ? "bottom-24" : luckyBarConfig.position === "center" ? "top-1/2 -translate-y-1/2" : "top-20"}`,
					style: { width: `min(92vw, ${luckyBarConfig.width_px}px)` },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex w-full items-center justify-center gap-2 text-xs font-black",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1 text-amber-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-block animate-bounce text-lg",
									children: "🪙"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-block animate-pulse",
									children: "🪙"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-amber-100",
								children: "مردود"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums text-white",
								children: [luckyRewardBanner.reward.toLocaleString(), " عملة"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full border border-amber-200/50 bg-black/25 px-2.5 py-1 text-[11px] font-black text-emerald-300",
								children: [new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(luckyRewardBanner.percent), "%"]
							})
						]
					})
				}, luckyRewardBanner.id),
				repeatGift && !giftOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void sendAgain(),
					className: "fixed bottom-24 left-4 z-[135] flex items-center gap-2 rounded-full border border-amber-300/80 bg-gradient-to-r from-[#221332] to-[#805018] px-4 py-3 text-sm font-black text-amber-50 shadow-[0_10px_30px_rgba(0,0,0,.55)] ring-1 ring-amber-100/30",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-5 w-5" }),
						"إرسال متتالي ×",
						repeatGift.qty
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
					open: giftOpen,
					onOpenChange: setGiftOpen,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
						side: "bottom",
						dir: "rtl",
						className: "max-h-[80vh] overflow-y-auto rounded-t-3xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الهدايا" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-primary",
								children: ["🪙 ", coins]
							})]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "w-full rounded-md border border-input bg-input px-3 py-2 text-sm",
									value: giftTo ?? "",
									onChange: (e) => setGiftTo(e.target.value),
									children: [members.filter((m) => m !== uid).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "لا يوجد أحد غيرك في الغرفة"
									}), members.filter((m) => m !== uid).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: m,
										children: ["إلى: ", publicName(m)]
									}, m))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2 overflow-x-auto pb-2",
									dir: "rtl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: giftTab === "normal" ? "default" : "outline",
										className: "shrink-0 rounded-full",
										onClick: () => setGiftTab("normal"),
										children: "الهدايا العادية"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: giftTab === "lucky" ? "default" : "outline",
										className: "shrink-0 rounded-full",
										onClick: () => setGiftTab("lucky"),
										children: "هدايا الحظ"
									})]
								}),
								giftTab === "normal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex snap-x snap-mandatory gap-2 overflow-x-auto pb-2",
									dir: "rtl",
									style: { scrollbarWidth: "none" },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: giftCategory === "all" ? "default" : "outline",
										className: "shrink-0 snap-start rounded-full",
										onClick: () => setGiftCategory("all"),
										children: "الكل"
									}), giftCategories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										size: "sm",
										variant: giftCategory === category.id ? "default" : "outline",
										className: "shrink-0 snap-start rounded-full",
										onClick: () => setGiftCategory(category.id),
										children: [category.name, category.display_mode === "animated" ? " ✨" : " ·"]
									}, category.id))]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex snap-x snap-mandatory gap-3 overflow-x-auto pb-3",
									dir: "rtl",
									style: { scrollbarWidth: "none" },
									children: visibleGifts.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										onClick: () => setGiftSel(g),
										className: `h-auto w-28 shrink-0 snap-start flex-col gap-1 rounded-xl p-2 ${giftSel?.id === g.id ? "bg-secondary ring-2 ring-primary" : "glass"}`,
										children: [
											g.asset_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
												src: g.asset_url,
												alt: g.name,
												muted: true,
												className: "h-16 w-16 object-contain"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "grid h-16 w-16 place-items-center rounded-xl bg-secondary text-muted-foreground",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-7 w-7" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs",
												children: g.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs text-primary",
												children: ["🪙", g.price]
											})
										]
									}, g.id))
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-3 gap-2",
									children: luckyGifts.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										onClick: () => {
											setLuckySel(g);
											setGiftSel(null);
										},
										className: `h-auto flex-col gap-1 rounded-xl p-2 ${luckySel?.id === g.id ? "bg-secondary ring-2 ring-gold" : "glass"}`,
										children: [
											g.asset_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
												src: g.asset_url,
												alt: g.name,
												muted: true,
												className: "h-14 w-14 object-contain"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-14 w-14 rounded-xl bg-secondary grid place-items-center text-2xl",
												children: "🎲"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-bold",
												children: g.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "rounded-full border border-amber-300/40 bg-amber-400/10 px-2 py-1 text-[10px] font-black text-amber-200",
												children: [
													"🎲 هدية حظ · فرصة الفوز ",
													Number(g.win_chance).toLocaleString(),
													"%"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-gold",
												children: ["🪙 ", Number(g.price).toLocaleString()]
											})
										]
									}, g.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [[
										1,
										10,
										99
									].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: "ghost",
										size: "sm",
										onClick: () => setQty(n),
										className: `rounded-full ${qty === n ? "bg-gold" : "glass"}`,
										children: ["x", n]
									}, n)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										disabled: !giftSel && !luckySel || !giftTo,
										onClick: luckySel ? sendLuckyGift : sendGift,
										className: "mr-auto bg-gold font-bold",
										children: luckySel ? `إرسال حظ (${luckySel.price * qty})` : `إرسال ${giftSel ? `(${giftSel.price * qty})` : ""}`
									})]
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
					open: showMembers,
					onOpenChange: setShowMembers,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
						side: "bottom",
						dir: "rtl",
						className: "max-h-[70vh] overflow-y-auto rounded-t-3xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, { children: [
							"الموجودون (",
							members.length,
							")"
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2 p-4",
							children: members.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between rounded-xl bg-secondary/50 p-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
										src: profiles[m]?.avatar_url,
										name: publicName(m),
										vip: profiles[m]?.vip_level,
										size: 44,
										frameKey: profiles[m]?.equipped_frame
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: publicName(m) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] text-muted-foreground",
										children: ["ID ", profiles[m]?.display_no ?? "—"]
									})] })]
								}), isStaff && m !== uid && m !== room.owner_id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap justify-end gap-1",
									children: [!seats.some((seat) => seat.user_id === m) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: async () => {
											const { error } = await supabase.rpc("staff_invite_to_mic", {
												_room: id,
												_user: m
											});
											if (error) toast.error(errMsg(error));
											else {
												await syncRoomSeats();
												toast.success("تمت دعوة المستخدم وصعوده للمايك");
												setShowMembers(false);
											}
										},
										children: "دعوة للمايك"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => {
											setShowMembers(false);
											onSeat(seats.find((seat) => seat.user_id === m) || {
												seat_index: -1,
												user_id: m,
												is_locked: false,
												is_muted: false
											});
										},
										children: "إدارة"
									})]
								})]
							}, m))
						})]
					})
				}),
				activeGame && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setGamesOpen(true),
					className: "fixed bottom-28 left-3 z-40 flex items-center gap-2 rounded-full border border-amber-300/50 bg-gradient-to-r from-amber-500 to-orange-600 px-3 py-2 text-xs font-bold text-white shadow-2xl",
					dir: "rtl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-lg",
							children: activeGame.emoji
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-w-[80px] truncate",
							children: activeGame.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3 w-3 animate-pulse" })
					]
				}),
				!activeGame && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setGamesOpen(true),
					className: "fixed bottom-28 left-3 z-40 flex flex-col items-center gap-1 rounded-2xl border border-white/20 bg-black/50 px-3 py-2 text-white shadow-xl backdrop-blur-md",
					dir: "rtl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dices, { className: "h-6 w-6 text-amber-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-bold",
						children: "ألعاب"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
					open: gamesOpen,
					onOpenChange: setGamesOpen,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
						side: "bottom",
						dir: "rtl",
						className: "max-h-[80vh] overflow-y-auto rounded-t-3xl bg-gradient-to-b from-[#1a1a2e] to-[#16213e]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
							className: "flex items-center gap-2 text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gamepad2, { className: "h-5 w-5 text-amber-400" }), " مركز الألعاب"]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-3 rounded-2xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 p-3 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-amber-200",
										children: "🎮 العب واستمتع مع الأصدقاء في الغرفة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-white/60",
										children: "اختر لعبة وابدأ التحدي الآن"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-5 gap-3",
									children: [
										{
											name: "الأسد الطماع",
											emoji: "🦁"
										},
										{
											name: "صندوق الحظ",
											emoji: "🎁"
										},
										{
											name: "الدولاب",
											emoji: "🎰"
										},
										{
											name: "حجر ورقة",
											emoji: "✊"
										},
										{
											name: "روليت",
											emoji: "🎡"
										},
										{
											name: "البوكر",
											emoji: "🃏"
										},
										{
											name: "الشطرنج",
											emoji: "♟️"
										},
										{
											name: "الدومينو",
											emoji: "🁫"
										},
										{
											name: "الطايرة",
											emoji: "✈️"
										},
										{
											name: "الألغاز",
											emoji: "🧩"
										},
										{
											name: "سهم النار",
											emoji: "🏹"
										},
										{
											name: "السباق",
											emoji: "🏎️"
										},
										{
											name: "كرة القدم",
											emoji: "⚽"
										},
										{
											name: "كرة السلة",
											emoji: "🏀"
										},
										{
											name: "التنس",
											emoji: "🎾"
										},
										{
											name: "المنجل",
											emoji: "⚔️"
										},
										{
											name: "التنين",
											emoji: "🐉"
										},
										{
											name: "كنز البحر",
											emoji: "🏴‍☠️"
										},
										{
											name: "الفاكهة",
											emoji: "🍉"
										},
										{
											name: "الماس",
											emoji: "💎"
										},
										{
											name: "النجمة",
											emoji: "⭐"
										},
										{
											name: "القلب",
											emoji: "❤️"
										},
										{
											name: "التاج",
											emoji: "👑"
										},
										{
											name: "الوردة",
											emoji: "🌹"
										},
										{
											name: "العسل",
											emoji: "🍯"
										}
									].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setActiveGame(g);
											setGamesOpen(false);
											toast.success(`تم تشغيل ${g.name}`);
										},
										className: `flex flex-col items-center gap-1 rounded-2xl p-2 transition-all hover:scale-105 ${activeGame?.name === g.name ? "bg-amber-500/30 ring-2 ring-amber-400" : "bg-white/5 hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-3xl",
											children: g.emoji
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "max-w-[56px] truncate text-[10px] font-bold text-white/80",
											children: g.name
										})]
									}, g.name))
								}),
								activeGame && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									className: "mt-4 w-full border-rose-400/30 text-rose-200",
									onClick: () => {
										setActiveGame(null);
										toast.info("تم إغلاق اللعبة");
									},
									children: "إغلاق اللعبة الحالية"
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
					open: micControlsOpen,
					onOpenChange: setMicControlsOpen,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
						side: "bottom",
						dir: "rtl",
						className: "max-h-[75vh] overflow-y-auto rounded-t-3xl bg-gradient-to-b from-[#1a1a2e] to-[#0f3460]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
							className: "flex items-center gap-2 text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "h-5 w-5 text-emerald-400" }), " التحكم في الميك والغرفة"]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-4 gap-3",
								children: [
									{
										icon: Mic,
										label: "الميك",
										color: "from-emerald-500 to-green-600",
										action: () => {
											if (mySeat) if (mySeat.is_muted) {
												call("toggle_my_mute", { _room: id });
												toast.success("تم فتح الميك");
											} else {
												call("toggle_my_mute", { _room: id });
												toast.success("تم كتم الميك");
											}
											else toast.error("يجب أن تجلس على مقعد أولاً");
										}
									},
									{
										icon: Music2,
										label: "موسيقى",
										color: "from-violet-500 to-purple-600",
										action: () => {
											setMicControlsOpen(false);
											setMusicOpen(true);
										}
									},
									{
										icon: Volume2,
										label: "الصوت",
										color: "from-sky-500 to-blue-600",
										action: () => toast.info("تحكم مستوى الصوت")
									},
									{
										icon: BellOff,
										label: "صامت",
										color: "from-slate-500 to-slate-700",
										action: () => toast.success("تم تفعيل الوضع الصامت")
									},
									{
										icon: Wallet,
										label: "المحفظة",
										color: "from-amber-500 to-yellow-600",
										action: () => {
											setMicControlsOpen(false);
											nav({ to: "/wallet" });
										}
									},
									{
										icon: Heart,
										label: "إعجاب",
										color: "from-rose-500 to-pink-600",
										action: () => toast.success("❤️ تم إرسال إعجاب")
									},
									{
										icon: Bell,
										label: "تنبيه",
										color: "from-yellow-400 to-amber-500",
										action: () => toast.success("🔔 تم إرسال تنبيه")
									},
									{
										icon: Share2,
										label: "مشاركة",
										color: "from-cyan-500 to-teal-600",
										action: () => {
											share();
										}
									},
									{
										icon: Lock,
										label: "قفل",
										color: "from-orange-500 to-red-600",
										action: () => {
											if (isStaff) toast.success("🔒 تم قفل الغرفة");
											else toast.error("فقط صاحب الغرفة يمكنه القفل");
										}
									},
									{
										icon: LockOpen,
										label: "فتح",
										color: "from-green-500 to-emerald-600",
										action: () => {
											if (isStaff) toast.success("🔓 تم فتح الغرفة");
											else toast.error("فقط صاحب الغرفة يمكنه الفتح");
										}
									},
									{
										icon: Settings,
										label: "إعدادات",
										color: "from-gray-500 to-gray-700",
										action: () => {
											if (isOwner) {
												setMicControlsOpen(false);
												setSettingsOpen(true);
											} else toast.error("فقط صاحب الغرفة يمكنه الوصول للإعدادات");
										}
									},
									{
										icon: Sofa,
										label: "المقاعد",
										color: "from-indigo-500 to-blue-600",
										action: () => {
											setMicControlsOpen(false);
											setShowMembers(true);
										}
									}
								].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: item.action,
									className: "flex flex-col items-center gap-1.5 rounded-2xl bg-white/5 p-3 transition-all hover:scale-105 hover:bg-white/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br ${item.color} shadow-lg`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-5 w-5 text-white" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-bold text-white/80",
										children: item.label
									})]
								}, item.label))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 rounded-2xl bg-white/5 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-white/80",
										children: "حالة الميكروفون"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-full px-2 py-0.5 text-[10px] font-black ${mySeat && !mySeat.is_muted && micPermissionGranted ? "bg-emerald-500/30 text-emerald-200" : "bg-rose-500/30 text-rose-200"}`,
										children: mySeat && !mySeat.is_muted && micPermissionGranted ? "مفتوح" : "مكتوم"
									})]
								}), mySeat ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									className: "w-full bg-gradient-to-r from-emerald-500 to-green-600",
									onClick: async () => {
										if (!micPermissionGranted) try {
											if (!navigator.mediaDevices?.getUserMedia) throw new Error("الوصول للميكروفون غير مدعوم");
											(await navigator.mediaDevices.getUserMedia({ audio: true })).getTracks().forEach((track) => track.stop());
											localStorage.setItem("vox_mic_permission_granted", "1");
											setMicPermissionGranted(true);
											if (mySeat.is_muted) await call("toggle_my_mute", { _room: id });
											toast.success("تم منح إذن الميكروفون");
										} catch (error) {
											toast.error("تعذر الوصول إلى الميكروفون");
										}
										else {
											setMicPermissionGranted(false);
											if (!mySeat.is_muted) await call("toggle_my_mute", { _room: id });
											toast.success("تم إيقاف الميكروفون");
										}
									},
									children: [mySeat.is_muted || !micPermissionGranted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, { className: "ml-2 h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "ml-2 h-4 w-4" }), mySeat.is_muted || !micPermissionGranted ? "فتح الميكروفون" : "إيقاف الميكروفون"]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-center text-xs text-white/60",
									children: "يجب أن تجلس على مقعد للتحكم في الميك"
								})]
							})]
						})]
					})
				})
			]
		})
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireAuth, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomPage, {}) });
//#endregion
export { SplitComponent as component };
