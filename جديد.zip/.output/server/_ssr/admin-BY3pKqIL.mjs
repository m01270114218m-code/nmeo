import "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import "../_libs/sonner.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
require_react();
require_jsx_runtime();
var $$splitComponentImporter = () => import("./admin-DZYL49i1.mjs");
var Route = createFileRoute("/admin")({
	validateSearch: (search) => ({ section: typeof search.section === "string" ? search.section : void 0 }),
	head: () => ({ meta: [
		{ title: "لوحة التحكم — صدى شات" },
		{
			name: "description",
			content: "لوحة إدارة صدى شات للبلاغات والغرف والمنشورات والمستخدمين."
		},
		{
			property: "og:title",
			content: "لوحة التحكم — صدى شات"
		},
		{
			property: "og:description",
			content: "إدارة البلاغات والغرف والمنشورات والمستخدمين."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
