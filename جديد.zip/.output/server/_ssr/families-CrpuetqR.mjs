import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { D as Search, U as LogOut, _t as Check, a as Users, d as Trophy, ft as Crown, j as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as PageHeader, t as AppShell } from "./AppShell-CNN_t4M1.mjs";
import { n as UserAvatar } from "./UserAvatar-DvFPapaA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/families-CrpuetqR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Families() {
	const { user } = useAuth();
	const uid = user.id;
	const [list, setList] = (0, import_react.useState)([]);
	const [mine, setMine] = (0, import_react.useState)(null);
	const [members, setMembers] = (0, import_react.useState)([]);
	const [show, setShow] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [desc, setDesc] = (0, import_react.useState)("");
	const [emblem, setEmblem] = (0, import_react.useState)("👑");
	const [query, setQuery] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	async function load() {
		setLoading(true);
		try {
			const [{ data: fs }, { data: m }] = await Promise.all([supabase.from("families").select("*").order("points", { ascending: false }).limit(50), supabase.from("family_members").select("*").eq("user_id", uid).maybeSingle()]);
			setList(fs ?? []);
			setMine(m ?? null);
			if (m && m.status === "active") {
				const { data: ms } = await supabase.from("family_members").select("*").eq("family_id", m.family_id);
				const ids = (ms ?? []).map((x) => x.user_id);
				const { data: ps } = ids.length ? await supabase.from("profiles").select("id,display_name,avatar_url").in("id", ids) : { data: [] };
				setMembers((ms ?? []).map((x) => ({
					...x,
					p: ps.find((p) => p.id === x.user_id)
				})));
			} else setMembers([]);
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load();
		const channel = supabase.channel(`families-list-live-${uid}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "families"
		}, () => {
			load();
		}).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "family_members"
		}, () => {
			load();
		}).subscribe();
		return () => {
			supabase.removeChannel(channel);
		};
	}, []);
	async function run(p, ok) {
		const { error } = await p;
		if (error) toast.error(error.message);
		else {
			toast.success(ok);
			load();
		}
	}
	const myFam = mine && list.find((f) => f.id === mine.family_id);
	const filteredList = list.filter((family) => {
		const term = query.trim().toLocaleLowerCase();
		return !term || family.name.toLocaleLowerCase().includes(term) || (family.description ?? "").toLocaleLowerCase().includes(term);
	});
	const isLeader = myFam && (myFam.owner_id === uid || mine?.role === "owner" || mine?.role === "admin");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "social-list-reference family-list-reference",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "العائلات",
				back: true,
				right: !mine && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setShow(!show),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " إنشاء"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "social-list-toolbar mx-4 mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "social-list-kicker",
						children: "VOX ROYALE · COMMUNITY"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "social-list-title",
						children: "عائلات تجمعنا"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "اكتشف العائلات وتابع ترتيبها ونقاطها"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "social-list-search",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "ابحث عن عائلة...",
						"aria-label": "ابحث عن عائلة"
					})]
				})]
			}),
			show && !mine && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass card-3d mx-4 mb-4 space-y-2 rounded-3xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "w-16 text-center text-2xl",
							value: emblem,
							maxLength: 2,
							onChange: (e) => setEmblem(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "اسم العائلة",
							value: name,
							maxLength: 30,
							onChange: (e) => setName(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "وصف قصير",
						value: desc,
						maxLength: 120,
						onChange: (e) => setDesc(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: name.trim().length < 2,
						onClick: () => run(supabase.rpc("create_family", {
							_name: name.trim(),
							_description: desc,
							_emblem: emblem || "👑"
						}), "تم إنشاء العائلة"),
						children: "إنشاء العائلة"
					})
				]
			}),
			myFam && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "social-feature-card glass card-3d mx-4 mb-4 rounded-3xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-gold flex h-16 w-16 items-center justify-center rounded-2xl text-3xl shadow-gold",
								children: myFam.emblem
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-display text-gold text-xl",
										children: myFam.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground",
										children: [
											myFam.member_count,
											" عضو · ",
											myFam.points,
											" نقطة"
										]
									}),
									mine?.status !== "active" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-primary",
										children: "طلبك قيد المراجعة"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => run(supabase.rpc("leave_family"), "غادرت العائلة"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" })
							})
						]
					}),
					myFam.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: myFam.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 space-y-2",
						children: members.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
									src: m.p?.avatar_url,
									name: m.p?.display_name,
									size: 36
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex-1 text-sm",
									children: [
										m.p?.display_name ?? "…",
										" ",
										m.role === "owner" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "inline h-4 w-4 text-primary" })
									]
								}),
								m.status === "pending" && isLeader ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									onClick: () => run(supabase.rpc("family_decide", {
										_family: myFam.id,
										_user: m.user_id,
										_accept: true
									}), "تم القبول"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									onClick: () => run(supabase.rpc("family_decide", {
										_family: myFam.id,
										_user: m.user_id,
										_accept: false
									}), "تم الرفض"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
								})] }) : m.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: "بانتظار"
								}) : null
							]
						}, m.user_id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-black text-amber-100",
					children: "ترتيب العائلات"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[11px] text-muted-foreground",
					children: [filteredList.length, " عائلة"]
				})]
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-8 text-center text-sm text-muted-foreground",
				children: "جارٍ تحميل العائلات..."
			}) : filteredList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "social-empty mx-4 py-8 text-center text-sm text-muted-foreground",
				children: query.trim() ? "لا توجد نتائج مطابقة للبحث" : "لا توجد عائلات بعد. كن أول من ينشئ عائلة."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 px-4",
				children: filteredList.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "social-family-row glass card-3d flex items-center gap-3 rounded-2xl p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "social-family-rank",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "h-3.5 w-3.5" }), list.findIndex((item) => item.id === f.id) + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-2xl",
							children: f.emblem
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate font-bold",
								children: f.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "inline h-3 w-3" }),
									" ",
									f.member_count,
									" · ",
									f.points,
									" نقطة"
								]
							})]
						}),
						!mine && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => run(supabase.rpc("request_join_family", { _family: f.id }), "أُرسل طلب الانضمام"),
							children: "انضمام"
						})
					]
				}, f.id))
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Families, {}) });
//#endregion
export { SplitComponent as component };
