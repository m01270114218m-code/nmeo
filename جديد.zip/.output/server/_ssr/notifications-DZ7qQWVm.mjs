import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { n as PageHeader, t as AppShell } from "./AppShell-CNN_t4M1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-DZ7qQWVm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICON = {
	like: "❤️",
	comment: "💬",
	follow: "➕",
	gift: "🎁",
	family: "🛡️",
	system: "📢"
};
function Notifs() {
	const [items, setItems] = (0, import_react.useState)([]);
	async function load() {
		const { data } = await supabase.from("notifications").select("id,kind,title,body,is_read,created_at").order("created_at", { ascending: false }).limit(100);
		setItems(data ?? []);
	}
	(0, import_react.useEffect)(() => {
		load().then(() => supabase.from("notifications").update({ is_read: true }).eq("is_read", false));
	}, []);
	async function clear() {
		const ids = items.map((i) => i.id);
		if (ids.length) await supabase.from("notifications").delete().in("id", ids);
		setItems([]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "الإشعارات",
		back: true,
		right: items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "outline",
			onClick: clear,
			children: "مسح الكل"
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass rounded-2xl p-3 text-sm",
				children: [
					"📢 ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "رسالة النظام" }),
					" — شكراً لاختيارك صدى شات! يُمنع المحتوى المسيء أو غير اللائق، وأي مخالفة تعرّض الحساب للحظر."
				]
			}),
			items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-muted-foreground",
				children: "لا توجد إشعارات"
			}),
			items.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `glass flex gap-3 rounded-2xl p-3 ${n.is_read ? "" : "ring-1 ring-primary"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-2xl",
					children: ICON[n.kind] ?? "🔔"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold",
							children: n.title
						}),
						n.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-muted-foreground",
							children: n.body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] text-muted-foreground",
							children: new Date(n.created_at).toLocaleString("ar-EG")
						})
					]
				})]
			}, n.id))
		]
	})] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notifs, {}) });
//#endregion
export { SplitComponent as component };
