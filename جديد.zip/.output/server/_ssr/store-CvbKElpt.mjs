import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as getAdminAssetUrl } from "./media-BXNEENvw.mjs";
import { a as errMsg } from "./vox-CkkqXMfh.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { gt as ChevronLeft, h as Star, pt as Clock, t as X, x as ShoppingBag } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-CNN_t4M1.mjs";
import { t as AdminAssetMedia } from "./AdminAssetMedia-CBSs12zp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-CvbKElpt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PACKS = [
	{
		coins: 6e3,
		price: "$0.99"
	},
	{
		coins: 32e3,
		price: "$4.99"
	},
	{
		coins: 68e3,
		price: "$9.99"
	},
	{
		coins: 35e4,
		price: "$49.99"
	}
];
var TABS = [
	{
		id: "vehicle",
		label: "مركبات الدخول"
	},
	{
		id: "frame",
		label: "إطار الصورة"
	},
	{
		id: "bubble",
		label: "فقاعة الدردشة"
	},
	{
		id: "entry",
		label: "تأثيرات المدخل"
	},
	{
		id: "badge",
		label: "الاوسمة"
	},
	{
		id: "profile_card",
		label: "بطاقة التعريف"
	},
	{
		id: "sound_wave",
		label: "موجات الصوت"
	}
];
function StorePage() {
	const { user } = useAuth();
	const nav = useNavigate();
	const [items, setItems] = (0, import_react.useState)([]);
	const [owned, setOwned] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [equippedFrame, setEquippedFrame] = (0, import_react.useState)(null);
	const [equippedEntry, setEquippedEntry] = (0, import_react.useState)(null);
	const [equippedBubble, setEquippedBubble] = (0, import_react.useState)(null);
	const [equippedWave, setEquippedWave] = (0, import_react.useState)(null);
	const [equippedCard, setEquippedCard] = (0, import_react.useState)(null);
	const [activeTab, setActiveTab] = (0, import_react.useState)("frame");
	(0, import_react.useEffect)(() => {
		if (!user) return;
		const live = supabase.channel(`store-live-${user.id}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "user_items",
			filter: `user_id=eq.${user.id}`
		}, async () => {
			const { data: ui } = await supabase.from("user_items").select("item_id,expires_at").eq("user_id", user.id);
			const now = Date.now();
			setOwned(new Set((ui ?? []).filter((r) => !r.expires_at || new Date(r.expires_at).getTime() > now).map((r) => r.item_id)));
		}).subscribe();
		(async () => {
			const [{ data: p }, { data: si }, { data: ui }] = await Promise.all([
				supabase.from("profiles").select("equipped_frame, equipped_entry, chat_bubble_asset_key, sound_wave_asset_key, profile_card_asset_key").eq("id", user.id).single(),
				supabase.from("store_items").select("*").eq("is_direct_grant", false).order("sort_order"),
				supabase.from("user_items").select("item_id,expires_at").eq("user_id", user.id)
			]);
			const now = Date.now();
			const activeOwned = (ui ?? []).filter((r) => !r.expires_at || new Date(r.expires_at).getTime() > now);
			setOwned(new Set(activeOwned.map((r) => r.item_id)));
			setEquippedFrame(p?.equipped_frame ?? null);
			setEquippedEntry(p?.equipped_entry ?? null);
			setEquippedBubble(p?.chat_bubble_asset_key ?? null);
			setEquippedWave(p?.sound_wave_asset_key ?? null);
			setEquippedCard(p?.profile_card_asset_key ?? null);
			const activeItems = (si ?? []).filter((item) => !item.expires_at || new Date(item.expires_at).getTime() > now);
			const enrichedItems = await Promise.all(activeItems.map(async (item) => ({
				...item,
				asset_url: await getAdminAssetUrl(item.asset_key)
			})));
			setItems(enrichedItems);
			setOwned(new Set(activeOwned.map((r) => r.item_id)));
		})();
		return () => {
			supabase.removeChannel(live);
		};
	}, [user]);
	async function buyItem(item) {
		const { data, error } = await supabase.rpc("buy_item", { _item_id: item.id });
		if (error) {
			toast.error(error.message.includes("insufficient") ? "رصيد العملات غير كافٍ" : error.message.includes("already") ? "تملكه بالفعل" : errMsg(error));
			return;
		}
		setOwned((s) => new Set(s).add(item.id));
		toast.success(`اشتريت ${item.name}! 🎉`);
	}
	async function equip(item, on) {
		const { error } = await supabase.rpc("equip_item", {
			_item_id: item.id,
			_equip: on
		});
		if (error) {
			toast.error(errMsg(error));
			return;
		}
		if (item.kind === "frame") setEquippedFrame(on ? item.asset_key : null);
		if (item.kind === "entry") setEquippedEntry(on ? item.asset_key : null);
		if (item.kind === "bubble") setEquippedBubble(on ? item.asset_key : null);
		if (item.kind === "sound_wave") setEquippedWave(on ? item.asset_key : null);
		if (item.kind === "profile_card") setEquippedCard(on ? item.asset_key : null);
		toast.success(on ? `تم تجهيز ${item.name}` : "تمت الإزالة");
	}
	const tabItems = items.filter((i) => i.kind === activeTab);
	const featured = tabItems[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "store-reference min-h-screen pb-8",
		style: { background: "#f0fdf4" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center justify-between bg-white px-4 py-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => nav({ to: "/profile" }),
						className: "rounded-full p-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-7 w-7 text-gray-700" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-bold text-gray-900",
						children: "متجر الادوات"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => nav({ to: "/" }),
						className: "rounded-full p-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-7 w-7 text-gray-700" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto border-b border-gray-200 bg-white px-2",
				children: TABS.map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setActiveTab(tab.id),
					className: `whitespace-nowrap px-4 py-3 text-sm font-bold ${activeTab === tab.id ? "border-b-2 border-emerald-500 text-emerald-600" : "text-gray-500"}`,
					children: tab.label
				}, tab.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-3 mt-3 overflow-hidden rounded-2xl",
				style: { background: "linear-gradient(135deg, #4ade80, #22d3ee)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex h-40 items-center justify-center",
					children: [featured?.asset_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
						src: featured.asset_url,
						alt: featured.name,
						className: "h-28 w-28 object-contain"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-28 w-28 items-center justify-center rounded-full bg-white/30 text-4xl",
						children: "🎁"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/bag",
						className: "absolute left-3 top-3 flex items-center gap-1 rounded-full bg-emerald-600 px-4 py-2 text-sm font-bold text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "h-4 w-4" }), " حقيبة"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mt-4 grid grid-cols-2 gap-3",
				children: [tabItems.map((item) => {
					const isOwned = owned.has(item.id);
					const isEquipped = item.kind === "frame" && equippedFrame === item.asset_key || item.kind === "entry" && equippedEntry === item.asset_key || item.kind === "bubble" && equippedBubble === item.asset_key || item.kind === "sound_wave" && equippedWave === item.asset_key || item.kind === "profile_card" && equippedCard === item.asset_key;
					const days = item.duration_hours ? Math.ceil(item.duration_hours / 24) : 7;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-2xl bg-white p-3 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1 text-xs text-gray-400",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }),
										" ",
										days,
										" أيام"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold text-emerald-600",
									children: item.name
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-28 items-center justify-center",
								children: item.asset_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAssetMedia, {
									src: item.asset_url,
									alt: item.name,
									className: "h-full w-full object-contain"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-full w-full items-center justify-center text-3xl",
									children: "🎁"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center justify-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
									className: "h-5 w-5 text-yellow-500",
									fill: "currentColor"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg font-bold text-gray-900",
									children: item.price.toLocaleString()
								})]
							}),
							isOwned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => equip(item, !isEquipped),
								className: `mt-2 w-full rounded-xl py-2 text-sm font-bold text-white ${isEquipped ? "bg-gray-400" : "bg-emerald-500"}`,
								children: isEquipped ? "قيد الارتداء" : "ارتداء"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => buyItem(item),
								className: "mt-2 w-full rounded-xl bg-emerald-500 py-2 text-sm font-bold text-white",
								children: "شراء"
							})
						]
					}, item.id);
				}), tabItems.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-2 rounded-2xl bg-white p-8 text-center text-gray-400",
					children: "لا توجد عناصر في هذا القسم"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-lg font-bold text-gray-900",
					children: "شحن العملات"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3",
					children: PACKS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-white p-4 text-center shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-yellow-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
									className: "h-10 w-10 text-yellow-500",
									fill: "currentColor"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "text-lg text-gray-900",
								children: p.coins.toLocaleString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm text-gray-500",
								children: p.price
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: async () => {
									const { error } = await supabase.rpc("request_wallet_topup", {
										_coins: p.coins,
										_payment_method: "manual"
									});
									if (error) toast.error(errMsg(error));
									else toast.success("تم إرسال طلب الشحن للإدارة");
								},
								className: "mt-2 w-full rounded-xl bg-emerald-500 py-2 text-sm font-bold text-white",
								children: "شراء"
							})
						]
					}, p.coins))
				})]
			})
		]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StorePage, {}) });
//#endregion
export { SplitComponent as component };
