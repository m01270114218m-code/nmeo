import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { t as require_AgoraRTC_N_production } from "../_libs/agora-rtc-sdk-ng.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as App } from "../_libs/capacitor__app+capacitor__core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RoomVoice-3nPer991.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_AgoraRTC_N_production = /* @__PURE__ */ __toESM(require_AgoraRTC_N_production());
function numericRtcUid(userId) {
	let hash = 2166136261;
	for (let i = 0; i < userId.length; i++) {
		hash ^= userId.charCodeAt(i);
		hash = Math.imul(hash, 16777619);
	}
	return hash >>> 1 || 1;
}
var rtcLifecycle = /* @__PURE__ */ new Map();
function RoomVoice({ roomId, uid, members, micEnabled, musicFile = null, musicCommand = null, onMusicProgress, onSpeakingUsers }) {
	const clientRef = (0, import_react.useRef)(null);
	const micRef = (0, import_react.useRef)(null);
	const musicRef = (0, import_react.useRef)(null);
	const joinedRef = (0, import_react.useRef)(false);
	const publishedRef = (0, import_react.useRef)(false);
	const aliveRef = (0, import_react.useRef)(true);
	const roleRef = (0, import_react.useRef)("audience");
	const operationRef = (0, import_react.useRef)(Promise.resolve());
	const tokenRefreshRef = (0, import_react.useRef)(null);
	const micEnabledRef = (0, import_react.useRef)(micEnabled);
	const musicFileRef = (0, import_react.useRef)(musicFile);
	micEnabledRef.current = micEnabled;
	musicFileRef.current = musicFile;
	const membersRef = (0, import_react.useRef)(members);
	membersRef.current = members;
	const onSpeakingUsersRef = (0, import_react.useRef)(onSpeakingUsers);
	onSpeakingUsersRef.current = onSpeakingUsers;
	const onMusicProgressRef = (0, import_react.useRef)(onMusicProgress);
	onMusicProgressRef.current = onMusicProgress;
	(0, import_react.useEffect)(() => {
		aliveRef.current = true;
		let effectAlive = true;
		let client = null;
		const lifecycleKey = roomId + ":" + uid;
		const previousLifecycle = rtcLifecycle.get(lifecycleKey) ?? Promise.resolve();
		let releaseLifecycle;
		const currentLifecycle = new Promise((resolve) => {
			releaseLifecycle = resolve;
		});
		rtcLifecycle.set(lifecycleKey, currentLifecycle);
		const getToken = async () => {
			const { data, error } = await supabase.functions.invoke("agora-rtc-token", { body: { roomId } });
			if (error) throw error;
			if (!data?.token || !data?.appId || !data?.channel || !data?.uid) throw new Error(data?.error || "تعذر الحصول على رمز Agora");
			return data;
		};
		const refreshToken = async () => {
			if (!client || !joinedRef.current) return;
			const access = await getToken();
			await client.renewToken(access.token);
			const nextRole = access.role === "publisher" ? "host" : "audience";
			if (roleRef.current !== nextRole) {
				await client.setClientRole(nextRole);
				roleRef.current = nextRole;
			}
		};
		tokenRefreshRef.current = refreshToken;
		const publishMicrophone = async () => {
			if (!client || !joinedRef.current || !micEnabledRef.current || publishedRef.current) return;
			await refreshToken();
			if (roleRef.current !== "host") throw new Error("حسابك ليس لديه إذن الصعود للميك");
			const track = micRef.current ?? await import_AgoraRTC_N_production.default.createMicrophoneAudioTrack({
				encoderConfig: "speech_low_quality",
				AEC: true,
				ANS: true,
				AGC: true
			});
			micRef.current = track;
			if (!track.enabled) await track.setEnabled(true);
			await client.publish(track);
			publishedRef.current = true;
		};
		const serialize = (task) => {
			operationRef.current = operationRef.current.then(task).catch((error) => {
				if (aliveRef.current) {
					console.error("[Agora RTC]", error);
					toast.error(error instanceof Error ? error.message : "تعذر تشغيل الصوت");
				}
			});
			return operationRef.current;
		};
		const onUserPublished = async (user, mediaType) => {
			if (!client || mediaType !== "audio") return;
			try {
				await client.subscribe(user, mediaType);
				user.audioTrack?.play();
			} catch (error) {
				console.error("[Agora] subscribe failed", error);
			}
		};
		const onUserUnpublished = (user) => {
			user.audioTrack?.stop();
		};
		const resumeRtc = (fromNative = false) => {
			if (!fromNative && document.visibilityState !== "visible" || !client || !joinedRef.current) return;
			serialize(async () => {
				if (!client || !joinedRef.current) return;
				if (client.connectionState === "DISCONNECTED") {
					await client.leave().catch(() => void 0);
					joinedRef.current = false;
					publishedRef.current = false;
					const access = await getToken();
					const nextRole = access.role === "publisher" ? "host" : "audience";
					await client.setClientRole(nextRole);
					roleRef.current = nextRole;
					await client.join(access.appId, access.channel, access.token, access.uid);
					joinedRef.current = true;
					if (micEnabledRef.current && nextRole === "host") await publishMicrophone();
				} else {
					await refreshToken();
					if (micEnabledRef.current && roleRef.current === "host") {
						if (!publishedRef.current) await publishMicrophone();
						else if (micRef.current && !micRef.current.enabled) await micRef.current.setEnabled(true);
					}
				}
			});
		};
		const nativeStateListener = App.addListener("appStateChange", ({ isActive }) => {
			if (isActive) resumeRtc(true);
		});
		const onDocumentResume = () => resumeRtc();
		document.addEventListener("visibilitychange", onDocumentResume);
		window.addEventListener("pageshow", onDocumentResume);
		const start = async () => {
			try {
				await previousLifecycle;
				if (!effectAlive || !aliveRef.current) return;
				if (!uid || !navigator.mediaDevices?.getUserMedia) throw new Error("المتصفح أو WebView لا يدعم الوصول للميكروفون");
				const access = await getToken();
				if (!effectAlive || !aliveRef.current) return;
				client = import_AgoraRTC_N_production.default.createClient({
					mode: "live",
					codec: "vp8"
				});
				clientRef.current = client;
				client.on("user-published", onUserPublished);
				client.on("user-unpublished", onUserUnpublished);
				const rtcToUser = new Map(membersRef.current.map((memberId) => [numericRtcUid(memberId), memberId]));
				rtcToUser.set(numericRtcUid(uid), uid);
				client.enableAudioVolumeIndicator();
				client.on("volume-indicator", (speakers) => {
					const active = speakers.filter((speaker) => speaker.level >= 18).map((speaker) => rtcToUser.get(Number(speaker.uid))).filter((userId) => !!userId);
					onSpeakingUsersRef.current?.([...new Set(active)]);
				});
				client.on("token-privilege-will-expire", () => {
					serialize(refreshToken);
				});
				const initialRole = access.role === "publisher" ? "host" : "audience";
				await client.setClientRole(initialRole);
				roleRef.current = initialRole;
				await client.join(access.appId, access.channel, access.token, access.uid);
				if (!effectAlive || !aliveRef.current) {
					await client.leave().catch(() => void 0);
					return;
				}
				joinedRef.current = true;
				if (micEnabledRef.current && initialRole === "host") {
					await publishMicrophone();
					if (musicFileRef.current) {
						const track = await import_AgoraRTC_N_production.default.createBufferSourceAudioTrack({
							source: musicFileRef.current,
							encoderConfig: "speech_standard"
						});
						musicRef.current = track;
						track.startProcessAudioBuffer();
						await client.publish(track);
						track.play();
					}
				}
			} catch (error) {
				if (aliveRef.current) {
					console.error("[Agora] join failed", error);
					toast.error(error instanceof Error ? error.message : "فشل الاتصال بخدمة الصوت");
				}
			}
		};
		start();
		return () => {
			effectAlive = false;
			aliveRef.current = false;
			document.removeEventListener("visibilitychange", onDocumentResume);
			window.removeEventListener("pageshow", onDocumentResume);
			nativeStateListener.then((listener) => listener.remove()).catch(() => void 0);
			tokenRefreshRef.current = null;
			joinedRef.current = false;
			publishedRef.current = false;
			if (musicRef.current) {
				musicRef.current.stopProcessAudioBuffer();
				musicRef.current.stop();
				musicRef.current.close();
				musicRef.current = null;
			}
			if (micRef.current) {
				micRef.current.stop();
				micRef.current.close();
				micRef.current = null;
			}
			if (client) {
				client.removeAllListeners();
				client.leave().catch(() => void 0).finally(() => {
					if (rtcLifecycle.get(lifecycleKey) === currentLifecycle) rtcLifecycle.delete(lifecycleKey);
					releaseLifecycle();
				});
			} else {
				if (rtcLifecycle.get(lifecycleKey) === currentLifecycle) rtcLifecycle.delete(lifecycleKey);
				releaseLifecycle();
			}
			clientRef.current = null;
		};
	}, [roomId, uid]);
	(0, import_react.useEffect)(() => {
		const client = clientRef.current;
		if (!client || !joinedRef.current) return;
		operationRef.current = operationRef.current.then(async () => {
			if (!musicFile) {
				if (musicRef.current) {
					await client.unpublish(musicRef.current).catch(() => void 0);
					musicRef.current.stopProcessAudioBuffer();
					musicRef.current.stop();
					musicRef.current.close();
					musicRef.current = null;
				}
				return;
			}
			if (!micEnabled) throw new Error("شغّل الميك أولاً حتى يتم بث الأغاني للجميع");
			if (musicRef.current) {
				await client.unpublish(musicRef.current).catch(() => void 0);
				musicRef.current.stopProcessAudioBuffer();
				musicRef.current.stop();
				musicRef.current.close();
				musicRef.current = null;
			}
			const track = await import_AgoraRTC_N_production.default.createBufferSourceAudioTrack({
				source: musicFile,
				encoderConfig: "speech_standard"
			});
			musicRef.current = track;
			track.startProcessAudioBuffer();
			await client.publish(track);
			track.play();
			toast.success("بدأ بث الأغنية لجميع الموجودين على الميك");
		}).catch((error) => {
			console.error("[Agora] music failed", error);
			toast.error(error instanceof Error ? error.message : "تعذر تشغيل الأغنية");
		});
	}, [musicFile, micEnabled]);
	(0, import_react.useEffect)(() => {
		const client = clientRef.current;
		if (!client || !joinedRef.current) return;
		operationRef.current = operationRef.current.then(async () => {
			if (micEnabled) {
				const access = await (async () => {
					const { data, error } = await supabase.functions.invoke("agora-rtc-token", { body: { roomId } });
					if (error) throw error;
					return data;
				})();
				await client.renewToken(access.token);
				const nextRole = access.role === "publisher" ? "host" : "audience";
				if (roleRef.current !== nextRole) {
					await client.setClientRole(nextRole);
					roleRef.current = nextRole;
				}
				if (nextRole !== "host") throw new Error("انتظر موافقة صاحب الغرفة للصعود إلى الميك");
				if (!micRef.current) micRef.current = await import_AgoraRTC_N_production.default.createMicrophoneAudioTrack({
					encoderConfig: "speech_low_quality",
					AEC: true,
					ANS: true,
					AGC: true
				});
				await micRef.current.setEnabled(true);
				if (!publishedRef.current) {
					await client.publish(micRef.current);
					publishedRef.current = true;
				}
				if (musicFileRef.current && !musicRef.current) {
					const musicTrack = await import_AgoraRTC_N_production.default.createBufferSourceAudioTrack({
						source: musicFileRef.current,
						encoderConfig: "speech_standard"
					});
					musicRef.current = musicTrack;
					musicTrack.startProcessAudioBuffer();
					await client.publish(musicTrack);
					musicTrack.play();
				}
			} else {
				if (publishedRef.current && micRef.current) {
					await client.unpublish(micRef.current).catch(() => void 0);
					publishedRef.current = false;
				}
				if (musicRef.current) {
					await client.unpublish(musicRef.current).catch(() => void 0);
					musicRef.current.stopProcessAudioBuffer();
					musicRef.current.stop();
					musicRef.current.close();
					musicRef.current = null;
				}
				if (micRef.current) await micRef.current.setEnabled(false);
				const { data, error } = await supabase.functions.invoke("agora-rtc-token", { body: { roomId } });
				if (!error && data?.token) {
					await client.renewToken(data.token);
					const nextRole = data.role === "publisher" ? "host" : "audience";
					if (roleRef.current !== nextRole) {
						await client.setClientRole(nextRole);
						roleRef.current = nextRole;
					}
				}
			}
		}).catch((error) => {
			console.error("[Agora] microphone state failed", error);
			if (aliveRef.current) toast.error(error instanceof Error ? error.message : "تعذر تفعيل الميكروفون");
		});
	}, [micEnabled, roomId]);
	(0, import_react.useEffect)(() => {
		if (!musicCommand) return;
		const command = musicCommand;
		operationRef.current = operationRef.current.then(async () => {
			const track = musicRef.current;
			if (!track) return;
			if (command.action === "pause") {
				track.pauseProcessAudioBuffer();
				track.stop();
			} else if (command.action === "resume") {
				track.resumeProcessAudioBuffer();
				track.play();
			} else if (command.action === "seek") track.seekAudioBuffer(Math.max(0, Math.min(track.duration, Number(command.value) || 0)));
			else if (command.action === "volume") track.setVolume(Math.max(0, Math.min(1e3, (Number(command.value) || 0) * 10)));
		}).catch((error) => {
			console.error("[Agora] music control failed", error);
			if (aliveRef.current) toast.error("تعذر التحكم في تشغيل الأغنية");
		});
	}, [musicCommand?.id]);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => {
			const track = musicRef.current;
			if (!track) {
				onMusicProgressRef.current?.({
					currentTime: 0,
					duration: 0,
					playing: false
				});
				return;
			}
			onMusicProgressRef.current?.({
				currentTime: track.getCurrentTime(),
				duration: track.duration,
				playing: track.currentState === "playing"
			});
		}, 500);
		return () => window.clearInterval(timer);
	}, [roomId, uid]);
	return null;
}
//#endregion
export { RoomVoice };
