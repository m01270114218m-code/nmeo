import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/media-BXNEENvw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var ALLOWED = [
	"image/jpeg",
	"image/png",
	"image/webp",
	"image/gif"
];
var MAX_BYTES = 5242880;
var cache = /* @__PURE__ */ new Map();
var adminAssetCache = /* @__PURE__ */ new Map();
var cacheGet = (map, key) => {
	const hit = map.get(key);
	if (!hit) return null;
	if (hit.expiresAt <= Date.now()) {
		map.delete(key);
		return null;
	}
	return hit.url;
};
var cacheSet = (map, key, url, ttlMs) => {
	map.set(key, {
		url,
		expiresAt: Date.now() + ttlMs
	});
};
async function compressImage(file) {
	if (!ALLOWED.includes(file.type)) throw new Error("يسمح فقط بالصور (JPG, PNG, WEBP, GIF)");
	if (file.type === "image/gif") return file;
	if (file.size <= 921600 && file.type === "image/webp") return file;
	const bitmap = await createImageBitmap(file).catch(() => null);
	if (!bitmap) {
		if (file.size > MAX_BYTES) throw new Error("تعذر ضغط الصورة؛ اختر صورة أصغر من 5MB");
		return file;
	}
	const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
	const canvas = document.createElement("canvas");
	canvas.width = Math.max(1, Math.round(bitmap.width * scale));
	canvas.height = Math.max(1, Math.round(bitmap.height * scale));
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("تعذر تجهيز الصورة");
	ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
	bitmap.close();
	const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", .82));
	if (!blob) throw new Error("تعذر ضغط الصورة");
	return new File([blob], "upload.webp", {
		type: "image/webp",
		lastModified: Date.now()
	});
}
/** Upload a user-owned image to Supabase Storage and return a media:<path> reference. */
async function uploadImage(file, userId, folder = "profile") {
	const compressed = await compressImage(file);
	const path = folder === "profile" ? `${userId}/${crypto.randomUUID()}.webp` : `${userId}/${folder}/${crypto.randomUUID()}.webp`;
	const { error } = await supabase.storage.from("media").upload(path, compressed, {
		contentType: "image/webp",
		upsert: false
	});
	if (error) throw error;
	return `media:${path}`;
}
async function deleteMedia(value) {
	if (!value?.startsWith("media:")) return;
	const path = value.slice(6).replace(/^\/+/, "");
	const { error } = await supabase.storage.from("media").remove([path]);
	if (error) throw error;
	cache.delete(value);
}
function useMedia(value) {
	const [url, setUrl] = (0, import_react.useState)(() => {
		if (!value) return null;
		if (!value.startsWith("media:")) return value;
		return cacheGet(cache, value);
	});
	(0, import_react.useEffect)(() => {
		if (!value) {
			setUrl(null);
			return;
		}
		if (!value.startsWith("media:")) {
			setUrl(value);
			return;
		}
		const hit = cacheGet(cache, value);
		if (hit) {
			setUrl(hit);
			return;
		}
		let alive = true;
		const path = value.slice(6).replace(/^\/+/, "");
		supabase.storage.from("media").createSignedUrl(path, 21600).then(({ data }) => {
			if (!alive) return;
			if (data?.signedUrl) {
				cacheSet(cache, value, data.signedUrl, 18e6);
				setUrl(data.signedUrl);
			} else setUrl(null);
		});
		return () => {
			alive = false;
		};
	}, [value]);
	return url;
}
function isVideoAsset(value) {
	if (!value) return false;
	const normalized = value.split("#")[0].split("?")[0];
	let decoded = normalized;
	try {
		decoded = decodeURIComponent(normalized);
	} catch {}
	return /\.(mp4|webm|mov)$/i.test(decoded);
}
async function resolveAdminAssetUrl(assetKey) {
	if (!assetKey) return null;
	const cached = cacheGet(adminAssetCache, assetKey);
	if (cached) return cached;
	let raw = assetKey.trim();
	if (raw.startsWith("media:")) {
		const path = raw.slice(6).replace(/^\/+/, "");
		if (!path) return null;
		const { data, error } = await supabase.storage.from("media").createSignedUrl(path, 21600);
		if (error || !data?.signedUrl) return null;
		cacheSet(adminAssetCache, assetKey, data.signedUrl, 18e6);
		return data.signedUrl;
	}
	if (!/^https?:\/\//i.test(raw)) {
		const { data: asset } = await supabase.from("admin_assets").select("asset_key,url,metadata").eq("asset_key", assetKey).eq("is_active", true).maybeSingle();
		if (asset) {
			raw = asset.metadata?.storage_path || asset.url || "";
			if (!raw) return null;
			const { data: signed, error } = await supabase.storage.from("admin-assets").createSignedUrl(raw, 3600);
			if (!error && signed?.signedUrl) {
				cacheSet(adminAssetCache, assetKey, signed.signedUrl, 3e6);
				return signed.signedUrl;
			}
			return null;
		}
		if (/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(raw)) {
			const { data: item } = await supabase.from("store_items").select("asset_key").eq("id", raw).maybeSingle();
			if (item?.asset_key) return getAdminAssetUrl(item.asset_key);
		}
		if (raw.includes("/") || /\.(png|jpe?g|webp|gif|svg|mp4|webm|mov)$/i.test(raw)) {
			const storagePath = raw.replace(/^\/+/, "");
			const { data: signed, error } = await supabase.storage.from("admin-assets").createSignedUrl(storagePath, 3600);
			if (!error && signed?.signedUrl) {
				cacheSet(adminAssetCache, assetKey, signed.signedUrl, 3e6);
				return signed.signedUrl;
			}
		}
		return null;
	}
	if (/^https?:\/\//i.test(raw)) {
		const markerIndex = raw.indexOf("/storage/v1/object/sign/");
		if (markerIndex >= 0) {
			const parts = raw.slice(markerIndex + 24).split("?")[0].split("/");
			const bucket = parts.shift();
			const storagePath = decodeURIComponent(parts.join("/").replace(/^\/+/, ""));
			if (bucket && storagePath) {
				const { data: signed, error } = await supabase.storage.from(bucket).createSignedUrl(storagePath, 3600);
				if (!error && signed?.signedUrl) {
					cacheSet(adminAssetCache, assetKey, signed.signedUrl, 3e6);
					return signed.signedUrl;
				}
			}
			return null;
		}
	}
	const markerIndex = raw.indexOf("/storage/v1/object/");
	if (markerIndex < 0) {
		if (/^https?:\/\//i.test(raw)) {
			cacheSet(adminAssetCache, assetKey, raw, 864e5);
			return raw;
		}
		return null;
	}
	const parts = raw.slice(markerIndex + 19).split("?")[0].split("/");
	const access = parts.shift();
	const bucket = parts.shift();
	const storagePath = decodeURIComponent(parts.join("/").replace(/^\/+/, ""));
	if (!access || !bucket || !storagePath) return null;
	if (access === "public") {
		if (bucket === "admin-assets") {
			const { data: signed, error } = await supabase.storage.from(bucket).createSignedUrl(storagePath, 3600);
			if (error || !signed?.signedUrl) return null;
			cacheSet(adminAssetCache, assetKey, signed.signedUrl, 3e6);
			return signed.signedUrl;
		}
		cacheSet(adminAssetCache, assetKey, raw, 864e5);
		return raw;
	}
	if (access === "sign" || access === "authenticated") {
		const { data: signed, error: signError } = await supabase.storage.from(bucket).createSignedUrl(storagePath, 3600);
		if (signError || !signed?.signedUrl) return null;
		cacheSet(adminAssetCache, assetKey, signed.signedUrl, 3e6);
		return signed.signedUrl;
	}
	return null;
}
/** Resolve an asset without allowing transient Storage/network failures to crash a screen. */
async function getAdminAssetUrl(assetKey) {
	try {
		return await resolveAdminAssetUrl(assetKey);
	} catch (error) {
		console.warn("[assets] failed to resolve admin asset", assetKey, error);
		return null;
	}
}
function useAdminAsset(assetKey) {
	const [url, setUrl] = (0, import_react.useState)(() => assetKey ? cacheGet(adminAssetCache, assetKey) : null);
	(0, import_react.useEffect)(() => {
		let alive = true;
		let refreshTimer;
		if (!assetKey) {
			setUrl(null);
			return;
		}
		const scheduleRefresh = () => {
			if (!alive) return;
			refreshTimer = setTimeout(() => {
				adminAssetCache.delete(assetKey);
				resolveAsset();
			}, 27e5);
		};
		const resolveAsset = async () => {
			const next = await getAdminAssetUrl(assetKey);
			if (!alive) return;
			setUrl(next);
			if (next) scheduleRefresh();
		};
		const hit = cacheGet(adminAssetCache, assetKey);
		if (hit) {
			setUrl(hit);
			scheduleRefresh();
		} else {
			setUrl(null);
			resolveAsset();
		}
		return () => {
			alive = false;
			if (refreshTimer) clearTimeout(refreshTimer);
		};
	}, [assetKey]);
	return url;
}
//#endregion
export { useAdminAsset as a, uploadImage as i, getAdminAssetUrl as n, useMedia as o, isVideoAsset as r, deleteMedia as t };
