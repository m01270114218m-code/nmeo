import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { o as useAuth } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Ct as Bell, D as Search, Q as Heart, S as Shield, a as Users } from "../_libs/lucide-react.mjs";
import { n as PageHeader, t as AppShell } from "./AppShell-CNN_t4M1.mjs";
import { n as UserAvatar } from "./UserAvatar-DvFPapaA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/messages-Dj6K7QkG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Messages() {
	const { user } = useAuth();
	const uid = user.id;
	const [convs, setConvs] = (0, import_react.useState)([]);
	const [people, setPeople] = (0, import_react.useState)({});
	const [unread, setUnread] = (0, import_react.useState)({});
	const [notif, setNotif] = (0, import_react.useState)(0);
	const [q, setQ] = (0, import_react.useState)("");
	async function load() {
		const { data } = await supabase.from("conversations").select("*").order("last_at", { ascending: false }).limit(100);
		const list = data ?? [];
		setConvs(list);
		const others = list.map((c) => c.user_a === uid ? c.user_b : c.user_a);
		if (others.length) {
			const { data: ps } = await supabase.from("profiles").select("id,display_name,avatar_url").in("id", others);
			setPeople(Object.fromEntries((ps ?? []).map((p) => [p.id, p])));
			const { data: um } = await supabase.from("messages").select("conversation_id").in("conversation_id", list.map((c) => c.id)).neq("sender_id", uid).is("read_at", null);
			const counts = {};
			(um ?? []).forEach((m) => counts[m.conversation_id] = (counts[m.conversation_id] ?? 0) + 1);
			setUnread(counts);
		}
		const { count } = await supabase.from("notifications").select("id", {
			count: "exact",
			head: true
		}).eq("is_read", false);
		setNotif(count ?? 0);
	}
	(0, import_react.useEffect)(() => {
		load();
		const ch = supabase.channel(`convs-${Math.random().toString(36).slice(2)}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "conversations"
		}, load).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "messages"
		}, load).subscribe();
		return () => {
			supabase.removeChannel(ch);
		};
	}, []);
	const shortcuts = [
		{
			to: "/notifications",
			label: "رسالة النظام والإشعارات",
			sub: "الإعجابات، المتابعات، الهدايا",
			icon: Bell,
			color: "bg-accent",
			badge: notif
		},
		{
			to: "/friends",
			label: "الأصدقاء",
			sub: "من تتابعهم ويتابعونك",
			icon: Heart,
			color: "bg-destructive",
			badge: 0
		},
		{
			to: "/families",
			label: "العائلة",
			sub: "عائلتك وطلبات الانضمام",
			icon: Users,
			color: "bg-secondary",
			badge: 0
		},
		{
			to: "/help",
			label: "مركز الدعم",
			sub: "بلاغاتك وتذاكرك",
			icon: Shield,
			color: "bg-gold",
			badge: 0
		}
	];
	const filtered = convs.filter((c) => {
		const o = people[c.user_a === uid ? c.user_b : c.user_a];
		return !q || o?.display_name.includes(q);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "الدردشات" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-4 mb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute right-3 top-2.5 h-5 w-5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "pr-10",
				placeholder: "ابحث في المحادثات",
				value: q,
				onChange: (e) => setQ(e.target.value)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-1 px-4",
			children: shortcuts.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: s.to,
				className: "flex items-center gap-3 rounded-2xl p-2 hover:bg-secondary/40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `relative flex h-14 w-14 items-center justify-center rounded-full ${s.color}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { className: "h-7 w-7" }), s.badge > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute -top-1 -left-1 rounded-full bg-destructive px-1.5 text-xs text-destructive-foreground",
						children: s.badge
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-bold",
					children: s.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: s.sub
				})] })]
			}, s.to))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-4 px-4 text-sm font-bold text-muted-foreground",
			children: "المحادثات الخاصة"
		}),
		filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-4 py-6 text-center text-sm text-muted-foreground",
			children: "لا توجد محادثات. افتح ملف أي مستخدم واضغط «مراسلة»."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-1 px-4 pt-2",
			children: filtered.map((c) => {
				const oid = c.user_a === uid ? c.user_b : c.user_a;
				const o = people[oid];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/chat/$id",
					params: { id: c.id },
					className: "flex items-center gap-3 rounded-2xl p-2 hover:bg-secondary/40",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
							src: o?.avatar_url,
							name: o?.display_name,
							size: 52
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: o?.display_name ?? "…"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: new Date(c.last_at).toLocaleDateString("ar-EG")
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm text-muted-foreground",
								children: c.last_message ?? "ابدأ المحادثة"
							})]
						}),
						!!unread[c.id] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-destructive px-2 text-xs text-destructive-foreground",
							children: unread[c.id]
						})
					]
				}, c.id);
			})
		})
	] });
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Messages, {}) });
//#endregion
export { SplitComponent as component };
