import { n as icons3d } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useAdminAsset, o as useMedia, r as isVideoAsset } from "./media-BXNEENvw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/UserAvatar-DvFPapaA.js
var import_jsx_runtime = require_jsx_runtime();
function UserAvatar({ src, name, size = 48, ring = false, vip = 0, frameKey }) {
	const url = useMedia(src);
	const dynamicFrame = useAdminAsset(frameKey);
	const frame = frameKey ? dynamicFrame : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative shrink-0",
		style: {
			width: size,
			height: size
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `absolute flex items-center justify-center overflow-hidden rounded-full bg-secondary ${frame ? "inset-[18%]" : "inset-0"} ${ring && !frame ? "shadow-gold ring-2 ring-primary" : ""}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: url ?? icons3d.profile,
				alt: name ?? "صورة المستخدم",
				className: `h-full w-full ${url ? "object-cover" : "object-contain p-1"}`
			})
		}), frame && (isVideoAsset(frame) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			src: frame,
			autoPlay: true,
			muted: true,
			loop: true,
			playsInline: true,
			"aria-label": vip ? `إطار المستخدم VIP ${vip}` : "إطار المستخدم",
			className: "pointer-events-none absolute inset-0 h-full w-full object-contain"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: frame,
			alt: vip ? `إطار المستخدم VIP ${vip}` : "إطار المستخدم",
			width: size,
			height: size,
			className: "pointer-events-none absolute inset-0 h-full w-full object-contain"
		}))]
	});
}
function MediaImage({ src, className }) {
	const url = useMedia(src);
	if (!url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `animate-pulse bg-muted ${className ?? ""}` });
	return isVideoAsset(url) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `relative block overflow-hidden ${className ?? ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			src: url,
			autoPlay: true,
			muted: true,
			loop: true,
			playsInline: true,
			preload: "auto",
			"aria-hidden": "true",
			className: "h-full w-full object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pointer-events-none absolute bottom-1 left-1 rounded bg-black/75 px-1 py-0.5 text-[8px] font-black text-white",
			children: "▶ MP4"
		})]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: url,
		alt: "",
		className,
		loading: "lazy"
	});
}
//#endregion
export { UserAvatar as n, MediaImage as t };
