import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-BLH0g87i.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Capacitor } from "../_libs/capacitor__app+capacitor__core.mjs";
import { n as icons3d, o as useAuth, t as getDeviceId } from "./assets3d-BTbRf-Mv.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as Input } from "./input-DicJzR9-.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ShieldCheck, Dt as ArrowRight, H as Mail, K as KeyRound, N as Phone } from "../_libs/lucide-react.mjs";
import { t as Browser } from "../_libs/capacitor__browser.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BxYHgzEH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const nav = useNavigate();
	const { user } = useAuth();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [appName, setAppName] = (0, import_react.useState)("صدى شات");
	const [logoUrl, setLogoUrl] = (0, import_react.useState)(null);
	const [bannerTitle, setBannerTitle] = (0, import_react.useState)("");
	const [bannerUrl, setBannerUrl] = (0, import_react.useState)(null);
	const [showBanner, setShowBanner] = (0, import_react.useState)(false);
	const [authMethods, setAuthMethods] = (0, import_react.useState)({
		email_enabled: true,
		quick_enabled: true,
		google_enabled: true,
		phone_enabled: true
	});
	const [phoneMode, setPhoneMode] = (0, import_react.useState)(false);
	const [selectedMethod, setSelectedMethod] = (0, import_react.useState)(null);
	const [phone, setPhone] = (0, import_react.useState)("");
	const [otp, setOtp] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let alive = true;
		let timer;
		async function loadPublicBranding() {
			const { data, error } = await supabase.from("admin_settings").select("key,value").in("key", [
				"app_branding",
				"home_banner",
				"auth_methods"
			]);
			if (error || !alive) return;
			const settings = Object.fromEntries((data ?? []).map((row) => [row.key, row.value]));
			const brand = settings.app_branding ?? {};
			const banner = settings.home_banner ?? {};
			const methods = settings.auth_methods ?? {};
			if (alive) setAuthMethods({
				email_enabled: methods.email_enabled !== false,
				quick_enabled: methods.quick_enabled !== false,
				google_enabled: methods.google_enabled !== false,
				phone_enabled: methods.phone_enabled !== false
			});
			if (brand.app_name) setAppName(brand.app_name);
			if (brand.logo_path) {
				const { data: signed } = await supabase.storage.from("admin-assets").createSignedUrl(brand.logo_path, 3600);
				if (alive) setLogoUrl(signed?.signedUrl ?? null);
			}
			if (banner.enabled !== false && banner.image_path && !sessionStorage.getItem("vox_intro_seen")) {
				const { data: signed } = await supabase.storage.from("admin-assets").createSignedUrl(banner.image_path, 3600);
				if (alive && signed?.signedUrl) {
					sessionStorage.setItem("vox_intro_seen", "1");
					setBannerTitle(banner.title || "");
					setBannerUrl(signed.signedUrl);
					setShowBanner(true);
					timer = setTimeout(() => setShowBanner(false), 5e3);
				}
			}
		}
		loadPublicBranding();
		return () => {
			alive = false;
			if (timer) clearTimeout(timer);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (user) nav({ to: "/" });
	}, [user, nav]);
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		try {
			if (mode === "in") {
				const { error } = await supabase.auth.signInWithPassword({
					email: email.trim().toLowerCase(),
					password
				});
				if (error) throw error;
			} else if (mode === "up") {
				const { error } = await supabase.auth.signUp({
					email: email.trim().toLowerCase(),
					password,
					options: {
						emailRedirectTo: window.location.origin,
						data: { full_name: name }
					}
				});
				if (error) throw error;
				toast.success("تم إنشاء الحساب، افتح بريدك لتأكيده");
				setMode("in");
			} else {
				const { error } = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), { redirectTo: `${window.location.origin}/reset-password` });
				if (error) throw error;
				toast.success("أرسلنا رابط استعادة كلمة المرور إلى بريدك");
			}
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	async function sendPhoneOtp() {
		const value = phone.trim();
		if (!/^\\+[1-9]\\d{7,14}$/.test(value)) {
			toast.error("اكتب الرقم بصيغة دولية مثل +2010xxxxxxxx");
			return;
		}
		setBusy(true);
		try {
			const { error } = await supabase.auth.signInWithOtp({
				phone: value,
				options: { shouldCreateUser: true }
			});
			if (error) throw error;
			toast.success("تم إرسال رمز SMS");
		} catch (err) {
			toast.error(err.message || "تعذر إرسال رمز SMS");
		} finally {
			setBusy(false);
		}
	}
	async function verifyPhoneOtp() {
		if (!otp.trim()) return;
		setBusy(true);
		try {
			const { error } = await supabase.auth.verifyOtp({
				phone: phone.trim(),
				token: otp.trim(),
				type: "sms"
			});
			if (error) throw error;
			toast.success("تم تسجيل الدخول بنجاح");
		} catch (err) {
			toast.error(err.message || "رمز التفعيل غير صحيح");
		} finally {
			setBusy(false);
		}
	}
	async function quick() {
		setBusy(true);
		try {
			const { data: current, error: sessionError } = await supabase.auth.getSession();
			if (sessionError) throw sessionError;
			if (current.session?.user) {
				if (current.session.user.is_anonymous) {
					localStorage.setItem("vox_guest_refresh", current.session.refresh_token);
					localStorage.setItem("vox_guest_account_created", "1");
					localStorage.removeItem("vox_guest_logged_out");
					window.dispatchEvent(new Event("vox-auth-visibility-change"));
					toast.success("تم فتح نفس حسابك السريع المحفوظ على هذا الجهاز");
					nav({ to: "/" });
				} else toast.info("أنت مسجل الدخول بالفعل.");
				return;
			}
			const dev = getDeviceId();
			const saved = localStorage.getItem("vox_guest_refresh");
			if (saved) {
				const { data: restored, error: restoreError } = await supabase.auth.refreshSession({ refresh_token: saved });
				if (!restoreError && restored.session) {
					localStorage.setItem("vox_guest_refresh", restored.session.refresh_token);
					localStorage.setItem("vox_guest_account_created", "1");
					localStorage.removeItem("vox_guest_logged_out");
					window.dispatchEvent(new Event("vox-auth-visibility-change"));
					toast.success("أهلاً بعودتك إلى حساب هذا الجهاز");
					nav({ to: "/" });
					return;
				}
				throw new Error("تعذر استعادة الحساب السريع المحفوظ لهذا الجهاز. لم ننشئ حسابًا جديدًا حفاظًا على حسابك السابق.");
			}
			if (localStorage.getItem("vox_guest_account_created") === "1") throw new Error("الحساب السريع لهذا الجهاز موجود، لكن بيانات استعادته غير متاحة. لم ننشئ حسابًا مكررًا.");
			const { data: guest, error } = await supabase.auth.signInAnonymously();
			if (error) throw error;
			if (!guest.user || !guest.session) throw new Error("لم يتم إنشاء جلسة دخول سريعة");
			const { error: deviceError } = await supabase.rpc("register_device", { _device: dev });
			if (deviceError) {
				await supabase.auth.signOut({ scope: "local" });
				throw new Error("تعذر ربط الحساب بهذا الجهاز: " + deviceError.message);
			}
			localStorage.removeItem("vox_guest_logged_out");
			localStorage.setItem("vox_guest_refresh", guest.session.refresh_token);
			localStorage.setItem("vox_guest_account_created", "1");
			toast.success("تم تسجيل الدخول إلى الحساب السريع لهذا الجهاز");
		} catch (err) {
			toast.error(err.message || "تعذر تسجيل الدخول السريع");
		} finally {
			setBusy(false);
		}
	}
	async function google() {
		setBusy(true);
		try {
			const nativeApp = Capacitor.isNativePlatform();
			const redirectTo = nativeApp ? "com.voxroyale.app://auth/callback" : window.location.origin;
			const { data, error } = await supabase.auth.signInWithOAuth({
				provider: "google",
				options: {
					redirectTo,
					skipBrowserRedirect: nativeApp
				}
			});
			if (error) throw error;
			if (nativeApp) {
				if (!data.url) throw new Error("لم يتم إنشاء رابط تسجيل Google");
				await Browser.open({
					url: data.url,
					presentationStyle: "popover"
				});
			}
		} catch (err) {
			toast.error(err.message || "تعذر بدء تسجيل الدخول باستخدام Google");
			setBusy(false);
		}
	}
	const methodCards = [
		{
			key: "email_enabled",
			label: "البريد الإلكتروني",
			icon: Mail,
			tone: "from-sky-500/30 to-blue-600/10",
			action: () => {
				setPhoneMode(false);
				setMode("in");
				setSelectedMethod("email");
			}
		},
		{
			key: "google_enabled",
			label: "Google",
			icon: null,
			tone: "from-red-500/20 to-yellow-500/10",
			action: google
		},
		{
			key: "phone_enabled",
			label: "رقم الهاتف",
			icon: Phone,
			tone: "from-emerald-500/25 to-cyan-500/10",
			action: () => {
				setPhoneMode(true);
				setMode("in");
				setSelectedMethod("phone");
			}
		},
		{
			key: "quick_enabled",
			label: "دخول سريع",
			icon: KeyRound,
			tone: "from-amber-500/30 to-orange-500/10",
			action: quick
		}
	].filter((m) => authMethods[m.key]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-screen overflow-hidden bg-[radial-gradient(circle_at_top,#4b3a12_0%,transparent_38%),linear-gradient(145deg,#070707,#15120a)] px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -left-20 top-10 h-64 w-64 rounded-full bg-gold/10 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-20 bottom-10 h-72 w-72 rounded-full bg-primary/10 blur-3xl" }),
			showBanner && bannerUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[100] flex items-center justify-center bg-black/95 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full max-w-xl overflow-hidden rounded-3xl border border-gold/40 shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: bannerUrl,
							alt: bannerTitle || "بنر البداية",
							className: "max-h-[78vh] w-full object-contain"
						}),
						bannerTitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-5 pt-12 text-center text-xl font-bold text-white",
							children: bannerTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setShowBanner(false),
							className: "absolute right-3 top-3 rounded-full bg-black/70 px-4 py-2 text-sm text-white",
							children: "تخطي"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 m-auto w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto mb-4 flex h-28 w-28 items-center justify-center rounded-[2rem] border border-gold/40 bg-gradient-to-br from-gold/25 to-black shadow-[0_20px_60px_rgba(0,0,0,.5)]",
								children: logoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: logoUrl,
									alt: appName,
									className: "h-full w-full rounded-[2rem] object-contain p-2"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: icons3d.micHost,
									alt: appName,
									className: "h-20 w-20 object-contain"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-4xl font-black text-gold drop-shadow-lg",
								children: appName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "دخول آمن وسريع إلى عالم الغرف الصوتية"
							})
						]
					}),
					!selectedMethod && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 grid grid-cols-2 gap-3",
						children: methodCards.map((item) => {
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: busy,
								onClick: () => void item.action(),
								className: `group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br ${item.tone} p-4 text-right shadow-xl transition hover:-translate-y-1 hover:border-gold/50 active:scale-[.98]`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mb-2 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/15 bg-black/25 text-white shadow-inner",
										children: Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-6 w-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-2xl font-black text-white",
											children: "G"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-white",
										children: item.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-1 flex items-center gap-1 text-[11px] text-white/55",
										children: ["دخول حقيقي ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3 w-3" })]
									})
								]
							}, item.key);
						})
					}),
					selectedMethod && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "glass rounded-[2rem] border border-white/10 p-5 shadow-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setSelectedMethod(null);
									setPhoneMode(false);
									setMode("in");
									setOtp("");
								},
								className: "mb-3 text-sm text-gold",
								children: "← العودة لطرق تسجيل الدخول"
							}),
							authMethods.email_enabled && !phoneMode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								mode === "up" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "الاسم",
									value: name,
									onChange: (e) => setName(e.target.value),
									required: true,
									maxLength: 30
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "pl-10",
										type: "email",
										placeholder: "البريد الإلكتروني",
										value: email,
										onChange: (e) => setEmail(e.target.value),
										required: true,
										dir: "ltr"
									})]
								}),
								mode !== "reset" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: "mt-3",
									type: "password",
									placeholder: "كلمة المرور",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									required: true,
									minLength: 6,
									dir: "ltr"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: busy,
									className: "mt-3 w-full bg-gold font-bold text-black shadow-gold",
									children: mode === "in" ? "تسجيل الدخول" : mode === "up" ? "إنشاء حساب" : "إرسال رابط الاستعادة"
								})
							] }),
							authMethods.phone_enabled && phoneMode && mode === "in" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-primary/15 bg-background/30 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-3 flex items-center gap-2 font-bold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-5 w-5 text-gold" }), " تسجيل الدخول برقم الهاتف"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "tel",
										dir: "ltr",
										placeholder: "+2010xxxxxxxx",
										value: phone,
										onChange: (e) => setPhone(e.target.value)
									}),
									otp && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "numeric",
										dir: "ltr",
										placeholder: "رمز SMS",
										value: otp,
										onChange: (e) => setOtp(e.target.value),
										className: "mt-2",
										maxLength: 8
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										disabled: busy,
										onClick: () => void (otp.trim() ? verifyPhoneOtp() : sendPhoneOtp()),
										className: "mt-2 w-full bg-primary font-bold",
										children: otp.trim() ? "تأكيد الرمز والدخول" : "إرسال رمز SMS"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex items-center justify-center gap-2 text-[11px] text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-emerald-400" }), " الجلسة محفوظة على هذا الجهاز"]
							}),
							authMethods.email_enabled && !phoneMode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between pt-4 text-sm text-muted-foreground",
								children: [mode === "reset" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode("in"),
									children: "العودة إلى تسجيل الدخول"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode(mode === "in" ? "up" : "in"),
									children: mode === "in" ? "حساب جديد" : "لدي حساب"
								}), mode !== "reset" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode("reset"),
									children: "نسيت كلمة المرور؟"
								})]
							})
						]
					})
				]
			})
		]
	});
}
//#endregion
export { AuthPage as component };
