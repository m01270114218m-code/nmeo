import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as isVideoAsset } from "./media-BXNEENvw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AdminAssetMedia-CBSs12zp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Displays MP4 assets as animated artwork without video labels or loading overlays. */
function AdminAssetMedia({ src, alt = "", className = "", videoClassName, loop = true, muted = false }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	const [videoReady, setVideoReady] = (0, import_react.useState)(false);
	const videoRef = (0, import_react.useRef)(null);
	const revealTimer = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setFailed(false);
		setVideoReady(false);
		if (revealTimer.current !== null) window.clearTimeout(revealTimer.current);
		const unlockAudio = () => {
			videoRef.current?.play().catch(() => {});
		};
		window.addEventListener("pointerdown", unlockAudio, {
			once: true,
			capture: true
		});
		return () => {
			window.removeEventListener("pointerdown", unlockAudio, true);
			if (revealTimer.current !== null) window.clearTimeout(revealTimer.current);
			revealTimer.current = null;
		};
	}, [src]);
	if (!src || failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		role: alt ? "img" : void 0,
		"aria-label": alt || void 0,
		"aria-hidden": alt ? void 0 : true,
		className
	});
	if (isVideoAsset(src)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `admin-asset-media relative inline-flex overflow-hidden ${className}`,
		onPointerDown: () => {
			videoRef.current?.play().catch(() => {});
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `.admin-asset-video{pointer-events:none!important;-webkit-appearance:none;appearance:none;object-fit:inherit}.admin-asset-video::-webkit-media-controls,.admin-asset-video::-webkit-media-controls-panel,.admin-asset-video::-webkit-media-controls-play-button,.admin-asset-video::-webkit-media-controls-start-playback-button,.admin-asset-video::-webkit-media-controls-timeline,.admin-asset-video::-webkit-media-controls-current-time-display,.admin-asset-video::-webkit-media-controls-time-remaining-display{display:none!important;-webkit-appearance:none!important;opacity:0!important}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			ref: videoRef,
			src,
			autoPlay: true,
			muted,
			loop,
			playsInline: true,
			preload: "auto",
			controls: false,
			disablePictureInPicture: true,
			disableRemotePlayback: true,
			controlsList: "nodownload noplaybackrate noremoteplayback",
			"aria-label": alt || void 0,
			onLoadedMetadata: (e) => {
				e.currentTarget.play().catch(() => {});
			},
			onCanPlay: (e) => {
				e.currentTarget.play().catch(() => {});
				if (revealTimer.current !== null) window.clearTimeout(revealTimer.current);
				revealTimer.current = window.setTimeout(() => setVideoReady(true), 220);
			},
			onError: () => setFailed(true),
			style: {
				opacity: videoReady ? 1 : 0,
				transition: "opacity 180ms ease-out"
			},
			className: `admin-asset-video block ${videoClassName ?? className}`
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt,
		className,
		decoding: "async",
		onError: () => setFailed(true)
	});
}
//#endregion
export { AdminAssetMedia as t };
