globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { a as toEventHandler, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-11-16T18:42:30.537Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/manifest.webmanifest": {
		"type": "application/manifest+json",
		"etag": "\"196-XKdIPuuRaE5TtLtUZoXBZk1e8wc\"",
		"mtime": "2026-11-16T18:42:30.537Z",
		"size": 406,
		"path": "../public/manifest.webmanifest"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-11-16T18:42:30.538Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/sdy-chat-icon.svg": {
		"type": "image/svg+xml",
		"etag": "\"84b-OOWoTJ85P7Tj13y0Tbg+4xRZJ+4\"",
		"mtime": "2026-11-16T18:42:30.538Z",
		"size": 2123,
		"path": "../public/sdy-chat-icon.svg"
	},
	"/assets/AdminAssetMedia-BbwisTpp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"87b-Wa/aSYjoU9omFY3/tS3cTAHsqxM\"",
		"mtime": "2026-11-16T18:42:27.770Z",
		"size": 2171,
		"path": "../public/assets/AdminAssetMedia-BbwisTpp.js"
	},
	"/assets/AppShell-B7-DC1eW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24d7-nfK7QQxcl5geRHEy62w5Mtw5TvQ\"",
		"mtime": "2026-11-16T18:42:27.770Z",
		"size": 9431,
		"path": "../public/assets/AppShell-B7-DC1eW.js"
	},
	"/assets/IdentityBadges-BqzuzxLW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"608-xmwNB2salIu9auVME0s6eM5rruo\"",
		"mtime": "2026-11-16T18:42:27.770Z",
		"size": 1544,
		"path": "../public/assets/IdentityBadges-BqzuzxLW.js"
	},
	"/assets/UserAvatar-QrEZ9FVW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"699-7aGJ+3eXGYbRWeu/rEu9CbMg500\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 1689,
		"path": "../public/assets/UserAvatar-QrEZ9FVW.js"
	},
	"/assets/admin-B8Z8vW5U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ada6-RmhMbjExvEiwvO4bXXX3J5J0kGo\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 109990,
		"path": "../public/assets/admin-B8Z8vW5U.js"
	},
	"/assets/admin-BWDTJrPz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"69d-AZBC6LVR7yB24YN5DNqA5+2AxIc\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 1693,
		"path": "../public/assets/admin-BWDTJrPz.js"
	},
	"/assets/arrow-right-DhP80kyU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d-xEJKlS8gQnci7puXbJKYLvRVDHA\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 157,
		"path": "../public/assets/arrow-right-DhP80kyU.js"
	},
	"/assets/assets3d-BitPTSG-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1618-5A4ruV1MO1v/MpSDZ8IVPTjSvvg\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 5656,
		"path": "../public/assets/assets3d-BitPTSG-.js"
	},
	"/assets/auth-DayIjw7T.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"305b-BGmCrWaHUVg3lhTDcX3TTBmjcXg\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 12379,
		"path": "../public/assets/auth-DayIjw7T.js"
	},
	"/assets/back-Dg3-L873.png": {
		"type": "image/png",
		"etag": "\"f6c8-8QJegnDrjS/H9x1fdnN1UsjZK0s\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 63176,
		"path": "../public/assets/back-Dg3-L873.png"
	},
	"/assets/bag-DljgNywu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"174e-IyglZMSmJVASzsg2n9bwbV0VeZo\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 5966,
		"path": "../public/assets/bag-DljgNywu.js"
	},
	"/assets/bell-BCVvmx1Q.png": {
		"type": "image/png",
		"etag": "\"157e5-lr7FEmNDvcvIgQaBF0m35X/ptX8\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 88037,
		"path": "../public/assets/bell-BCVvmx1Q.png"
	},
	"/assets/bell-l0AGH92G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11a-fT8ZkgxBJAaFeQCq3TCiXliY6Mo\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 282,
		"path": "../public/assets/bell-l0AGH92G.js"
	},
	"/assets/button-AeSeaSEG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7f10-ziYTTnFGGo0RJRlkeZacLxX/GsM\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 32528,
		"path": "../public/assets/button-AeSeaSEG.js"
	},
	"/assets/car-2NzIQmoB.png": {
		"type": "image/png",
		"etag": "\"1c204-dmjHLq8/2P+3K+eHPn2gDk4xN5U\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 115204,
		"path": "../public/assets/car-2NzIQmoB.png"
	},
	"/assets/castle-DNlGknhQ.png": {
		"type": "image/png",
		"etag": "\"28972-Fd8k4t+YtbMnpFG0vz7BKCJo8+8\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 166258,
		"path": "../public/assets/castle-DNlGknhQ.png"
	},
	"/assets/chat._id-Cf76p8eD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ed5-VQ2oLUBd02OZpAU60M82LwacVCE\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 3797,
		"path": "../public/assets/chat._id-Cf76p8eD.js"
	},
	"/assets/chat._id-xkKvVZbZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"43c-UWbyN0PI1hE00UtYkVyJ9D6xQqo\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 1084,
		"path": "../public/assets/chat._id-xkKvVZbZ.js"
	},
	"/assets/check-yYBOHfPa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74-k6Tco4pLhzudowkCtPLwy3T37c0\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 116,
		"path": "../public/assets/check-yYBOHfPa.js"
	},
	"/assets/chest-BdUIwVKu.png": {
		"type": "image/png",
		"etag": "\"37f70-Z1+moP+ap3tDKtKBNhyWWdHQMVk\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 229232,
		"path": "../public/assets/chest-BdUIwVKu.png"
	},
	"/assets/RoomVoice-BT488NXj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1806fc-0STGGJaCvvWLGXewECt5IaZ9sxQ\"",
		"mtime": "2026-11-16T18:42:27.770Z",
		"size": 1574652,
		"path": "../public/assets/RoomVoice-BT488NXj.js"
	},
	"/assets/chevron-left-BMjt_4i9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7a-5kDricoxBMLSYxw1ltBmznWFQc0\"",
		"mtime": "2026-11-16T18:42:27.771Z",
		"size": 122,
		"path": "../public/assets/chevron-left-BMjt_4i9.js"
	},
	"/assets/clock-BoMD7e8C.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1-VjcnMFYtHl293QRbzQnhiM/1ytM\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 161,
		"path": "../public/assets/clock-BoMD7e8C.js"
	},
	"/assets/coin-BJaq9zRh.png": {
		"type": "image/png",
		"etag": "\"29588-TebS1BC/YBzLe1HpVUnh2MJcspw\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 169352,
		"path": "../public/assets/coin-BJaq9zRh.png"
	},
	"/assets/crown-C1wYi11J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"162-02RIMjZHTz+sxKR8SCBhh51NZRw\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 354,
		"path": "../public/assets/crown-C1wYi11J.js"
	},
	"/assets/crown-Cm86ECVz.png": {
		"type": "image/png",
		"etag": "\"31bc3-M1QBY/eiTqy17njwHDVa9A5i8vU\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 203715,
		"path": "../public/assets/crown-Cm86ECVz.png"
	},
	"/assets/diamond-C7m0mM8J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ec-JJVf/zzbjpjyP9EutX4md9uVFic\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 236,
		"path": "../public/assets/diamond-C7m0mM8J.js"
	},
	"/assets/diamond-KBz7aKBB.png": {
		"type": "image/png",
		"etag": "\"2caf0-MCeG+mAZZOycEFCRDuvg3ZfW/mY\"",
		"mtime": "2026-11-16T18:42:27.774Z",
		"size": 183024,
		"path": "../public/assets/diamond-KBz7aKBB.png"
	},
	"/assets/diamonds-BK3wZHFd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b9-4vw27IVoXsCha5Kbw6bzlJZvOgk\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 5049,
		"path": "../public/assets/diamonds-BK3wZHFd.js"
	},
	"/assets/dist-CYZZ2lK8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3ff70-IGcAFxUO4W4kWG8v+HguxEcnmcI\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 262e3,
		"path": "../public/assets/dist-CYZZ2lK8.js"
	},
	"/assets/dist-JpKXDfnl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e57-esOpJ2SfK4+2KXvFwnHvnAgiBmQ\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 7767,
		"path": "../public/assets/dist-JpKXDfnl.js"
	},
	"/assets/door-open-ACZv5PYU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16c-uiUoc2LhdOtvd0vUlkpSNeAjVIc\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 364,
		"path": "../public/assets/door-open-ACZv5PYU.js"
	},
	"/assets/esm-C_27_sxd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c-ghM6SBeSv2PGeLy1G3EcilG8its\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 332,
		"path": "../public/assets/esm-C_27_sxd.js"
	},
	"/assets/esm-D-B-velh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"154-sdW4NihphdwMA+/AVp80/bX5u1Q\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 340,
		"path": "../public/assets/esm-D-B-velh.js"
	},
	"/assets/explore-DyAAce_m.png": {
		"type": "image/png",
		"etag": "\"22c57-yUBAefDGXSPrkW+keYNjTPLmtQg\"",
		"mtime": "2026-11-16T18:42:27.774Z",
		"size": 142423,
		"path": "../public/assets/explore-DyAAce_m.png"
	},
	"/assets/families-w64beiD6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c09-3xeKcu+Wt8ngIK5uUmVXzSD6xaU\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 7177,
		"path": "../public/assets/families-w64beiD6.js"
	},
	"/assets/family-BvM15vCT.png": {
		"type": "image/png",
		"etag": "\"1d41a-p6YkPSGWoAEouq+v31LMTxL6mAg\"",
		"mtime": "2026-11-16T18:42:27.774Z",
		"size": 119834,
		"path": "../public/assets/family-BvM15vCT.png"
	},
	"/assets/flag-UaF70SF2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f6-dDLLoHNcoExOyqcPH259axk3dwU\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 246,
		"path": "../public/assets/flag-UaF70SF2.js"
	},
	"/assets/frame-1-DsyPxvvq.png": {
		"type": "image/png",
		"etag": "\"1c348-XORPmIYKPEmKtkI3SUlpwYr/iGg\"",
		"mtime": "2026-11-16T18:42:27.774Z",
		"size": 115528,
		"path": "../public/assets/frame-1-DsyPxvvq.png"
	},
	"/assets/frame-2-CAthEL8j.png": {
		"type": "image/png",
		"etag": "\"249ba-k4QA0cIDqqz/1BbqiZ3ZlICa/4Q\"",
		"mtime": "2026-11-16T18:42:27.774Z",
		"size": 149946,
		"path": "../public/assets/frame-2-CAthEL8j.png"
	},
	"/assets/frame-3-C8CWdiLD.png": {
		"type": "image/png",
		"etag": "\"1ecf8-7aKvrJlpZg0NfrJJjZ6x9dIO29o\"",
		"mtime": "2026-11-16T18:42:27.774Z",
		"size": 126200,
		"path": "../public/assets/frame-3-C8CWdiLD.png"
	},
	"/assets/frame-4-D6pH-AuW.png": {
		"type": "image/png",
		"etag": "\"23e78-nDioewVMcf7Dp+LRawdBJsRhDJQ\"",
		"mtime": "2026-11-16T18:42:27.774Z",
		"size": 147064,
		"path": "../public/assets/frame-4-D6pH-AuW.png"
	},
	"/assets/frame-5-D2lRo8qO.png": {
		"type": "image/png",
		"etag": "\"27feb-R/hhxge49g9CS8W8OoXJ1/FgXNM\"",
		"mtime": "2026-11-16T18:42:27.774Z",
		"size": 163819,
		"path": "../public/assets/frame-5-D2lRo8qO.png"
	},
	"/assets/frame-6-D_STVAjc.png": {
		"type": "image/png",
		"etag": "\"2202d-nLOR0D4bKoPrJAhmb7gZzq/Sx3M\"",
		"mtime": "2026-11-16T18:42:27.774Z",
		"size": 139309,
		"path": "../public/assets/frame-6-D_STVAjc.png"
	},
	"/assets/friends-CBI7SdWp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12d2-buGruM9yqNNgaaSjFRYObrMw1nI\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 4818,
		"path": "../public/assets/friends-CBI7SdWp.js"
	},
	"/assets/friends-CZ1OmZPd.png": {
		"type": "image/png",
		"etag": "\"1bac2-GX/uyB/xHaL71g3ha/2B/peidvA\"",
		"mtime": "2026-11-16T18:42:27.775Z",
		"size": 113346,
		"path": "../public/assets/friends-CZ1OmZPd.png"
	},
	"/assets/friends-DRlFiXK9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f8-HIvEP9wc70fH1L2klVTKu/mztY0\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 1272,
		"path": "../public/assets/friends-DRlFiXK9.js"
	},
	"/assets/gear-B9NL3_h-.png": {
		"type": "image/png",
		"etag": "\"197f8-RpdlDvJ2ZR3RVfc3dY74La1G0b0\"",
		"mtime": "2026-11-16T18:42:27.775Z",
		"size": 104440,
		"path": "../public/assets/gear-B9NL3_h-.png"
	},
	"/assets/gift-DNA_xVdg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"155-fieBl0GLciM4lFf+tf+nCAB2apE\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 341,
		"path": "../public/assets/gift-DNA_xVdg.js"
	},
	"/assets/giftbox-CQ4IOi8t.png": {
		"type": "image/png",
		"etag": "\"1c1ac-5mIBzRAmNUE9ZDeurCZU9Tj0u6I\"",
		"mtime": "2026-11-16T18:42:27.775Z",
		"size": 115116,
		"path": "../public/assets/giftbox-CQ4IOi8t.png"
	},
	"/assets/heart-BuYkKnJb.png": {
		"type": "image/png",
		"etag": "\"2d99a-hje5p8/YiY3FI96EQLayfp2ZPis\"",
		"mtime": "2026-11-16T18:42:27.775Z",
		"size": 186778,
		"path": "../public/assets/heart-BuYkKnJb.png"
	},
	"/assets/heart-CO8xqB3b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-TO90wjBget6ThmKSE6qGpxXpbPY\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 250,
		"path": "../public/assets/heart-CO8xqB3b.js"
	},
	"/assets/help-VOwyCVKk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"939-lAcT8aOkYq3ZEeHUIW4ZCuzmfnc\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 2361,
		"path": "../public/assets/help-VOwyCVKk.js"
	},
	"/assets/home-CslZS9Il.png": {
		"type": "image/png",
		"etag": "\"1be04-GRlUWePQhlOfozyFckH00/Jsy0Y\"",
		"mtime": "2026-11-16T18:42:27.775Z",
		"size": 114180,
		"path": "../public/assets/home-CslZS9Il.png"
	},
	"/assets/image-DLxsMws7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"105-x+5sTJc+cWkXtdTcvH1t5l9FnCw\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 261,
		"path": "../public/assets/image-DLxsMws7.js"
	},
	"/assets/index-CqCbFXYb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"51786-vZZGQerXoNFkQUrUVIa7QS7jKns\"",
		"mtime": "2026-11-16T18:42:27.770Z",
		"size": 333702,
		"path": "../public/assets/index-CqCbFXYb.js"
	},
	"/assets/input-HVJvrNRt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"265-SSvW1KlpOWZCIOeZGXvKxPTDsQE\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 613,
		"path": "../public/assets/input-HVJvrNRt.js"
	},
	"/assets/lazyRouteComponent-CFNdlMA0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1159-WP6AQt3SV3zWbWhrSsHd8m6HGqg\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 4441,
		"path": "../public/assets/lazyRouteComponent-CFNdlMA0.js"
	},
	"/assets/level-1-B_4BJHlI.png": {
		"type": "image/png",
		"etag": "\"21898-w5V7Uh8J6+ySAxmyL5Q68GfE+W8\"",
		"mtime": "2026-11-16T18:42:27.775Z",
		"size": 137368,
		"path": "../public/assets/level-1-B_4BJHlI.png"
	},
	"/assets/level-2-C833Ky6E.png": {
		"type": "image/png",
		"etag": "\"23716-OTgU0knvjQgQ+1n62+em8Yc0t7g\"",
		"mtime": "2026-11-16T18:42:27.775Z",
		"size": 145174,
		"path": "../public/assets/level-2-C833Ky6E.png"
	},
	"/assets/level-3-DtGQ1Rkg.png": {
		"type": "image/png",
		"etag": "\"237aa-JGRjbbdXm2ztQxQgLvhkuuhruT8\"",
		"mtime": "2026-11-16T18:42:27.775Z",
		"size": 145322,
		"path": "../public/assets/level-3-DtGQ1Rkg.png"
	},
	"/assets/level-4-CLEFTeka.png": {
		"type": "image/png",
		"etag": "\"29c4d-Qv098xfEUW+C5dJdzw3UbANNPrs\"",
		"mtime": "2026-11-16T18:42:27.775Z",
		"size": 171085,
		"path": "../public/assets/level-4-CLEFTeka.png"
	},
	"/assets/level-5-BBLsewFB.png": {
		"type": "image/png",
		"etag": "\"36902-U4Fbw2zHo1QSL/QM5vWdx8y2Uq0\"",
		"mtime": "2026-11-16T18:42:27.776Z",
		"size": 223490,
		"path": "../public/assets/level-5-BBLsewFB.png"
	},
	"/assets/level-6-Bq5OTDGz.png": {
		"type": "image/png",
		"etag": "\"38d9c-KWQ3T4Z5CBlrmVDszGkpPor1HS0\"",
		"mtime": "2026-11-16T18:42:27.776Z",
		"size": 232860,
		"path": "../public/assets/level-6-Bq5OTDGz.png"
	},
	"/assets/level-VXXFx9_0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1404-57nP2/CErFEwEXNbCpulQUx5D2A\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 5124,
		"path": "../public/assets/level-VXXFx9_0.js"
	},
	"/assets/link-BmJlRNB0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2bfb-WsJ8k3MVOhf6zgHXoQi4far9PnM\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 11259,
		"path": "../public/assets/link-BmJlRNB0.js"
	},
	"/assets/log-out-CfFjrlbm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"de-vMxXtLaTAmXwPJTtr57INlJQSUU\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 222,
		"path": "../public/assets/log-out-CfFjrlbm.js"
	},
	"/assets/logout-CyJbqldm.png": {
		"type": "image/png",
		"etag": "\"16c9b-h0+TE0cB+R8wBiMowq2CCPMGTnU\"",
		"mtime": "2026-11-16T18:42:27.776Z",
		"size": 93339,
		"path": "../public/assets/logout-CyJbqldm.png"
	},
	"/assets/mail-Gtx7ZM5b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cd-am0K+EM8D+pZOqiFud3hOMSM0gY\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 205,
		"path": "../public/assets/mail-Gtx7ZM5b.js"
	},
	"/assets/media-vUzYlFbQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"120e-Stx20HiIaDMv5LZcgaQ9HoWStgc\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 4622,
		"path": "../public/assets/media-vUzYlFbQ.js"
	},
	"/assets/message-circle-WZ8wmD9m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e9-2B01JsqZiUfv7cEj3798G13+qMU\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 233,
		"path": "../public/assets/message-circle-WZ8wmD9m.js"
	},
	"/assets/messages-Bz_vpbwF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"118f-bNmFe6gDWQ0tAck8jdFxu5+XKPA\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 4495,
		"path": "../public/assets/messages-Bz_vpbwF.js"
	},
	"/assets/messages-CE7iYHsK.png": {
		"type": "image/png",
		"etag": "\"19fa1-luaG00KBPl68+rqOnMulGnJjgE4\"",
		"mtime": "2026-11-16T18:42:27.776Z",
		"size": 106401,
		"path": "../public/assets/messages-CE7iYHsK.png"
	},
	"/assets/mic-Dwrh68Ef.png": {
		"type": "image/png",
		"etag": "\"2382b-s+lXvYt27ZauPxC4Ed6GWg1oJ3Y\"",
		"mtime": "2026-11-16T18:42:27.776Z",
		"size": 145451,
		"path": "../public/assets/mic-Dwrh68Ef.png"
	},
	"/assets/mic-host-CosVm9T7.png": {
		"type": "image/png",
		"etag": "\"20b61-vmSH9wcr0GvIO3QXRjqtzo9Fcjk\"",
		"mtime": "2026-11-16T18:42:27.776Z",
		"size": 133985,
		"path": "../public/assets/mic-host-CosVm9T7.png"
	},
	"/assets/mic-locked-uDSbY1P0.png": {
		"type": "image/png",
		"etag": "\"23845-rF+4hho18cVIP/5F3fPyCX4kTJE\"",
		"mtime": "2026-11-16T18:42:27.777Z",
		"size": 145477,
		"path": "../public/assets/mic-locked-uDSbY1P0.png"
	},
	"/assets/mic-muted-CY6KH7ws.png": {
		"type": "image/png",
		"etag": "\"23be1-7qKCEUSb3XBFhssYyq0fRi6QOP4\"",
		"mtime": "2026-11-16T18:42:27.777Z",
		"size": 146401,
		"path": "../public/assets/mic-muted-CY6KH7ws.png"
	},
	"/assets/moments-ByMo0un8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dc3-swsfzI6OFpG+S9QU/PN5EDh2X3w\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 7619,
		"path": "../public/assets/moments-ByMo0un8.js"
	},
	"/assets/notifications-BnMoXCAU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"786-ERyqA3H+AkS/mJBZdxYjdL4a4fg\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 1926,
		"path": "../public/assets/notifications-BnMoXCAU.js"
	},
	"/assets/plus-BMSOuDBO.png": {
		"type": "image/png",
		"etag": "\"10e02-qHw8EdujPe+ygakkjwhvzR1F+sQ\"",
		"mtime": "2026-11-16T18:42:27.777Z",
		"size": 69122,
		"path": "../public/assets/plus-BMSOuDBO.png"
	},
	"/assets/preload-helper-Czpn1I53.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ac-sE+5KsaRXTMfwOfrOATQajMSGV4\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 1196,
		"path": "../public/assets/preload-helper-Czpn1I53.js"
	},
	"/assets/profile-1jU5PF_u.png": {
		"type": "image/png",
		"etag": "\"1151e-DPnbU2R/pZOjapCXgMfIWXPNYRc\"",
		"mtime": "2026-11-16T18:42:27.777Z",
		"size": 70942,
		"path": "../public/assets/profile-1jU5PF_u.png"
	},
	"/assets/profile-BgBfh4SB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36fd-okp8DwT2Kw7jI83TfIA/c57244A\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 14077,
		"path": "../public/assets/profile-BgBfh4SB.js"
	},
	"/assets/reset-password-58S7u39_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38c-1Ko8CCyx2EK8DY8lZMAXwxS2Go0\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 908,
		"path": "../public/assets/reset-password-58S7u39_.js"
	},
	"/assets/ring-7Op1snYs.png": {
		"type": "image/png",
		"etag": "\"27202-/NDseFUedEpahOm+E5doi7MIzYA\"",
		"mtime": "2026-11-16T18:42:27.777Z",
		"size": 160258,
		"path": "../public/assets/ring-7Op1snYs.png"
	},
	"/assets/rocket-Bv5PzRyD.png": {
		"type": "image/png",
		"etag": "\"1de45-CvEfOjw7rfgxlgbZxfGw7CyhLZU\"",
		"mtime": "2026-11-16T18:42:27.777Z",
		"size": 122437,
		"path": "../public/assets/rocket-Bv5PzRyD.png"
	},
	"/assets/room-garden-93_kgPLL.jpg": {
		"type": "image/jpeg",
		"etag": "\"4d96b-AYR9zh2gCOdI8fAmtvkSI4XL5eo\"",
		"mtime": "2026-11-16T18:42:27.777Z",
		"size": 317803,
		"path": "../public/assets/room-garden-93_kgPLL.jpg"
	},
	"/assets/room-music-BJDQmaHr.jpg": {
		"type": "image/jpeg",
		"etag": "\"32a94-rjZ1p08YBKecF/UgDfCUevCV3EA\"",
		"mtime": "2026-11-16T18:42:27.778Z",
		"size": 207508,
		"path": "../public/assets/room-music-BJDQmaHr.jpg"
	},
	"/assets/room-royal-DMbwXmoq.jpg": {
		"type": "image/jpeg",
		"etag": "\"3cded-UA1tBYBKvuw3Tgr7ByfmrvxPKBw\"",
		"mtime": "2026-11-16T18:42:27.778Z",
		"size": 249325,
		"path": "../public/assets/room-royal-DMbwXmoq.jpg"
	},
	"/assets/room-tropical-D2br8o9D.jpg": {
		"type": "image/jpeg",
		"etag": "\"3e9e6-vWdaam1p3azxoVz/GBB1e5KiNuY\"",
		"mtime": "2026-11-16T18:42:27.778Z",
		"size": 256486,
		"path": "../public/assets/room-tropical-D2br8o9D.jpg"
	},
	"/assets/room._id-BrztJgNP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15605-J/75w4RMwYMx8GzCSYQ0O8reRjg\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 87557,
		"path": "../public/assets/room._id-BrztJgNP.js"
	},
	"/assets/room._id-RNbgD6hm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6ca-b4G5mVDBJKsHeg2v40QCBq5bGXE\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 1738,
		"path": "../public/assets/room._id-RNbgD6hm.js"
	},
	"/assets/rose-BJQiL5s3.png": {
		"type": "image/png",
		"etag": "\"296b5-fEuLWEZMY2Z2DVmTRW5z87Wh7lQ\"",
		"mtime": "2026-11-16T18:42:27.778Z",
		"size": 169653,
		"path": "../public/assets/rose-BJQiL5s3.png"
	},
	"/assets/routes-B6gYUiOR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4f3-kax29qbUBtsRvk2+NMA6/BsfXVs\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 50419,
		"path": "../public/assets/routes-B6gYUiOR.js"
	},
	"/assets/routes-OGGFm5JR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"31c4-w6GirUElX6G+iOiTVI5wkNaX5oU\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 12740,
		"path": "../public/assets/routes-OGGFm5JR.js"
	},
	"/assets/search-2-rcoWv6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a6-aCMITmq1/cBqOT899h6+WFuGDX4\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 166,
		"path": "../public/assets/search-2-rcoWv6.js"
	},
	"/assets/search-DZY5lTm5.png": {
		"type": "image/png",
		"etag": "\"1b305-kcnP2jNZfrGlsFcCDu1J/gE261Q\"",
		"mtime": "2026-11-16T18:42:27.778Z",
		"size": 111365,
		"path": "../public/assets/search-DZY5lTm5.png"
	},
	"/assets/send-CipCD4W5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11a-M0nfMafBjntaNvgk7eDRGz/j9fg\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 282,
		"path": "../public/assets/send-CipCD4W5.js"
	},
	"/assets/send-DPH6sTIv.png": {
		"type": "image/png",
		"etag": "\"16b6d-FW9oKlCCm/mB4voPSAwaajq6fhw\"",
		"mtime": "2026-11-16T18:42:27.778Z",
		"size": 93037,
		"path": "../public/assets/send-DPH6sTIv.png"
	},
	"/assets/settings-BIOpd0ue.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1df-BWxr/ZApzz75BLvJ6y/WNZprVGM\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 479,
		"path": "../public/assets/settings-BIOpd0ue.js"
	},
	"/assets/share-D83L6cd3.png": {
		"type": "image/png",
		"etag": "\"12750-q7AOJZRcnD4Nw+ZX7QpIfT8tDe4\"",
		"mtime": "2026-11-16T18:42:27.779Z",
		"size": 75600,
		"path": "../public/assets/share-D83L6cd3.png"
	},
	"/assets/shield-check-CHmMqO5F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"138-IOyiyFn9m+l0KP9dPcQHvRo4HXA\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 312,
		"path": "../public/assets/shield-check-CHmMqO5F.js"
	},
	"/assets/shopping-bag-BSFWuZi-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c-VlWSvA07gnkz4p6+jfe9Dmt+YSA\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 332,
		"path": "../public/assets/shopping-bag-BSFWuZi-.js"
	},
	"/assets/sparkles-nMO4B5DT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e6-i5tkt6VDlzqzDFOjNXF0lzkzTHE\"",
		"mtime": "2026-11-16T18:42:27.772Z",
		"size": 486,
		"path": "../public/assets/sparkles-nMO4B5DT.js"
	},
	"/assets/star-C_C910lO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d0-cS6pkNT+FAuaVuoCKewMpE4Y6gg\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 464,
		"path": "../public/assets/star-C_C910lO.js"
	},
	"/assets/store-DuIFf-h4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e35-ouXyCDK9Cbk2C7mTIE87/gIliWU\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 7733,
		"path": "../public/assets/store-DuIFf-h4.js"
	},
	"/assets/store-MJpuSzER.png": {
		"type": "image/png",
		"etag": "\"16489-P5Iz8b2fTvSFn2FpdBgDZQskpgg\"",
		"mtime": "2026-11-16T18:42:27.779Z",
		"size": 91273,
		"path": "../public/assets/store-MJpuSzER.png"
	},
	"/assets/styles-BOpEUwmo.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"2add0-KN1TVst74QYTibCZwzjp7Y6Rvq8\"",
		"mtime": "2026-11-16T18:42:27.779Z",
		"size": 175568,
		"path": "../public/assets/styles-BOpEUwmo.css"
	},
	"/assets/support-7NmJg-J4.png": {
		"type": "image/png",
		"etag": "\"147db-pLD+TsUKzce9zCjJH0VmPhFNlyM\"",
		"mtime": "2026-11-16T18:42:27.779Z",
		"size": 83931,
		"path": "../public/assets/support-7NmJg-J4.png"
	},
	"/assets/textarea-DbR0H-ZM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ff-KQ26oNyJeAc3VPa102rdzFadblA\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 511,
		"path": "../public/assets/textarea-DbR0H-ZM.js"
	},
	"/assets/trash-2-DA0UAgOw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-LpTxRKZRJZNWLMQmcIXpwXU/I2g\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 320,
		"path": "../public/assets/trash-2-DA0UAgOw.js"
	},
	"/assets/trash-Dktb-HiP.png": {
		"type": "image/png",
		"etag": "\"168b6-cJqcaylsKQOvRWakklE2JH7BfCg\"",
		"mtime": "2026-11-16T18:42:27.779Z",
		"size": 92342,
		"path": "../public/assets/trash-Dktb-HiP.png"
	},
	"/assets/trophy-BN-uvbkI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d4-z4TwaUHTwah4d26SXCQB//AulQw\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 468,
		"path": "../public/assets/trophy-BN-uvbkI.js"
	},
	"/assets/u._id-AgNLVoJS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4c9-iT+jbjCrvhiIL00LLFF4y3TvHGs\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 1225,
		"path": "../public/assets/u._id-AgNLVoJS.js"
	},
	"/assets/u._id-Bc1xXLSJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"216f-pobvyQTLqlMZYENm3qhnp90myWQ\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 8559,
		"path": "../public/assets/u._id-Bc1xXLSJ.js"
	},
	"/assets/user-plus-B2OfenlG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12e-F91TH5MNa7GReFK/W5VYqx4Gl8s\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 302,
		"path": "../public/assets/user-plus-B2OfenlG.js"
	},
	"/assets/users-CH0GzkAz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12a-m9JlsiS7wjCXA3Ng+37p2Vi4zy0\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 298,
		"path": "../public/assets/users-CH0GzkAz.js"
	},
	"/assets/vip-1-ccH9oVED.png": {
		"type": "image/png",
		"etag": "\"2a337-LOJaZnZObweZsFf71w5aK7bwu74\"",
		"mtime": "2026-11-16T18:42:27.779Z",
		"size": 172855,
		"path": "../public/assets/vip-1-ccH9oVED.png"
	},
	"/assets/vip-2-C08gV04y.png": {
		"type": "image/png",
		"etag": "\"2e995-ezcaH+9iHOihnthF/RWQQfFKnMA\"",
		"mtime": "2026-11-16T18:42:27.779Z",
		"size": 190869,
		"path": "../public/assets/vip-2-C08gV04y.png"
	},
	"/assets/vip-3-BDdFfDR1.png": {
		"type": "image/png",
		"etag": "\"2f25a-bDlQMwNpMr5rOR6CitiJ00hU37s\"",
		"mtime": "2026-11-16T18:42:27.780Z",
		"size": 193114,
		"path": "../public/assets/vip-3-BDdFfDR1.png"
	},
	"/assets/vip-4-DPHxPG1s.png": {
		"type": "image/png",
		"etag": "\"2f08f-2Yohe4Zp265fC43M3WYJBqy4d8k\"",
		"mtime": "2026-11-16T18:42:27.780Z",
		"size": 192655,
		"path": "../public/assets/vip-4-DPHxPG1s.png"
	},
	"/assets/vip-5-BW8ZjjcD.png": {
		"type": "image/png",
		"etag": "\"2e94c-/SE15O/i8ufGoUliw6n3ww7cRLw\"",
		"mtime": "2026-11-16T18:42:27.780Z",
		"size": 190796,
		"path": "../public/assets/vip-5-BW8ZjjcD.png"
	},
	"/assets/vip-6-cVpGwUUN.png": {
		"type": "image/png",
		"etag": "\"3373d-1us5kqky116mYdBbZvcw8iFVNIM\"",
		"mtime": "2026-11-16T18:42:27.780Z",
		"size": 210749,
		"path": "../public/assets/vip-6-cVpGwUUN.png"
	},
	"/assets/vip-Bi7hJz6E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36d8-z3KX7WR93Hc8TqiFb85zu3cePgQ\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 14040,
		"path": "../public/assets/vip-Bi7hJz6E.js"
	},
	"/assets/vip-DyAR4Uwx.png": {
		"type": "image/png",
		"etag": "\"20cc6-h86DbKzRcfFBLDpSLleI6MF1Nco\"",
		"mtime": "2026-11-16T18:42:27.780Z",
		"size": 134342,
		"path": "../public/assets/vip-DyAR4Uwx.png"
	},
	"/assets/vox-CWxUV9sz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9d3-JYiMEl9seLqwlNyrOVT1EIa+yDM\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 2515,
		"path": "../public/assets/vox-CWxUV9sz.js"
	},
	"/assets/wallet-BQxOANl0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116-m6M9tGqRfKt3PuBOZnXg4XLp2NU\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 278,
		"path": "../public/assets/wallet-BQxOANl0.js"
	},
	"/assets/wallet-CvQKlhR4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fe9-MyNgKor08LXUO91P7KcrN2kTUP4\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 4073,
		"path": "../public/assets/wallet-CvQKlhR4.js"
	},
	"/assets/wallet-DqNzQK2M.png": {
		"type": "image/png",
		"etag": "\"1d2a8-kovq6GXaEdbk4cLKBZle21hLR8A\"",
		"mtime": "2026-11-16T18:42:27.780Z",
		"size": 119464,
		"path": "../public/assets/wallet-DqNzQK2M.png"
	},
	"/assets/web-Djb6NYj7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"169-rCr2y/rsrWuADGPWwaKG+KGuctE\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 361,
		"path": "../public/assets/web-Djb6NYj7.js"
	},
	"/assets/web-P90nF4Hg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34b-7Sji8R5IXrLtsNnagj0Ud91pxbA\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 843,
		"path": "../public/assets/web-P90nF4Hg.js"
	},
	"/assets/x-DJr8v236.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"92-mPEl3NudWsWwlMrZpJawACGLAZ8\"",
		"mtime": "2026-11-16T18:42:27.773Z",
		"size": 146,
		"path": "../public/assets/x-DJr8v236.js"
	},
	"/control-center/index.html": {
		"type": "text/html; charset=utf-8",
		"etag": "\"d74b-z2GBvHvphkvi6qqq7cCkGBExXos\"",
		"mtime": "2026-11-16T18:42:30.537Z",
		"size": 55115,
		"path": "../public/control-center/index.html"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_6uLq6y = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_6uLq6y
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
