//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DfxhdOnj.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/vox-royale-social-club/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/auth",
			"/bag",
			"/diamonds",
			"/families",
			"/friends",
			"/help",
			"/level",
			"/messages",
			"/moments",
			"/notifications",
			"/profile",
			"/reset-password",
			"/store",
			"/vip",
			"/wallet",
			"/chat/$id",
			"/room/$id",
			"/u/$id"
		],
		preloads: [
			"/assets/index-CqCbFXYb.js",
			"/assets/dist-CYZZ2lK8.js",
			"/assets/lazyRouteComponent-CFNdlMA0.js",
			"/assets/link-BmJlRNB0.js",
			"/assets/button-AeSeaSEG.js",
			"/assets/dist-JpKXDfnl.js",
			"/assets/preload-helper-Czpn1I53.js",
			"/assets/esm-C_27_sxd.js",
			"/assets/esm-D-B-velh.js",
			"/assets/assets3d-BitPTSG-.js",
			"/assets/routes-B6gYUiOR.js",
			"/assets/shield-check-CHmMqO5F.js",
			"/assets/sparkles-nMO4B5DT.js",
			"/assets/admin-BWDTJrPz.js",
			"/assets/friends-DRlFiXK9.js",
			"/assets/chat._id-xkKvVZbZ.js",
			"/assets/room._id-RNbgD6hm.js",
			"/assets/u._id-AgNLVoJS.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CqCbFXYb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/vox-royale-social-club/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-OGGFm5JR.js",
			"/assets/search-2-rcoWv6.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/trophy-BN-uvbkI.js",
			"/assets/users-CH0GzkAz.js",
			"/assets/media-vUzYlFbQ.js",
			"/assets/UserAvatar-QrEZ9FVW.js",
			"/assets/AdminAssetMedia-BbwisTpp.js",
			"/assets/input-HVJvrNRt.js",
			"/assets/vox-CWxUV9sz.js"
		]
	},
	"/admin": {
		filePath: "/workspace/vox-royale-social-club/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-B8Z8vW5U.js",
			"/assets/bell-l0AGH92G.js",
			"/assets/door-open-ACZv5PYU.js",
			"/assets/flag-UaF70SF2.js",
			"/assets/gift-DNA_xVdg.js",
			"/assets/image-DLxsMws7.js",
			"/assets/search-2-rcoWv6.js",
			"/assets/settings-BIOpd0ue.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/trash-2-DA0UAgOw.js",
			"/assets/users-CH0GzkAz.js",
			"/assets/wallet-BQxOANl0.js",
			"/assets/media-vUzYlFbQ.js",
			"/assets/input-HVJvrNRt.js",
			"/assets/vox-CWxUV9sz.js"
		]
	},
	"/auth": {
		filePath: "/workspace/vox-royale-social-club/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DayIjw7T.js",
			"/assets/arrow-right-DhP80kyU.js",
			"/assets/mail-Gtx7ZM5b.js",
			"/assets/input-HVJvrNRt.js"
		]
	},
	"/bag": {
		filePath: "/workspace/vox-royale-social-club/src/routes/bag.tsx",
		children: void 0,
		preloads: [
			"/assets/bag-DljgNywu.js",
			"/assets/chevron-left-BMjt_4i9.js",
			"/assets/clock-BoMD7e8C.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/x-DJr8v236.js",
			"/assets/media-vUzYlFbQ.js",
			"/assets/AdminAssetMedia-BbwisTpp.js",
			"/assets/vox-CWxUV9sz.js"
		]
	},
	"/diamonds": {
		filePath: "/workspace/vox-royale-social-club/src/routes/diamonds.tsx",
		children: void 0,
		preloads: [
			"/assets/diamonds-BK3wZHFd.js",
			"/assets/chevron-left-BMjt_4i9.js",
			"/assets/diamond-C7m0mM8J.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/star-C_C910lO.js",
			"/assets/input-HVJvrNRt.js",
			"/assets/vox-CWxUV9sz.js"
		]
	},
	"/families": {
		filePath: "/workspace/vox-royale-social-club/src/routes/families.tsx",
		children: void 0,
		preloads: [
			"/assets/families-w64beiD6.js",
			"/assets/check-yYBOHfPa.js",
			"/assets/crown-C1wYi11J.js",
			"/assets/log-out-CfFjrlbm.js",
			"/assets/search-2-rcoWv6.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/trophy-BN-uvbkI.js",
			"/assets/users-CH0GzkAz.js",
			"/assets/x-DJr8v236.js",
			"/assets/UserAvatar-QrEZ9FVW.js",
			"/assets/input-HVJvrNRt.js"
		]
	},
	"/friends": {
		filePath: "/workspace/vox-royale-social-club/src/routes/friends.tsx",
		children: void 0,
		preloads: [
			"/assets/friends-CBI7SdWp.js",
			"/assets/search-2-rcoWv6.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/user-plus-B2OfenlG.js",
			"/assets/users-CH0GzkAz.js",
			"/assets/UserAvatar-QrEZ9FVW.js",
			"/assets/input-HVJvrNRt.js",
			"/assets/IdentityBadges-BqzuzxLW.js"
		]
	},
	"/help": {
		filePath: "/workspace/vox-royale-social-club/src/routes/help.tsx",
		children: void 0,
		preloads: [
			"/assets/help-VOwyCVKk.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/input-HVJvrNRt.js"
		]
	},
	"/level": {
		filePath: "/workspace/vox-royale-social-club/src/routes/level.tsx",
		children: void 0,
		preloads: [
			"/assets/level-VXXFx9_0.js",
			"/assets/chevron-left-BMjt_4i9.js",
			"/assets/AppShell-B7-DC1eW.js"
		]
	},
	"/messages": {
		filePath: "/workspace/vox-royale-social-club/src/routes/messages.tsx",
		children: void 0,
		preloads: [
			"/assets/messages-Bz_vpbwF.js",
			"/assets/bell-l0AGH92G.js",
			"/assets/heart-CO8xqB3b.js",
			"/assets/search-2-rcoWv6.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/users-CH0GzkAz.js",
			"/assets/UserAvatar-QrEZ9FVW.js",
			"/assets/input-HVJvrNRt.js"
		]
	},
	"/moments": {
		filePath: "/workspace/vox-royale-social-club/src/routes/moments.tsx",
		children: void 0,
		preloads: [
			"/assets/moments-ByMo0un8.js",
			"/assets/flag-UaF70SF2.js",
			"/assets/heart-CO8xqB3b.js",
			"/assets/message-circle-WZ8wmD9m.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/trash-2-DA0UAgOw.js",
			"/assets/media-vUzYlFbQ.js",
			"/assets/UserAvatar-QrEZ9FVW.js",
			"/assets/input-HVJvrNRt.js",
			"/assets/vox-CWxUV9sz.js",
			"/assets/IdentityBadges-BqzuzxLW.js",
			"/assets/textarea-DbR0H-ZM.js"
		]
	},
	"/notifications": {
		filePath: "/workspace/vox-royale-social-club/src/routes/notifications.tsx",
		children: void 0,
		preloads: ["/assets/notifications-BnMoXCAU.js", "/assets/AppShell-B7-DC1eW.js"]
	},
	"/profile": {
		filePath: "/workspace/vox-royale-social-club/src/routes/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-BgBfh4SB.js",
			"/assets/chevron-left-BMjt_4i9.js",
			"/assets/crown-C1wYi11J.js",
			"/assets/gift-DNA_xVdg.js",
			"/assets/heart-CO8xqB3b.js",
			"/assets/mail-Gtx7ZM5b.js",
			"/assets/settings-BIOpd0ue.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/shopping-bag-BSFWuZi-.js",
			"/assets/star-C_C910lO.js",
			"/assets/users-CH0GzkAz.js",
			"/assets/media-vUzYlFbQ.js",
			"/assets/UserAvatar-QrEZ9FVW.js",
			"/assets/input-HVJvrNRt.js",
			"/assets/vox-CWxUV9sz.js",
			"/assets/textarea-DbR0H-ZM.js"
		]
	},
	"/reset-password": {
		filePath: "/workspace/vox-royale-social-club/src/routes/reset-password.tsx",
		children: void 0,
		preloads: ["/assets/reset-password-58S7u39_.js", "/assets/input-HVJvrNRt.js"]
	},
	"/store": {
		filePath: "/workspace/vox-royale-social-club/src/routes/store.tsx",
		children: void 0,
		preloads: [
			"/assets/store-DuIFf-h4.js",
			"/assets/chevron-left-BMjt_4i9.js",
			"/assets/clock-BoMD7e8C.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/shopping-bag-BSFWuZi-.js",
			"/assets/star-C_C910lO.js",
			"/assets/x-DJr8v236.js",
			"/assets/media-vUzYlFbQ.js",
			"/assets/AdminAssetMedia-BbwisTpp.js",
			"/assets/vox-CWxUV9sz.js"
		]
	},
	"/vip": {
		filePath: "/workspace/vox-royale-social-club/src/routes/vip.tsx",
		children: void 0,
		preloads: [
			"/assets/vip-Bi7hJz6E.js",
			"/assets/arrow-right-DhP80kyU.js",
			"/assets/check-yYBOHfPa.js",
			"/assets/chevron-left-BMjt_4i9.js",
			"/assets/crown-C1wYi11J.js",
			"/assets/diamond-C7m0mM8J.js",
			"/assets/gift-DNA_xVdg.js",
			"/assets/image-DLxsMws7.js",
			"/assets/message-circle-WZ8wmD9m.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/star-C_C910lO.js",
			"/assets/vox-CWxUV9sz.js"
		]
	},
	"/wallet": {
		filePath: "/workspace/vox-royale-social-club/src/routes/wallet.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-CvQKlhR4.js",
			"/assets/chevron-left-BMjt_4i9.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/star-C_C910lO.js",
			"/assets/vox-CWxUV9sz.js"
		]
	},
	"/chat/$id": {
		filePath: "/workspace/vox-royale-social-club/src/routes/chat.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/chat._id-Cf76p8eD.js",
			"/assets/arrow-right-DhP80kyU.js",
			"/assets/check-yYBOHfPa.js",
			"/assets/send-CipCD4W5.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/UserAvatar-QrEZ9FVW.js",
			"/assets/input-HVJvrNRt.js",
			"/assets/vox-CWxUV9sz.js"
		]
	},
	"/room/$id": {
		filePath: "/workspace/vox-royale-social-club/src/routes/room.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/room._id-BrztJgNP.js",
			"/assets/bell-l0AGH92G.js",
			"/assets/crown-C1wYi11J.js",
			"/assets/door-open-ACZv5PYU.js",
			"/assets/gift-DNA_xVdg.js",
			"/assets/heart-CO8xqB3b.js",
			"/assets/log-out-CfFjrlbm.js",
			"/assets/message-circle-WZ8wmD9m.js",
			"/assets/send-CipCD4W5.js",
			"/assets/settings-BIOpd0ue.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/user-plus-B2OfenlG.js",
			"/assets/users-CH0GzkAz.js",
			"/assets/wallet-BQxOANl0.js",
			"/assets/x-DJr8v236.js",
			"/assets/media-vUzYlFbQ.js",
			"/assets/UserAvatar-QrEZ9FVW.js",
			"/assets/AdminAssetMedia-BbwisTpp.js",
			"/assets/input-HVJvrNRt.js",
			"/assets/vox-CWxUV9sz.js",
			"/assets/IdentityBadges-BqzuzxLW.js"
		]
	},
	"/u/$id": {
		filePath: "/workspace/vox-royale-social-club/src/routes/u.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/u._id-Bc1xXLSJ.js",
			"/assets/door-open-ACZv5PYU.js",
			"/assets/flag-UaF70SF2.js",
			"/assets/message-circle-WZ8wmD9m.js",
			"/assets/AppShell-B7-DC1eW.js",
			"/assets/user-plus-B2OfenlG.js",
			"/assets/media-vUzYlFbQ.js",
			"/assets/UserAvatar-QrEZ9FVW.js",
			"/assets/AdminAssetMedia-BbwisTpp.js",
			"/assets/vox-CWxUV9sz.js",
			"/assets/IdentityBadges-BqzuzxLW.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
